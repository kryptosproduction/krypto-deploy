"""
pump_quality.py — a quant scoring layer for Bot 2.

Turns a raw pump detection into a TRADE / SHADOW / SKIP decision with a proper
plan (dynamic stop, R:R-checked target, conviction-weighted size). It answers
two questions:

  1. Is the move REAL?    -> taker buying, rising OI, sustained (not spiked) volume
  2. Is it EARLY enough?  -> extension vs EMA in ATR units, RSI, funding crowding

Market context is pulled from Binance USDT-M public endpoints (no API key). Every
fetch degrades gracefully to None; missing factors have their weight redistributed
(adaptive weighting), and data_confidence reflects how complete the read was — the
same approach Bot 1 uses, so a partial read never silently scores like a full one.
"""
import json
import time
import logging
import urllib.request

import numpy as np
import pandas as pd

log = logging.getLogger('pump_quality')

FAPI = 'https://fapi.binance.com'


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def _fapi_get(path, params, timeout=6):
    try:
        qs = '&'.join(f'{k}={v}' for k, v in params.items())
        url = f'{FAPI}{path}?{qs}'
        req = urllib.request.Request(url, headers={'User-Agent': 'KryptoSniper/1.0'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        log.debug(f"fapi {path} failed: {e}")
        return None


def _fsym(symbol):
    """ccxt unified 'BTC/USDT:USDT' -> Binance 'BTCUSDT'."""
    return symbol.replace('/', '').replace(':USDT', '')


class PumpScorer:
    def __init__(self, cfg=None):
        c = cfg or {}
        self.liq_feed = None     # optional LiquidationFeed, set by the bot if available
        self.min_trade = c.get('min_score_to_trade', 58)
        self.shadow_min = c.get('shadow_min_score', 45)
        self.min_rr = c.get('min_rr', 1.5)
        self.atr_mult = c.get('atr_stop_mult', 2.0)
        self.max_stop = c.get('max_stop_pct', 12.0)
        self.min_stop = c.get('min_stop_pct', 3.0)
        self.vol_target = c.get('vol_target_pct', 4.0)
        self.btc_dump_veto = c.get('btc_dump_veto_pct', -2.5)
        self.r_cap = c.get('target_r_cap', 4.0)   # cap target at this many R
        self.min_quote_vol = c.get('min_quote_volume', 5_000_000)  # 24h $ liquidity floor
        self.min_impulse_atr = c.get('min_impulse_atr', 1.2)       # move must be >= this x ATR
        self._btc = {'pct_1h': None, 'ts': 0}
        self._btc_lead_cache = {'pct': None, 'ts': 0}

    # ----------------------------------------------------------- candle features
    def _features(self, df):
        f = {}
        try:
            close = df['close'].astype(float)
            high = df['high'].astype(float)
            low = df['low'].astype(float)
            openp = df['open'].astype(float)
            price = float(close.iloc[-1])

            # ATR(14) as % of price
            prev = close.shift(1)
            tr = pd.concat([(high - low), (high - prev).abs(), (low - prev).abs()], axis=1).max(axis=1)
            atr = float(tr.rolling(14).mean().iloc[-1])
            f['atr_pct'] = round(atr / price * 100, 3) if price else None

            # RSI(14)
            delta = close.diff()
            gain = delta.clip(lower=0).rolling(14).mean()
            loss = (-delta.clip(upper=0)).rolling(14).mean()
            rs = gain / loss.replace(0, np.nan)
            f['rsi'] = round(float((100 - 100 / (1 + rs)).iloc[-1]), 1)

            # extension above EMA20 in ATR units
            ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
            f['ext_atr'] = round((price - ema20) / atr, 2) if atr else None

            # consecutive green candles (blow-off proxy)
            cg = 0
            for i in range(len(close) - 1, -1, -1):
                if close.iloc[i] > openp.iloc[i]:
                    cg += 1
                else:
                    break
            f['consec_green'] = cg

            # close location in candle range (demand proxy / CVD lite)
            last_rng = float(high.iloc[-1] - low.iloc[-1])
            f['close_loc'] = round((float(close.iloc[-1]) - float(low.iloc[-1])) / last_rng, 2) if last_rng else 0.5
            f['price'] = price
        except Exception as e:
            log.debug(f"feature calc failed: {e}")
        return f

    # ----------------------------------------------------------- market context
    def _context(self, symbol):
        s = _fsym(symbol)
        ctx = {'oi_change_pct': None, 'funding': None, 'taker_ratio': None,
               'top_trader_ls': None, 'quote_vol_24h': None,
               'basis_pct': None, 'htf_align': None, 'sym_1h_pct': None,
               'oi_zscore': None, 'global_ls': None, 'cvd_slope': None,
               'price_slope': None, 'short_liq_ratio': None,
               'liq_cascade': None, 'btc_lead_15m': None}

        tkr = _fapi_get('/fapi/v1/ticker/24hr', {'symbol': s})
        if isinstance(tkr, dict):
            try:
                ctx['quote_vol_24h'] = round(float(tkr['quoteVolume']), 0)
            except Exception:
                pass

        oi = _fapi_get('/futures/data/openInterestHist', {'symbol': s, 'period': '5m', 'limit': 30})
        if oi and len(oi) >= 2:
            try:
                vals = [float(o['sumOpenInterest']) for o in oi]
                a, b = vals[0], vals[-1]
                ctx['oi_change_pct'] = round((b - a) / a * 100, 2) if a else None
                # z-score: how abnormal is the latest OI vs this coin's own recent OI
                if len(vals) >= 10:
                    arr = pd.Series(vals)
                    sd = float(arr.std())
                    ctx['oi_zscore'] = round((vals[-1] - float(arr.mean())) / sd, 2) if sd > 0 else None
            except Exception:
                pass

        fund = _fapi_get('/fapi/v1/premiumIndex', {'symbol': s})
        if isinstance(fund, dict):
            try:
                ctx['funding'] = round(float(fund['lastFundingRate']) * 100, 4)  # % per 8h
            except Exception:
                pass
            try:
                mark = float(fund['markPrice']); index = float(fund['indexPrice'])
                ctx['basis_pct'] = round((mark - index) / index * 100, 3) if index else None
            except Exception:
                pass

        tk = _fapi_get('/futures/data/takerlongshortRatio', {'symbol': s, 'period': '5m', 'limit': 1})
        if tk:
            try:
                ctx['taker_ratio'] = round(float(tk[-1]['buySellRatio']), 3)
            except Exception:
                pass

        tt = _fapi_get('/futures/data/topLongShortPositionRatio', {'symbol': s, 'period': '5m', 'limit': 1})
        if tt:
            try:
                ctx['top_trader_ls'] = round(float(tt[-1]['longShortRatio']), 3)
            except Exception:
                pass

        # global/retail long-short account ratio (smart-money vs retail divergence)
        gl = _fapi_get('/futures/data/globalLongShortAccountRatio', {'symbol': s, 'period': '5m', 'limit': 1})
        if gl:
            try:
                ctx['global_ls'] = round(float(gl[-1]['longShortRatio']), 3)
            except Exception:
                pass

        # CVD slope vs price slope (real cumulative volume delta divergence)
        kk = _fapi_get('/fapi/v1/klines', {'symbol': s, 'interval': '1m', 'limit': 20})
        if kk and len(kk) >= 6:
            try:
                cvd, closes, run = [], [], 0.0
                for r in kk:
                    vol, tbv = float(r[5]), float(r[9])     # total vol, taker-buy vol
                    run += tbv - (vol - tbv)                 # buy - sell delta
                    cvd.append(run); closes.append(float(r[4]))
                xs = list(range(len(cvd)))
                cvd_slope = float(np.polyfit(xs, cvd, 1)[0])
                price_slope = float(np.polyfit(xs, closes, 1)[0])
                ctx['cvd_slope'] = cvd_slope
                ctx['price_slope'] = price_slope
            except Exception:
                pass

        # short-liquidation ratio (organic pump vs squeeze) — from the live WS feed
        if self.liq_feed is not None:
            try:
                ctx['short_liq_ratio'] = self.liq_feed.short_liq_ratio(symbol)
            except Exception:
                pass
            try:
                ctx['liq_cascade'] = self.liq_feed.cascade_intensity(symbol)
            except Exception:
                pass

        # higher-timeframe trend alignment + the symbol's own 1h return (for RS vs BTC)
        k = _fapi_get('/fapi/v1/klines', {'symbol': s, 'interval': '1h', 'limit': 50})
        if k and len(k) >= 21:
            try:
                closes = pd.Series([float(c[4]) for c in k])
                ema = closes.ewm(span=20, adjust=False).mean().iloc[-1]
                ctx['htf_align'] = 1.0 if closes.iloc[-1] > ema else 0.0
                ctx['sym_1h_pct'] = round((closes.iloc[-1] - closes.iloc[-2]) / closes.iloc[-2] * 100, 2)
            except Exception:
                pass
        return ctx

    def _btc_lead(self):
        """BTC's short-term (15-min) momentum — the immediate tape that alts LAG.
        Alts pumping while BTC just pushed up are riding a macro wave (continuation);
        alts pumping while BTC drops are fighting the tape (fragile). Cached 2 min."""
        if time.time() - self._btc_lead_cache['ts'] < 120 and self._btc_lead_cache['pct'] is not None:
            return self._btc_lead_cache['pct']
        k = _fapi_get('/fapi/v1/klines', {'symbol': 'BTCUSDT', 'interval': '5m', 'limit': 4})
        pct = None
        if k and len(k) >= 4:
            try:
                start = float(k[0][4]); end = float(k[-1][4])   # ~15 min of 5m candles
                pct = round((end - start) / start * 100, 3)
            except Exception:
                pass
        self._btc_lead_cache = {'pct': pct, 'ts': time.time()}
        return pct

    def _btc_regime(self):
        if time.time() - self._btc['ts'] < 300 and self._btc['pct_1h'] is not None:
            return self._btc['pct_1h']
        k = _fapi_get('/fapi/v1/klines', {'symbol': 'BTCUSDT', 'interval': '1h', 'limit': 2})
        pct = None
        if k and len(k) >= 2:
            try:
                prev_close = float(k[0][4]); last_close = float(k[1][4])
                pct = round((last_close - prev_close) / prev_close * 100, 2)
            except Exception:
                pass
        self._btc = {'pct_1h': pct, 'ts': time.time()}
        return pct

    # ----------------------------------------------------------- scoring
    def _score(self, f, ctx, regime, pump):
        """Weighted sub-scores in [0,1] with adaptive re-weighting for missing data."""
        parts = {}   # name -> (sub_score in [0,1] or None, weight)

        # --- demand authenticity (is the buying real?) ---
        # taker buy/sell ratio > 1 = aggressive buyers
        tr = ctx.get('taker_ratio')
        parts['taker'] = ((_clamp((tr - 0.9) / 0.6, 0, 1) if tr is not None else None), 14)
        # OI rising during pump = new positioning / squeeze fuel (Bot 1's ORCA logic).
        # Blend raw %-change with a z-score of how abnormal this OI move is vs the
        # coin's own history (ported from Bot 1) when available.
        oi = ctx.get('oi_change_pct')
        oi_base = _clamp((oi + 1) / 6, 0, 1) if oi is not None else None
        oiz = ctx.get('oi_zscore')
        if oiz is not None:
            oiz_score = _clamp((oiz + 0.5) / 3.0, 0, 1)   # +3σ OI = strong
            blended = oiz_score if oi_base is None else (0.5 * oi_base + 0.5 * oiz_score)
            parts['oi'] = (blended, 13)
        else:
            parts['oi'] = (oi_base, 13)
        # NOTE: volume is the SIGNAL TRIGGER (the >=15x gate), deliberately NOT a
        # score factor — scoring it would double-count the very thing that fired
        # the signal. The score judges everything ELSE about the setup.
        # closing near candle high = buyers in control (price action, not volume)
        cl = f.get('close_loc')
        parts['close_loc'] = ((_clamp(cl, 0, 1) if cl is not None else None), 6)

        # --- positioning / squeeze fuel ---
        tt = ctx.get('top_trader_ls')
        parts['top_trader'] = ((_clamp((tt - 0.9) / 0.7, 0, 1) if tt is not None else None), 10)
        # funding: mild positive ok; extreme positive = crowded longs = exhaustion
        fund = ctx.get('funding')
        if fund is not None:
            parts['funding'] = (_clamp(1 - (fund / 0.08), 0, 1), 10)   # 0.08%/8h ~ hot
        else:
            parts['funding'] = (None, 10)

        # --- regime alignment ---
        if regime is not None:
            # reward neutral/up BTC, punish dumps
            parts['regime'] = (_clamp((regime + 2.5) / 4.0, 0, 1), 13)
        else:
            parts['regime'] = (None, 13)

        # spot-perp basis: perp >> spot = leveraged froth (fragile); spot-led = real
        basis = ctx.get('basis_pct')
        if basis is not None:
            parts['basis'] = (_clamp(1 - (basis / 0.4), 0, 1) if basis > 0 else 1.0, 8)
        else:
            parts['basis'] = (None, 8)

        # higher-timeframe trend alignment (pumping with the 1h trend, not against it)
        htf = ctx.get('htf_align')
        parts['htf_trend'] = ((float(htf) if htf is not None else None), 8)

        # relative strength vs BTC: is this coin leading the market or just beta?
        sym1h = ctx.get('sym_1h_pct')
        if sym1h is not None and regime is not None:
            parts['rs_btc'] = (_clamp(((sym1h - regime) + 2) / 4, 0, 1), 7)
        else:
            parts['rs_btc'] = (None, 7)

        # --- order-flow quality (ported from Bot 1) ---
        # CVD vs price slope: is real cumulative buying behind the move, or is price
        # rising on hollow flow? CVD up with price up = confirmed; price up while CVD
        # flat/down = distribution into the pump (weak). Divergence the OTHER way
        # (price flat, CVD up) is hidden accumulation = also good.
        cvd_s = ctx.get('cvd_slope'); px_s = ctx.get('price_slope')
        if cvd_s is not None and px_s is not None:
            cvd_dir = 1 if cvd_s > 0 else (-1 if cvd_s < 0 else 0)
            px_dir = 1 if px_s > 0 else (-1 if px_s < 0 else 0)
            if cvd_dir > 0 and px_dir >= 0:
                cvd_score = 1.0            # buying confirmed
            elif cvd_dir > 0 and px_dir < 0:
                cvd_score = 0.8            # absorption: price down, buyers loading
            elif cvd_dir <= 0 and px_dir > 0:
                cvd_score = 0.2            # price up on weak/negative flow = suspect
            else:
                cvd_score = 0.4
            parts['cvd'] = (cvd_score, 10)
        else:
            parts['cvd'] = (None, 10)

        # global/retail long-short vs top-trader: smart money long while retail short
        # = bullish divergence; both crowded long = late.
        gls = ctx.get('global_ls'); tls = ctx.get('top_trader_ls')
        if gls is not None and tls is not None:
            # top traders more long than retail (tls > gls) is the bullish tell
            parts['smart_vs_retail'] = (_clamp((tls - gls + 0.3) / 0.8, 0, 1), 6)
        elif gls is not None:
            parts['smart_vs_retail'] = (_clamp(1 - (gls - 1) / 1.5, 0, 1), 6)  # extreme retail-long = late
        else:
            parts['smart_vs_retail'] = (None, 6)

        # short-liquidation ratio: a pump that's mostly shorts being force-bought is a
        # SQUEEZE that snaps back. High short-liq share = lower quality. (Bot 1's
        # liquidation_organic, fed by the live forceOrder websocket.)
        slr = ctx.get('short_liq_ratio')
        if slr is not None:
            parts['liq_organic'] = (_clamp(1 - (slr - 0.4) / 0.5, 0, 1), 10)  # >40% short-liq starts penalizing
        else:
            parts['liq_organic'] = (None, 10)

        # BTC lead-lag: alts lag BTC. A pump while BTC just pushed up (last 15m) has
        # macro tailwind (continuation); a pump while BTC is dropping is fighting the
        # tape. Distinct from the slower 1h 'regime' and from 'rs_btc' (relative).
        btc_lead = ctx.get('btc_lead_15m')
        if btc_lead is not None:
            parts['btc_lead'] = (_clamp((btc_lead + 0.4) / 1.2, 0, 1), 7)
        else:
            parts['btc_lead'] = (None, 7)

        # liquidation-cascade magnet: a burst of short liquidations firing RIGHT NOW
        # (vs the recent baseline) is active squeeze fuel pulling price up — good for
        # a long pump's continuation. Timing signal, distinct from liq_organic.
        casc = ctx.get('liq_cascade')
        if casc is not None:
            parts['liq_cascade'] = (_clamp((casc - 1.0) / 3.0, 0, 1), 7)  # 1x normal..4x = full
        else:
            parts['liq_cascade'] = (None, 7)

        # --- entry quality / non-exhaustion (is it early?) ---
        rsi = f.get('rsi')
        # best ~ 55-70; punish >80 (overbought) and <45 (no momentum)
        if rsi is not None:
            rsi_score = 1 - _clamp((rsi - 68) / 22, 0, 1) if rsi >= 68 else _clamp((rsi - 40) / 28, 0, 1)
            parts['rsi'] = (_clamp(rsi_score, 0, 1), 9)
        else:
            parts['rsi'] = (None, 9)
        ext = f.get('ext_atr')   # extension above EMA20 in ATR; >4 = stretched
        parts['extension'] = ((_clamp(1 - (ext - 1) / 5, 0, 1) if ext is not None else None), 9)
        cg = f.get('consec_green')
        parts['blowoff'] = ((_clamp(1 - (cg - 3) / 6, 0, 1) if cg is not None else None), 5)

        # adaptive weighting: redistribute weight of missing factors
        avail = {k: v for k, v in parts.items() if v[0] is not None}
        total_w = sum(w for _, w in parts.values())
        avail_w = sum(w for _, w in avail.values())
        if avail_w == 0:
            return 0, 0.0, {}
        score01 = sum(s * w for s, w in avail.values()) / avail_w
        data_conf = round(avail_w / total_w, 2)
        contributions = {k: round(s * w, 1) for k, (s, w) in avail.items()}
        return round(score01 * 100), data_conf, contributions

    # ----------------------------------------------------------- planning
    def _plan(self, entry, f, resistance):
        """Dynamic stop + R:R-checked target."""
        atr_pct = f.get('atr_pct') or 4.0
        # stop: ATR-based, clamped to a sane band (not a flat -20%)
        stop_pct = _clamp(self.atr_mult * atr_pct, self.min_stop, self.max_stop)
        stop = entry * (1 - stop_pct / 100)
        risk = entry - stop

        # target: nearest resistance, but capped at r_cap R and floored to keep R:R sane
        res = (resistance or {}).get('4h', {}).get('resistance')
        cap_target = entry + self.r_cap * risk
        if res and res > entry:
            target = min(res, cap_target)
        else:
            target = entry + max(self.min_rr, 2.0) * risk
        rr = round((target - entry) / risk, 2) if risk > 0 else 0
        return {'stop': round(stop, 8), 'target': round(target, 8),
                'stop_pct': round(stop_pct, 2), 'rr': rr, 'risk_pct': round(stop_pct, 2)}

    def _size(self, score, f):
        atr_pct = f.get('atr_pct') or self.vol_target
        vol_adj = _clamp(self.vol_target / atr_pct, 0.3, 2.0)   # vol-target sizing
        conv = 1.0 if score >= 70 else (0.6 if score >= self.min_trade else 0.0)
        return round(conv * vol_adj, 2)

    # ----------------------------------------------------------- public
    def evaluate(self, symbol, df, pump, resistance, fetch_context=True):
        f = self._features(df)
        entry = f.get('price') or pump.get('current_price')
        ctx = self._context(symbol) if fetch_context else {}
        regime = self._btc_regime() if fetch_context else None
        if fetch_context:
            ctx['btc_lead_15m'] = self._btc_lead()

        score, data_conf, contribs = self._score(f, ctx, regime, pump)
        plan = self._plan(entry, f, resistance)

        # --- signal qualifiers (gate-level, separate from the score) ---
        # The pump volume already fired the signal; these decide if it's tradeable.
        skip = []
        qv = ctx.get('quote_vol_24h')
        if qv is not None and qv < self.min_quote_vol:
            skip.append('illiquid')          # can't actually trade it -> SKIP entirely

        atr_pct = f.get('atr_pct')
        move = pump.get('price_change_pct', 0)
        impulse = round(move / atr_pct, 2) if atr_pct else None
        f['impulse_atr'] = impulse

        # hard vetoes (force shadow) -> a quant's non-negotiables
        vetoes = []
        if plan['rr'] < 1.2:
            vetoes.append('rr<1.2')
        if regime is not None and regime < self.btc_dump_veto:
            vetoes.append('btc_dumping')
        if f.get('rsi') is not None and f['rsi'] > 90:
            vetoes.append('blowoff_rsi')
        if data_conf < 0.5:
            vetoes.append('low_data_conf')
        if impulse is not None and impulse < self.min_impulse_atr:
            vetoes.append('weak_impulse')    # move too small for this coin's vol

        # decision
        if skip:
            decision, mode = 'SKIP', 'ILLIQUID'
        elif vetoes:
            decision, mode = 'SHADOW', 'VETOED'
        elif score >= self.min_trade and plan['rr'] >= self.min_rr:
            decision = 'TRADE'
            mode = 'CHASE' if score >= 70 else 'WAIT_RETRACE'
        elif score >= self.shadow_min:
            decision, mode = 'SHADOW', 'LOW_SCORE'
        else:
            decision, mode = 'SKIP', 'BELOW_FLOOR'

        size_factor = self._size(score, f) if decision == 'TRADE' else 0.0
        stars = '★' * _clamp(int(score / 20) + 1, 1, 5)

        return {
            'score': score, 'stars': stars, 'decision': decision, 'mode': mode,
            'data_confidence': data_conf, 'rr': plan['rr'],
            'stop': plan['stop'], 'target': plan['target'],
            'risk_pct': plan['risk_pct'], 'size_factor': size_factor,
            'vetoes': ','.join(skip + vetoes),
            'factors': {**f, **ctx, 'btc_1h_pct': regime},
            'contributions': contribs,
        }


if __name__ == '__main__':
    # offline smoke test (no network -> context degrades, candle-only score)
    import numpy as np
    rng = np.random.default_rng(0)
    base = 100 + np.cumsum(rng.normal(0.2, 1, 60))
    df = pd.DataFrame({
        'open': base, 'high': base + abs(rng.normal(0, 1, 60)),
        'low': base - abs(rng.normal(0, 1, 60)), 'close': base + rng.normal(0, 0.5, 60),
        'volume': abs(rng.normal(1000, 200, 60)),
    })
    sc = PumpScorer()
    pump = {'current_price': float(df['close'].iloc[-1]), 'volume_ratios': [16.2, 19.1, 22.4]}
    res = {'4h': {'resistance': float(df['close'].iloc[-1]) * 1.08, 'gap': 8.0}}
    out = sc.evaluate('TEST/USDT:USDT', df, pump, res, fetch_context=False)
    print(json.dumps({k: v for k, v in out.items() if k != 'factors'}, indent=2))
    print('data_confidence (no network):', out['data_confidence'])
