"""
accumulation.py — detects the *accumulation* phase that often precedes a big
markup (the "spike-and-drop, spike-and-drop, then 10x" pattern).

This is intentionally a SLOW, background read on higher-timeframe data (4h), run
on a rotating subset of the universe so it never hammers the API. It produces a
0-100 accumulation score per coin that is used two ways:

  1. As a conviction MULTIPLIER on Bot 2's pump score — a pump breaking out of a
     real accumulation base is far more likely to be the start of the markup.
  2. As a separate WATCHLIST — coils setting up before any pump fires.

Honest caveat baked into the philosophy: accumulation only looks like
accumulation in hindsight. Most coils never break out. So this NEVER triggers a
trade on its own — it only amplifies a confirmed pump and populates a stalk list.
"""
import logging

import numpy as np
import pandas as pd

from pump_quality import _fapi_get, _fsym, _clamp

log = logging.getLogger('accumulation')


class AccumulationScanner:
    def __init__(self, cfg=None):
        c = cfg or {}
        self.tf = c.get('timeframe', '4h')
        self.bars = c.get('bars', 120)          # ~20 days of 4h candles
        self.min_quote_vol = c.get('min_quote_vol_24h', 300000)

    # -------------------------------------------------------------- helpers
    def _klines(self, s):
        k = _fapi_get('/fapi/v1/klines', {'symbol': s, 'interval': self.tf, 'limit': self.bars})
        if not k or len(k) < 40:
            return None
        df = pd.DataFrame(k, columns=['t', 'o', 'h', 'l', 'c', 'v', 'ct', 'qv', 'n', 'tb', 'tq', 'i'])
        for col in ['o', 'h', 'l', 'c', 'v', 'qv']:
            df[col] = df[col].astype(float)
        return df

    # -------------------------------------------------------------- signals
    def _squeeze(self, closes):
        """Volatility contraction: current Bollinger bandwidth in the low end of its
        own recent range = coiling. Returns 0..1 (1 = very tight)."""
        if len(closes) < 40:
            return None
        mid = closes.rolling(20).mean()
        std = closes.rolling(20).std()
        bw = (4 * std) / mid                       # (upper-lower)/mid
        bw = bw.dropna()
        if len(bw) < 20:
            return None
        now = bw.iloc[-1]
        pctile = float((bw < now).mean())          # where does current width rank
        return _clamp(1 - pctile, 0, 1)

    def _flat(self, closes):
        """Price rangebound / not yet marked up. Penalize coins that already ran."""
        if len(closes) < 20:
            return None
        drift = abs((closes.iloc[-1] - closes.iloc[-20]) / closes.iloc[-20])
        return _clamp(1 - drift / 0.25, 0, 1)      # <25% drift over ~3d = flattish

    def _oi_accumulation(self, s, price_change):
        """OI rising while price stays flat = positions building quietly."""
        oi = _fapi_get('/futures/data/openInterestHist', {'symbol': s, 'period': self.tf, 'limit': self.bars})
        if not oi or len(oi) < 10:
            return None, None
        try:
            a = float(oi[0]['sumOpenInterest']); b = float(oi[-1]['sumOpenInterest'])
            oi_change = (b - a) / a if a else 0
        except Exception:
            return None, None
        base = _clamp(oi_change / 0.4, 0, 1)               # +40% OI over window = strong
        damp = _clamp(1 - max(0, price_change) / 0.6, 0, 1)  # fade if price already ran >60%
        return round(_clamp(base * damp, 0, 1), 3), round(oi_change * 100, 1)

    def _absorption(self, s):
        """Persistent taker buying without price appreciation = demand absorbing supply."""
        tk = _fapi_get('/futures/data/takerlongshortRatio', {'symbol': s, 'period': self.tf, 'limit': 60})
        if not tk:
            return None
        try:
            ratios = [float(x['buySellRatio']) for x in tk]
            mean_r = sum(ratios) / len(ratios)
            return _clamp((mean_r - 0.95) / 0.3, 0, 1)
        except Exception:
            return None

    def _springs(self, df):
        """Count absorbed liquidity grabs: wick pierces support, closes back inside,
        on elevated volume = stop-hunt / spring (the 'spike-and-drop')."""
        try:
            support = df['l'].rolling(10).min().shift(1)
            vol_ma = df['v'].rolling(20).mean()
            pierced = df['l'] < support * 0.98
            reclaimed = df['c'] > support
            heavy = df['v'] > 1.5 * vol_ma
            count = int((pierced & reclaimed & heavy).sum())
            return _clamp(count / 4.0, 0, 1), count
        except Exception:
            return None, 0

    def _volume_dryup(self, df):
        """Volume contracting over the window = sellers exhausting (base building)."""
        try:
            v = df['v'].values
            half = len(v) // 2
            early = v[:half].mean(); late = v[half:].mean()
            if early <= 0:
                return None
            return _clamp((early - late) / early, 0, 1)
        except Exception:
            return None

    # -------------------------------------------------------------- score
    def score_symbol(self, symbol):
        s = _fsym(symbol)
        df = self._klines(s)
        if df is None:
            return None
        # liquidity gate (accumulation in illiquid names isn't tradeable)
        if df['qv'].tail(6).mean() < self.min_quote_vol:
            return None

        closes = df['c']
        price_change = float((closes.iloc[-1] - closes.iloc[0]) / closes.iloc[0])
        days = round(len(df) * 4 / 24, 1)

        squeeze = self._squeeze(closes)
        flat = self._flat(closes)
        oi_score, oi_change = self._oi_accumulation(s, price_change)
        absorption = self._absorption(s)
        springs_score, spring_count = self._springs(df)
        dryup = self._volume_dryup(df)

        parts = {
            'squeeze': (squeeze, 22),
            'oi_accum': (oi_score, 24),
            'absorption': (absorption, 16),
            'springs': (springs_score, 18),
            'volume_dryup': (dryup, 12),
            'flat': (flat, 8),
        }
        avail = {k: v for k, v in parts.items() if v[0] is not None}
        if not avail:
            return None
        total_w = sum(w for _, w in parts.values())
        avail_w = sum(w for _, w in avail.values())
        score01 = sum(v * w for v, w in avail.values()) / avail_w
        score = round(score01 * 100)
        data_conf = round(avail_w / total_w, 2)

        # human-readable label
        bits = [f"coiling {days:.0f}d"]
        if oi_change is not None:
            bits.append(f"OI {oi_change:+.0f}%")
        if spring_count:
            bits.append(f"{spring_count} springs")
        if dryup and dryup > 0.3:
            bits.append("vol drying up")
        label = " · ".join(bits)

        return {
            'score': score,
            'data_confidence': data_conf,
            'label': label,
            'price_change_pct': round(price_change * 100, 1),
            'oi_change_pct': oi_change,
            'spring_count': spring_count,
            'signals': {k: round(v, 2) for k, (v, _) in avail.items()},
        }


if __name__ == '__main__':
    # offline sanity check of the math on synthetic data (no network)
    sc = AccumulationScanner()
    n = 120
    # a coiling base: flat price, contracting volatility, a couple of springs
    rng = np.random.default_rng(0)
    price = 1.0 + np.cumsum(rng.normal(0, 0.004, n))   # nearly flat
    vol = np.linspace(1000, 400, n) + rng.normal(0, 50, n)  # drying up
    df = pd.DataFrame({'o': price, 'h': price + 0.01, 'l': price - 0.01,
                       'c': price, 'v': vol})
    print("squeeze:", sc._squeeze(df['c']))
    print("flat:", sc._flat(df['c']))
    print("dryup:", sc._volume_dryup(df))
    print("springs:", sc._springs(df))
