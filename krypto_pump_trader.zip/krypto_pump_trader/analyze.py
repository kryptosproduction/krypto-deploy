#!/usr/bin/env python3
"""
analyze.py — turn Bot 2's trade log into the decisions that tune it.

Reads pump_trades.csv (the local file the bot writes on every exit) and prints
the tables a quant actually uses:

  • overall expectancy, profit factor, max drawdown
  • expectancy BY SCORE BUCKET   -> where to set MIN_SCORE_TO_TRADE
  • traded vs SHADOW             -> is the score gate adding value?
  • WITH vs WITHOUT accum base   -> does the accumulation boost improve results?
  • MFE / MAE                    -> are stops too wide / targets too far?
  • exit-reason mix              -> is exit management behaving?

Usage:  python3 analyze.py [path/to/pump_trades.csv]
Nothing here is real below ~30 trades — it will say so.
"""
import sys
import csv
import math
from collections import defaultdict

PATH = sys.argv[1] if len(sys.argv) > 1 else 'pump_trades.csv'


def f(x, d=0.0):
    try:
        if x in (None, '', 'None'):
            return d
        return float(x)
    except (ValueError, TypeError):
        return d


def load(path):
    try:
        with open(path, newline='') as fh:
            rows = [r for r in csv.DictReader(fh) if (r.get('event') or '').upper() == 'EXIT']
    except FileNotFoundError:
        print(f"!! {path} not found. Run this where the bot writes pump_trades.csv "
              f"(the bot's folder on the VM).")
        sys.exit(1)
    for r in rows:
        r['_pnl'] = f(r.get('pnl_pct'))
        r['_net'] = f(r.get('net_pnl_pct'), f(r.get('pnl_pct')))
        r['_r'] = f(r.get('r_multiple'))
        r['_netr'] = f(r.get('net_r_multiple'), f(r.get('r_multiple')))
        r['_score'] = f(r.get('score'))
        r['_acc'] = f(r.get('acc_score'))
        r['_mfe'] = f(r.get('peak_pnl_pct'))
        r['_mae'] = f(r.get('trough_pnl_pct'))
        r['_shadow'] = str(r.get('is_shadow')).lower() in ('true', '1')
    return rows


def metrics(rows):
    n = len(rows)
    if n == 0:
        return None
    pnls = [r['_pnl'] for r in rows]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]
    gw = sum(wins); gl = abs(sum(losses))
    rs = [r['_r'] for r in rows if r['_r'] != 0]
    # max drawdown on the cumulative curve
    cum = peak = dd = 0.0
    for p in pnls:
        cum += p; peak = max(peak, cum); dd = max(dd, peak - cum)
    return {
        'n': n,
        'win_rate': len(wins) / n * 100,
        'avg_pnl': sum(pnls) / n,
        'expectancy_R': (sum(rs) / len(rs)) if rs else float('nan'),
        'profit_factor': (gw / gl) if gl else float('inf'),
        'avg_win': (gw / len(wins)) if wins else 0,
        'avg_loss': (sum(losses) / len(losses)) if losses else 0,
        'max_dd': dd,
        'total_pnl': sum(pnls),
    }


def line(label, m, width=22):
    if not m:
        print(f"  {label:<{width}} (no trades)")
        return
    ev = m['expectancy_R']
    ev_s = f"{ev:+.2f}R" if not math.isnan(ev) else "  n/a"
    flag = ''
    if not math.isnan(ev):
        flag = '  <= positive' if ev > 0 else '  <= negative'
    print(f"  {label:<{width}} n={m['n']:<4} win={m['win_rate']:4.0f}%  "
          f"avgPnL={m['avg_pnl']:+5.2f}%  PF={m['profit_factor']:4.2f}  EV={ev_s}{flag}")


def header(t):
    print('\n' + t)
    print('-' * 78)


def gatekeeper_analysis(real):
    """For each logged raw factor, split trades into low/mid/high buckets by that
    factor's value and show win rate + expectancy per bucket. A factor whose WORST
    bucket is both well-populated and sharply losing is a GATEKEEPER CANDIDATE:
    better used as a hard veto than as soft points the score can override."""
    header("FACTOR GATEKEEPER ANALYSIS  -> which factors should become hard gates?")
    if len(real) < 40:
        print("  Need ~40+ real trades for this to mean anything; keep collecting.")
        return

    # factors worth testing (raw readings logged per trade). Direction note tells
    # you which end is *expected* to be good, for interpreting the buckets.
    factors = [
        ('score', 'higher better'), ('acc_score', 'higher better'),
        ('rsi', 'mid best (~55-70)'), ('ext_atr', 'lower better (less extended)'),
        ('oi_change_pct', 'higher better'), ('oi_zscore', 'higher better'),
        ('funding', 'lower better (less crowded)'), ('taker_ratio', 'higher better'),
        ('top_trader_ls', 'higher better'), ('global_ls', 'lower better (less retail-crowded)'),
        ('btc_1h_pct', 'higher better'), ('short_liq_ratio', 'lower better (organic > squeeze)'),
        ('basis_pct', 'lower better (less froth)'), ('sym_1h_pct', 'higher better (rel strength)'),
        ('cvd_slope', 'higher better (real buying)'),
    ]
    flagged = []
    for name, note in factors:
        vals = [(f(r.get(name)), r['_pnl']) for r in real if r.get(name) not in (None, '', 'None')]
        if len(vals) < 30:
            continue
        vals.sort(key=lambda x: x[0])
        n = len(vals); third = n // 3
        buckets = [('low ', vals[:third]), ('mid ', vals[third:2 * third]), ('high', vals[2 * third:])]
        stats_line, wr_by = [], {}
        for label, seg in buckets:
            if not seg:
                continue
            wins = sum(1 for _, p in seg if p > 0)
            wr = wins / len(seg) * 100
            avg = sum(p for _, p in seg) / len(seg)
            lo, hi = seg[0][0], seg[-1][0]
            wr_by[label.strip()] = (wr, avg, len(seg))
            stats_line.append(f"{label} [{lo:+.3g}..{hi:+.3g}] win={wr:3.0f}% avg={avg:+4.1f}%")
        print(f"\n  {name}  ({note})")
        for s in stats_line:
            print(f"      {s}")
        # gatekeeper test: does the worst bucket lose badly while another wins?
        if len(wr_by) == 3:
            worst = min(wr_by.values(), key=lambda v: v[1])   # by avg pnl
            best = max(wr_by.values(), key=lambda v: v[1])
            spread = best[1] - worst[1]
            if worst[1] < 0 and best[1] > 0 and spread > 4 and worst[2] >= 10:
                worst_label = [k for k, v in wr_by.items() if v == worst][0]
                flagged.append((name, worst_label, worst[1], best[1]))
                print(f"      >> GATEKEEPER CANDIDATE: the '{worst_label}' bucket is "
                      f"net-losing ({worst[1]:+.1f}%) while another wins ({best[1]:+.1f}%).")
                print(f"         Consider VETOING trades in that range instead of just scoring them.")

    if flagged:
        print("\n  SUMMARY — promote these from score to gate (most predictive first):")
        for name, lbl, w, b in sorted(flagged, key=lambda x: x[2]):
            print(f"    • {name}: veto the '{lbl}' range  (that bucket {w:+.1f}% vs best {b:+.1f}%)")
    else:
        print("\n  No clear gatekeeper yet — every factor still contributes softly. Keep collecting.")


def main():
    rows = load(PATH)
    real = [r for r in rows if not r['_shadow']]
    shadow = [r for r in rows if r['_shadow']]

    print('=' * 78)
    print(f" KryptoSniper Bot 2 — trade analysis  ({PATH})")
    print('=' * 78)
    print(f" {len(rows)} closed trades  |  {len(real)} traded  |  {len(shadow)} shadow")
    if len(rows) < 30:
        print(" ** small sample — treat everything below as directional, not real, "
              "until ~100+ trades. **")

    header("OVERALL (real trades)")
    line('all real', metrics(real))

    header("GROSS vs NET — the go/no-go for real capital")
    if real:
        g_ev = sum(r['_r'] for r in real if r['_r']) / max(1, len([r for r in real if r['_r']]))
        n_ev = sum(r['_netr'] for r in real if r['_netr']) / max(1, len([r for r in real if r['_netr']]))
        g_pnl = sum(r['_pnl'] for r in real) / len(real)
        n_pnl = sum(r['_net'] for r in real) / len(real)
        print(f"  gross:  avgPnL={g_pnl:+5.2f}%   EV={g_ev:+.2f}R")
        print(f"  net:    avgPnL={n_pnl:+5.2f}%   EV={n_ev:+.2f}R   (after est. fees + slippage)")
        if n_ev > 0.1:
            print("  -> NET expectancy is positive: the edge survives estimated costs.")
        elif n_ev > 0:
            print("  -> NET expectancy is barely positive: thin edge, do not size up yet.")
        else:
            print("  -> NET expectancy is NEGATIVE: costs eat the edge. Do NOT go live as-is.")
    else:
        print("  (no real trades yet)")

    # watchlist outcomes (does the accumulation engine itself work?)
    import os
    wl_path = os.path.join(os.path.dirname(os.path.abspath(PATH)) or '.', 'watchlist_outcomes.csv')
    if os.path.exists(wl_path):
        header("WATCHLIST OUTCOMES — does the accumulation engine find real coils?")
        with open(wl_path, newline='') as fh:
            wrows = list(csv.DictReader(fh))
        n = len(wrows)
        br = [w for w in wrows if w.get('outcome') == 'BREAKOUT']
        if n:
            print(f"  resolved coils: {n}   breakouts: {len(br)} ({len(br)/n*100:.0f}%)   "
                  f"faded/expired: {n-len(br)}")
            if br:
                avg_d = sum(f(w.get('days_stalked')) for w in br) / len(br)
                print(f"  avg stalk time before breakout: {avg_d:.1f} days")
            print("  A meaningful breakout rate (vs base rate of random coins pumping) is the")
            print("  evidence the watchlist deserves attention; if it's ~random, retune ACC thresholds.")


    header("EXPECTANCY BY SCORE BUCKET (real trades)  -> sets MIN_SCORE_TO_TRADE")
    bands = [('45-58 (shadow band)', 45, 58), ('58-70', 58, 70), ('70-80', 70, 80), ('80+', 80, 999)]
    for label, lo, hi in bands:
        seg = [r for r in real if lo <= r['_score'] < hi]
        line(label, metrics(seg))
    print("  Rule of thumb: raise the trade threshold to where EV turns clearly positive.")

    header("DOES THE GATE ADD VALUE?  traded vs shadow")
    line('traded (score>=58)', metrics(real))
    line('shadow (45-58)', metrics(shadow))
    print("  If shadow EV ~= traded EV, the gate isn't separating winners — move the line.")

    header("DOES THE ACCUMULATION BOOST HELP?  with-base vs without")
    with_acc = [r for r in real if r['_acc'] >= 60]
    no_acc = [r for r in real if r['_acc'] < 60]
    line('pump + accum base', metrics(with_acc))
    line('pump, no base', metrics(no_acc))
    print("  If 'with base' EV beats 'no base', the accumulation multiplier is earning its keep.")

    header("MFE / MAE  -> are stops too wide / targets too far?")
    for label, seg in (('winners', [r for r in real if r['_pnl'] > 0]),
                       ('losers', [r for r in real if r['_pnl'] <= 0])):
        if seg:
            mfe = sum(r['_mfe'] for r in seg) / len(seg)
            mae = sum(r['_mae'] for r in seg) / len(seg)
            print(f"  {label:<10} n={len(seg):<4} avg MFE(peak)={mfe:+5.2f}%   avg MAE(dip)={mae:+5.2f}%")
    print("  Losers with tiny MAE before stopping = stops too tight. Winners with big MFE")
    print("  vs realized P&L = targets too far / trail too loose.")

    header("EXIT REASON MIX (real trades)")
    by_reason = defaultdict(list)
    for r in real:
        by_reason[(r.get('exit_reason') or '?')].append(r['_pnl'])
    for reason, pnls in sorted(by_reason.items(), key=lambda kv: -len(kv[1])):
        avg = sum(pnls) / len(pnls)
        print(f"  {reason:<14} n={len(pnls):<4} avg={avg:+5.2f}%")

    header("BY STRATEGY (real trades)")
    by_strat = defaultdict(list)
    for r in real:
        by_strat[r.get('strategy', '?')].append(r)
    for strat, rows in sorted(by_strat.items(), key=lambda kv: -len(kv[1])):
        wins = sum(1 for r in rows if r['_pnl'] > 0)
        wr = wins / len(rows) * 100 if rows else 0
        pnl = sum(r['_pnl'] for r in rows)
        net = sum(r.get('_net', r['_pnl']) for r in rows)
        avg = pnl / len(rows) if rows else 0
        nice = 'Pump Breakout' if strat == 'PUMP_BREAKOUT' else ('Golden Pocket' if strat == 'GOLDEN_POCKET' else strat)
        print(f"  {nice:<16} n={len(rows):<4} win={wr:4.0f}%  avg={avg:+5.2f}%  "
              f"gross={pnl:+7.1f}%  net={net:+7.1f}%")

    gatekeeper_analysis(real)

    print('\n' + '=' * 78)
    print(" Tune the constants at the top of krypto_pump_trader.py from these tables,")
    print(" then let the shadow group keep validating the new boundary. Re-run weekly.")
    print('=' * 78)


if __name__ == '__main__':
    main()
