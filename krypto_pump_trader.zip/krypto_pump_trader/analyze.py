#!/usr/bin/env python3
"""
analyze.py — turn Bot 2's trade log into the decisions that tune it.

Reads pump_trades.csv (the local file the bot writes on every exit) and prints
the tables a quant actually uses:

  • overall expectancy, profit factor, max drawdown
  • expectancy BY SCORE BUCKET   -> where to set MIN_SCORE_TO_TRADE
  • traded vs SHADOW             -> is the score gate adding value?
  • WITH vs WITHOUT accum base   -> does the accumulation boost improve results?
  • MFE / MAE                    -> are stops too wide / targets too far?
  • exit-reason mix              -> is exit management behaving?

Usage:  python3 analyze.py [path/to/pump_trades.csv]
Nothing here is real below ~30 trades — it will say so.
"""
import sys
import csv
import math
from collections import defaultdict

PATH = sys.argv[1] if len(sys.argv) > 1 else 'pump_trades.csv'


def f(x, d=0.0):
    try:
        if x in (None, '', 'None'):
            return d
        return float(x)
    except (ValueError, TypeError):
        return d


def load(path):
    try:
        with open(path, newline='') as fh:
            rows = [r for r in csv.DictReader(fh) if (r.get('event') or '').upper() == 'EXIT']
    except FileNotFoundError:
        print(f"!! {path} not found. Run this where the bot writes pump_trades.csv "
              f"(the bot's folder on the VM).")
        sys.exit(1)
    for r in rows:
        r['_pnl'] = f(r.get('pnl_pct'))
        r['_net'] = f(r.get('net_pnl_pct'), f(r.get('pnl_pct')))
        r['_r'] = f(r.get('r_multiple'))
        r['_netr'] = f(r.get('net_r_multiple'), f(r.get('r_multiple')))
        r['_score'] = f(r.get('score'))
        r['_acc'] = f(r.get('acc_score'))
        r['_mfe'] = f(r.get('peak_pnl_pct'))
        r['_mae'] = f(r.get('trough_pnl_pct'))
        r['_shadow'] = str(r.get('is_shadow')).lower() in ('true', '1')
    return rows


def metrics(rows):
    n = len(rows)
    if n == 0:
        return None
    pnls = [r['_pnl'] for r in rows]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p <= 0]
    gw = sum(wins); gl = abs(sum(losses))
    rs = [r['_r'] for r in rows if r['_r'] != 0]
    # max drawdown on the cumulative curve
    cum = peak = dd = 0.0
    for p in pnls:
        cum += p; peak = max(peak, cum); dd = max(dd, peak - cum)
    return {
        'n': n,
        'win_rate': len(wins) / n * 100,
        'avg_pnl': sum(pnls) / n,
        'expectancy_R': (sum(rs) / len(rs)) if rs else float('nan'),
        'profit_factor': (gw / gl) if gl else float('inf'),
        'avg_win': (gw / len(wins)) if wins else 0,
        'avg_loss': (sum(losses) / len(losses)) if losses else 0,
        'max_dd': dd,
        'total_pnl': sum(pnls),
    }


def line(label, m, width=22):
    if not m:
        print(f"  {label:<{width}} (no trades)")
        return
    ev = m['expectancy_R']
    ev_s = f"{ev:+.2f}R" if not math.isnan(ev) else "  n/a"
    flag = ''
    if not math.isnan(ev):
        flag = '  <= positive' if ev > 0 else '  <= negative'
    print(f"  {label:<{width}} n={m['n']:<4} win={m['win_rate']:4.0f}%  "
          f"avgPnL={m['avg_pnl']:+5.2f}%  PF={m['profit_factor']:4.2f}  EV={ev_s}{flag}")


def header(t):
    print('\n' + t)
    print('-' * 78)


def fib_level_analysis(rows):
    """For Golden Pocket trades, bucket by the actual retrace level where the bounce
    happened (fib_level) and show win rate per band. Answers: is the 0.618–0.65
    golden pocket really the best entry zone, or do bounces pay better elsewhere?"""
    gp = [r for r in rows if r.get('strategy') == 'GOLDEN_POCKET'
          and (r.get('event') or '').upper() == 'EXIT' and r.get('fib_level') not in (None, '', 'None')]
    if len(gp) < 8:
        return
    header("FIB RETRACE — which level bounces best? (trading 0.786, tracking all)")
    bands = [('shallow <0.5', 0, 0.5), ('0.5–0.618', 0.5, 0.618),
             ('pocket 0.618–0.65', 0.618, 0.65), ('0.65–0.75', 0.65, 0.75),
             ('TRADED 0.75–0.786', 0.75, 0.8), ('very deep >0.8', 0.8, 99)]
    for name, lo, hi in bands:
        seg = [r for r in gp if lo <= f(r.get('fib_level')) < hi]
        if not seg:
            continue
        wins = sum(1 for r in seg if r['_pnl'] > 0)
        avg = sum(r['_pnl'] for r in seg) / len(seg)
        print(f"  {name:<20} n={len(seg):<3} win={wins/len(seg)*100:3.0f}%  avg={avg:+5.2f}%")
    print("  -> you're trading the 0.786 band. If a shallower band (e.g. the 0.618–0.65")
    print("     pocket) wins more, shift FIB_ENTRY_LOW/HIGH toward it.")


def rr_by_strategy(rows):
    """For each strategy, bucket trades by their ENTRY R:R and show win rate +
    expectancy per bucket. Answers: does this strategy want higher or lower R:R?
    A momentum strategy should win more at high R:R; a reversion strategy may make
    most of its money at low R:R + high win rate."""
    header("R:R BY STRATEGY  -> should each strategy push for higher or lower R:R?")
    exits = [r for r in rows if (r.get('event') or '').upper() == 'EXIT']
    by_strat = defaultdict(list)
    for r in exits:
        by_strat[r.get('strategy', '?')].append(r)
    for strat, rs in sorted(by_strat.items()):
        nice = {'PUMP_BREAKOUT': 'Pump Breakout', 'GOLDEN_POCKET': 'Golden Pocket',
                'SHORT_REVERSION': 'Short Reversion'}.get(strat, strat)
        vals = [(f(r.get('rr')), r['_pnl'], r.get('_net', r['_pnl'])) for r in rs
                if r.get('rr') not in (None, '', 'None')]
        n = len(vals)
        if n < 6:
            print(f"\n  {nice}: {len(rs)} trades ({n} with R:R logged) — too few to bucket yet.")
            continue
        wins = sum(1 for _, p, _ in vals if p > 0)
        wr = wins / n * 100
        avg_rr = sum(v[0] for v in vals) / n
        exp = sum(v[1] for v in vals) / n
        print(f"\n  {nice}: {n} trades · {wr:.0f}% win · avg entry R:R {avg_rr:.2f} · "
              f"expectancy {exp:+.2f}%/trade")
        vals.sort()
        third = max(1, n // 3)
        for label, seg in [('low R:R ', vals[:third]), ('mid R:R ', vals[third:2*third]),
                           ('high R:R', vals[2*third:])]:
            if not seg:
                continue
            sw = sum(1 for _, p, _ in seg if p > 0)
            print(f"     {label} [{seg[0][0]:.1f}–{seg[-1][0]:.1f}]  "
                  f"win={sw/len(seg)*100:3.0f}%  avg P&L={sum(s[1] for s in seg)/len(seg):+5.2f}%  (n={len(seg)})")
        print(f"     -> if win% holds as R:R rises, push targets higher; if win% "
              f"collapses, this strategy lives on low-R:R/high-win.")


def pocket_rebound_analysis(rows):
    """Tune the Pocket Rebound scalp from data. Answers the key questions:
    - Is the stop too tight? (do stopped trades show the bounce came right after?)
    - Does the bounce reach the 0.65 pocket, or stall earlier?
    - Does a coinciding higher-TF support improve the bounce?"""
    pr = [r for r in rows if r.get('strategy') == 'POCKET_REBOUND'
          and (r.get('event') or '').upper() == 'EXIT']
    if len(pr) < 6:
        if pr:
            print(f"\n  Pocket Rebound: {len(pr)} trades — need ~6+ to analyze.")
        return
    header("POCKET REBOUND — tuning the bounce snipe")
    n = len(pr)
    wins = [r for r in pr if r['_pnl'] > 0]
    wr = len(wins) / n * 100
    print(f"  {n} trades · {wr:.0f}% win · avg {sum(r['_pnl'] for r in pr)/n:+.2f}%")

    # 1) IS THE STOP TOO TIGHT? For stopped-out losers, how deep did price go before
    #    the candle that stopped us — and did winners survive a deep dip first?
    stopped = [r for r in pr if 'STOP' in (r.get('exit_reason') or '').upper()]
    print(f"\n  Stop-outs: {len(stopped)}/{n} ({len(stopped)/n*100:.0f}%)")
    if wins:
        worst_dips = [f(w.get('trough_pnl_pct')) for w in wins if w.get('trough_pnl_pct') not in (None, '', 'None')]
        if worst_dips:
            avg_dip = sum(worst_dips) / len(worst_dips)
            print(f"  Winners' avg worst dip before winning: {avg_dip:.2f}%")
            print(f"    -> if winners routinely dip close to the stop before recovering,")
            print(f"       the stop is too tight; widen REBOUND_STOP_FIB toward 0.88.")

    # 2) DOES THE BOUNCE REACH THE POCKET? Look at winners' peak vs the target.
    if wins:
        peaks = [f(w.get('peak_pnl_pct')) for w in wins if w.get('peak_pnl_pct') not in (None, '', 'None')]
        if peaks:
            print(f"\n  Winners' avg peak reach: +{sum(peaks)/len(peaks):.2f}%")
            print(f"    -> if peaks routinely exceed the target, the bounce runs further")
            print(f"       than 0.65; push REBOUND_TARGET_FIB toward 0.618 or lower.")

    # 3) HTF SUPPORT EFFECT: split by whether a 4h/1d support coincided (from notes).
    with_htf = [r for r in pr if 'htf_support=yes' in (r.get('notes') or '')]
    without = [r for r in pr if 'htf_support=no' in (r.get('notes') or '')]
    if with_htf and without:
        w_wr = sum(1 for r in with_htf if r['_pnl'] > 0) / len(with_htf) * 100
        wo_wr = sum(1 for r in without if r['_pnl'] > 0) / len(without) * 100
        print(f"\n  Bounce AT a higher-TF support: {w_wr:.0f}% win (n={len(with_htf)})")
        print(f"  Bounce with NO HTF support:    {wo_wr:.0f}% win (n={len(without)})")
        print(f"    -> if HTF-backed bounces win much more, require near_htf_support=True")
        print(f"       as an entry filter (the bounce respects bigger structure).")

    # 4) ENTRY DEPTH: which exact retrace filled best?
    by_depth = [('0.75-0.78', 0.75, 0.78), ('0.78-0.80', 0.78, 0.801)]
    print()
    for label, lo, hi in by_depth:
        seg = [r for r in pr if lo <= f(r.get('fib_level')) < hi]
        if seg:
            sw = sum(1 for r in seg if r['_pnl'] > 0)
            print(f"  entry {label}: {sw}/{len(seg)} win ({sw/len(seg)*100:.0f}%)")


def wall_reject_analysis(rows):
    """Tune the Wall Reject short from data. Answers:
    - Are we getting stopped out early? (MAE on winners vs the stop distance)
    - Where's the best take-profit? (how far the drop actually reached vs TP1/TP2)
    - Does the entry wick depth above resistance matter?
    - Does a coinciding higher-TF resistance improve the short?"""
    wr = [r for r in rows if r.get('strategy') == 'WALL_REJECT'
          and (r.get('event') or '').upper() == 'EXIT']
    if len(wr) < 6:
        if wr:
            print(f"\n  Wall Reject: {len(wr)} trades — need ~6+ to analyze.")
        return
    header("WALL REJECT — tuning the resistance-rejection short")
    n = len(wr); wins = [r for r in wr if r['_pnl'] > 0]
    print(f"  {n} trades · {len(wins)/n*100:.0f}% win · avg {sum(r['_pnl'] for r in wr)/n:+.2f}%")

    # 1) ARE WE STOPPED OUT EARLY? For winners, how far did price go AGAINST us (up)
    #    before working? If winners routinely spike near the stop first, stop's tight.
    if wins:
        adverse = [f(w.get('peak_pnl_pct')) for w in wins if w.get('peak_pnl_pct') not in (None,'','None')]
        # for a short, "peak_pnl_pct" adverse = how far price rose against us
        if adverse:
            print(f"\n  Winners' worst adverse move (toward stop): avg {sum(adverse)/len(adverse):.2f}%")
            print(f"    -> if winners often near the stop before dropping, widen WALL_STOP_ABOVE_PCT.")
    stopped = [r for r in wr if 'STOP' in (r.get('exit_reason') or '').upper()]
    print(f"  Stop-outs: {len(stopped)}/{n} ({len(stopped)/n*100:.0f}%)")

    # 2) WHERE'S THE BEST TP? How far did the drop actually reach (best favorable)?
    if wins:
        favs = [abs(f(w.get('trough_pnl_pct'))) for w in wins if w.get('trough_pnl_pct') not in (None,'','None')]
        if favs:
            print(f"\n  Winners' best favorable drop: avg {sum(favs)/len(favs):.2f}%")
            print(f"    -> compare to TP1/TP2 distances: if drops routinely exceed TP2,")
            print(f"       the move runs further; if they stall before TP1, pull targets in.")

    # 3) TP1 vs TP2 hit rate
    tp2_hits = [r for r in wr if 'TP2' in (r.get('notes') or '') or r.get('exit_reason')=='TARGET_HIT']
    print(f"\n  Reached TP2 (full target): {len(tp2_hits)}/{n}")

    # 4) entry wick depth: did shorting ABOVE resistance beat shorting AT it?
    above = [r for r in wr if f(r.get('wall_dist_at_entry_pct') or _dist_from_notes(r)) > 0]
    at_below = [r for r in wr if f(r.get('wall_dist_at_entry_pct') or _dist_from_notes(r)) <= 0]
    if above and at_below:
        aw = sum(1 for r in above if r['_pnl']>0)/len(above)*100
        bw = sum(1 for r in at_below if r['_pnl']>0)/len(at_below)*100
        print(f"\n  Entered ABOVE resistance (wick): {aw:.0f}% win (n={len(above)})")
        print(f"  Entered AT/below resistance:     {bw:.0f}% win (n={len(at_below)})")
        print(f"    -> tells you if the liquidation-wick entry actually helps.")


def _dist_from_notes(r):
    return 0


def short_optimization(rows):
    """For SHORT_REVERSION trades, bucket by 'short_dist_pct' (how far above EMA the
    short was taken) to find the threshold that actually pays — so the % over EMA can
    be tuned from data per timeframe."""
    shorts = [r for r in rows if r.get('side') == 'short' and (r.get('event') or '').upper() == 'EXIT']
    if not shorts:
        return
    header("SHORT REVERSION — optimize the % over EMA")
    if len(shorts) < 20:
        print(f"  Only {len(shorts)} short trades — need ~20+ per timeframe to tune. Keep collecting.")
    by_tf = defaultdict(list)
    for r in shorts:
        by_tf[r.get('short_tf', '?')].append(r)
    for tf, rs in sorted(by_tf.items()):
        vals = [(f(r.get('short_dist_pct')), r['_pnl']) for r in rs if r.get('short_dist_pct') not in (None, '', 'None')]
        if len(vals) < 6:
            print(f"  {tf}: {len(rs)} trades (too few to bucket)")
            continue
        vals.sort()
        n = len(vals); third = max(1, n // 3)
        print(f"  {tf} ({n} trades):")
        for label, seg in [('low ', vals[:third]), ('mid ', vals[third:2*third]), ('high', vals[2*third:])]:
            if not seg:
                continue
            wins = sum(1 for _, p in seg if p > 0)
            wr = wins / len(seg) * 100
            avg = sum(p for _, p in seg) / len(seg)
            print(f"     dist {label} [{seg[0][0]:.0f}%..{seg[-1][0]:.0f}%]  "
                  f"win={wr:3.0f}%  avg={avg:+5.2f}%  (n={len(seg)})")
        print(f"     -> if higher-distance buckets win more, raise the {tf} threshold.")


def factor_correlation(real):
    """Correlation between the raw factor readings. Factors that move together are
    secretly ONE factor with multiplied weight — hidden concentration that feels
    like diversification. Flags pairs with |r| > 0.7 so you can prune or down-weight."""
    header("FACTOR CORRELATION  -> are your factors secretly measuring the same thing?")
    cols = ['score', 'rsi', 'ext_atr', 'oi_change_pct', 'oi_zscore', 'funding',
            'taker_ratio', 'top_trader_ls', 'global_ls', 'btc_1h_pct', 'cvd_slope',
            'short_liq_ratio', 'liq_cascade', 'basis_pct', 'sym_1h_pct', 'btc_lead_15m',
            'acc_score']
    # collect aligned numeric series (only factors actually present with data)
    series = {}
    for c in cols:
        vals = [f(r.get(c)) for r in real if r.get(c) not in (None, '', 'None')]
        if len(vals) >= 20:
            series[c] = [f(r.get(c)) if r.get(c) not in (None, '', 'None') else None for r in real]
    names = list(series.keys())
    if len(names) < 2:
        print("  Not enough populated factors yet — keep collecting.")
        return

    def pearson(a, b):
        pairs = [(x, y) for x, y in zip(a, b) if x is not None and y is not None]
        if len(pairs) < 20:
            return None
        xs, ys = zip(*pairs)
        n = len(xs); mx = sum(xs) / n; my = sum(ys) / n
        cov = sum((x - mx) * (y - my) for x, y in pairs)
        vx = sum((x - mx) ** 2 for x in xs); vy = sum((y - my) ** 2 for y in ys)
        if vx <= 0 or vy <= 0:
            return None
        return cov / math.sqrt(vx * vy)

    flagged = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            r = pearson(series[names[i]], series[names[j]])
            if r is not None and abs(r) > 0.7:
                flagged.append((abs(r), names[i], names[j], r))
    if flagged:
        print("  Highly correlated pairs (|r| > 0.7) — these overlap, consider pruning one:")
        for _, a, b, r in sorted(flagged, reverse=True):
            print(f"    {a:16s} <-> {b:16s}  r = {r:+.2f}")
    else:
        print("  No factor pair exceeds |r|=0.7 — your factors are reasonably independent. Good.")
    print(f"  ({len(names)} factors had enough data to test.)")


def gatekeeper_analysis(real):
    """For each logged raw factor, split trades into low/mid/high buckets by that
    factor's value and show win rate + expectancy per bucket. A factor whose WORST
    bucket is both well-populated and sharply losing is a GATEKEEPER CANDIDATE:
    better used as a hard veto than as soft points the score can override."""
    header("FACTOR GATEKEEPER ANALYSIS  -> which factors should become hard gates?")
    if len(real) < 40:
        print("  Need ~40+ real trades for this to mean anything; keep collecting.")
        return

    # factors worth testing (raw readings logged per trade). Direction note tells
    # you which end is *expected* to be good, for interpreting the buckets.
    factors = [
        ('score', 'higher better'), ('acc_score', 'higher better'),
        ('rsi', 'mid best (~55-70)'), ('ext_atr', 'lower better (less extended)'),
        ('oi_change_pct', 'higher better'), ('oi_zscore', 'higher better'),
        ('funding', 'lower better (less crowded)'), ('taker_ratio', 'higher better'),
        ('top_trader_ls', 'higher better'), ('global_ls', 'lower better (less retail-crowded)'),
        ('btc_1h_pct', 'higher better'), ('short_liq_ratio', 'lower better (organic > squeeze)'),
        ('basis_pct', 'lower better (less froth)'), ('sym_1h_pct', 'higher better (rel strength)'),
        ('cvd_slope', 'higher better (real buying)'),
        ('btc_lead_15m', 'higher better (BTC tailwind)'),
        ('liq_cascade', 'higher better (active squeeze fuel)'),
    ]
    flagged = []
    for name, note in factors:
        vals = [(f(r.get(name)), r['_pnl']) for r in real if r.get(name) not in (None, '', 'None')]
        if len(vals) < 30:
            continue
        vals.sort(key=lambda x: x[0])
        n = len(vals); third = n // 3
        buckets = [('low ', vals[:third]), ('mid ', vals[third:2 * third]), ('high', vals[2 * third:])]
        stats_line, wr_by = [], {}
        for label, seg in buckets:
            if not seg:
                continue
            wins = sum(1 for _, p in seg if p > 0)
            wr = wins / len(seg) * 100
            avg = sum(p for _, p in seg) / len(seg)
            lo, hi = seg[0][0], seg[-1][0]
            wr_by[label.strip()] = (wr, avg, len(seg))
            stats_line.append(f"{label} [{lo:+.3g}..{hi:+.3g}] win={wr:3.0f}% avg={avg:+4.1f}%")
        print(f"\n  {name}  ({note})")
        for s in stats_line:
            print(f"      {s}")
        # gatekeeper test: does the worst bucket lose badly while another wins?
        if len(wr_by) == 3:
            worst = min(wr_by.values(), key=lambda v: v[1])   # by avg pnl
            best = max(wr_by.values(), key=lambda v: v[1])
            spread = best[1] - worst[1]
            if worst[1] < 0 and best[1] > 0 and spread > 4 and worst[2] >= 10:
                worst_label = [k for k, v in wr_by.items() if v == worst][0]
                flagged.append((name, worst_label, worst[1], best[1]))
                print(f"      >> GATEKEEPER CANDIDATE: the '{worst_label}' bucket is "
                      f"net-losing ({worst[1]:+.1f}%) while another wins ({best[1]:+.1f}%).")
                print(f"         Consider VETOING trades in that range instead of just scoring them.")

    if flagged:
        print("\n  SUMMARY — promote these from score to gate (most predictive first):")
        for name, lbl, w, b in sorted(flagged, key=lambda x: x[2]):
            print(f"    • {name}: veto the '{lbl}' range  (that bucket {w:+.1f}% vs best {b:+.1f}%)")
    else:
        print("\n  No clear gatekeeper yet — every factor still contributes softly. Keep collecting.")


def main():
    rows = load(PATH)
    real = [r for r in rows if not r['_shadow']]
    shadow = [r for r in rows if r['_shadow']]

    print('=' * 78)
    print(f" KryptoSniper Bot 2 — trade analysis  ({PATH})")
    print('=' * 78)
    print(f" {len(rows)} closed trades  |  {len(real)} traded  |  {len(shadow)} shadow")
    if len(rows) < 30:
        print(" ** small sample — treat everything below as directional, not real, "
              "until ~100+ trades. **")

    header("OVERALL (real trades)")
    line('all real', metrics(real))

    header("GROSS vs NET — the go/no-go for real capital")
    if real:
        g_ev = sum(r['_r'] for r in real if r['_r']) / max(1, len([r for r in real if r['_r']]))
        n_ev = sum(r['_netr'] for r in real if r['_netr']) / max(1, len([r for r in real if r['_netr']]))
        g_pnl = sum(r['_pnl'] for r in real) / len(real)
        n_pnl = sum(r['_net'] for r in real) / len(real)
        print(f"  gross:  avgPnL={g_pnl:+5.2f}%   EV={g_ev:+.2f}R")
        print(f"  net:    avgPnL={n_pnl:+5.2f}%   EV={n_ev:+.2f}R   (after est. fees + slippage)")
        if n_ev > 0.1:
            print("  -> NET expectancy is positive: the edge survives estimated costs.")
        elif n_ev > 0:
            print("  -> NET expectancy is barely positive: thin edge, do not size up yet.")
        else:
            print("  -> NET expectancy is NEGATIVE: costs eat the edge. Do NOT go live as-is.")
    else:
        print("  (no real trades yet)")

    # watchlist outcomes (does the accumulation engine itself work?)
    import os
    wl_path = os.path.join(os.path.dirname(os.path.abspath(PATH)) or '.', 'watchlist_outcomes.csv')
    if os.path.exists(wl_path):
        header("WATCHLIST OUTCOMES — does the accumulation engine find real coils?")
        with open(wl_path, newline='') as fh:
            wrows = list(csv.DictReader(fh))
        n = len(wrows)
        br = [w for w in wrows if w.get('outcome') == 'BREAKOUT']
        if n:
            print(f"  resolved coils: {n}   breakouts: {len(br)} ({len(br)/n*100:.0f}%)   "
                  f"faded/expired: {n-len(br)}")
            if br:
                avg_d = sum(f(w.get('days_stalked')) for w in br) / len(br)
                print(f"  avg stalk time before breakout: {avg_d:.1f} days")
            print("  A meaningful breakout rate (vs base rate of random coins pumping) is the")
            print("  evidence the watchlist deserves attention; if it's ~random, retune ACC thresholds.")


    header("EXPECTANCY BY SCORE BUCKET (real trades)  -> sets MIN_SCORE_TO_TRADE")
    bands = [('45-58 (shadow band)', 45, 58), ('58-70', 58, 70), ('70-80', 70, 80), ('80+', 80, 999)]
    for label, lo, hi in bands:
        seg = [r for r in real if lo <= r['_score'] < hi]
        line(label, metrics(seg))
    print("  Rule of thumb: raise the trade threshold to where EV turns clearly positive.")

    header("DOES THE GATE ADD VALUE?  traded vs shadow")
    line('traded (score>=58)', metrics(real))
    line('shadow (45-58)', metrics(shadow))
    print("  If shadow EV ~= traded EV, the gate isn't separating winners — move the line.")

    header("DOES THE ACCUMULATION BOOST HELP?  with-base vs without")
    with_acc = [r for r in real if r['_acc'] >= 60]
    no_acc = [r for r in real if r['_acc'] < 60]
    line('pump + accum base', metrics(with_acc))
    line('pump, no base', metrics(no_acc))
    print("  If 'with base' EV beats 'no base', the accumulation multiplier is earning its keep.")

    header("MFE / MAE  -> are stops too wide / targets too far?")
    for label, seg in (('winners', [r for r in real if r['_pnl'] > 0]),
                       ('losers', [r for r in real if r['_pnl'] <= 0])):
        if seg:
            mfe = sum(r['_mfe'] for r in seg) / len(seg)
            mae = sum(r['_mae'] for r in seg) / len(seg)
            print(f"  {label:<10} n={len(seg):<4} avg MFE(peak)={mfe:+5.2f}%   avg MAE(dip)={mae:+5.2f}%")
    print("  Losers with tiny MAE before stopping = stops too tight. Winners with big MFE")
    print("  vs realized P&L = targets too far / trail too loose.")

    header("EXIT REASON MIX (real trades)")
    by_reason = defaultdict(list)
    for r in real:
        by_reason[(r.get('exit_reason') or '?')].append(r['_pnl'])
    for reason, pnls in sorted(by_reason.items(), key=lambda kv: -len(kv[1])):
        avg = sum(pnls) / len(pnls)
        print(f"  {reason:<14} n={len(pnls):<4} avg={avg:+5.2f}%")

    header("BY STRATEGY (real trades)")
    by_strat = defaultdict(list)
    for r in real:
        by_strat[r.get('strategy', '?')].append(r)
    for strat, rows in sorted(by_strat.items(), key=lambda kv: -len(kv[1])):
        wins = sum(1 for r in rows if r['_pnl'] > 0)
        wr = wins / len(rows) * 100 if rows else 0
        pnl = sum(r['_pnl'] for r in rows)
        net = sum(r.get('_net', r['_pnl']) for r in rows)
        avg = pnl / len(rows) if rows else 0
        nice = 'Pump Breakout' if strat == 'PUMP_BREAKOUT' else ('Golden Pocket' if strat == 'GOLDEN_POCKET' else strat)
        print(f"  {nice:<16} n={len(rows):<4} win={wr:4.0f}%  avg={avg:+5.2f}%  "
              f"gross={pnl:+7.1f}%  net={net:+7.1f}%")

    # Factor-level analysis uses ALL tracked trades (real + shadow). Shadow trades
    # have outcomes too and aren't subject to the trade/skip selection bias, so they
    # are the cleaner sample for judging which factors actually predict winners.
    all_tracked = real + shadow
    print(f"\n  (factor analyses below use all {len(all_tracked)} tracked trades — "
          f"shadow included as unbiased control)")
    factor_correlation(all_tracked)
    gatekeeper_analysis(all_tracked)
    rr_by_strategy(rows)
    fib_level_analysis(rows)
    pocket_rebound_analysis(rows)
    wall_reject_analysis(rows)
    short_optimization(rows)

    print('\n' + '=' * 78)
    print(" Tune the constants at the top of krypto_pump_trader.py from these tables,")
    print(" then let the shadow group keep validating the new boundary. Re-run weekly.")
    print('=' * 78)


if __name__ == '__main__':
    main()
