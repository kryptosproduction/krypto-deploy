// ============================================================================
// KryptoPumpTrader — Google Sheet webhook
// ----------------------------------------------------------------------------
// 1. Create a new Google Sheet.
// 2. Extensions > Apps Script. Delete everything, paste this in.
// 3. Deploy > New deployment > type "Web app".
//      - Execute as: Me
//      - Who has access: Anyone
// 4. Copy the Web App URL and paste it into SHEET_WEBHOOK_URL in the Python file.
// ============================================================================

var HEADERS = [
  'event', 'trade_id', 'timestamp', 'symbol', 'strategy',
  'entry_price', 'exit_price', 'target_price', 'stop_loss', 'exit_reason',
  'pnl_pct', 'net_pnl_pct', 'r_multiple', 'net_r_multiple', 'weighted_pnl_pct',
  'hold_minutes', 'peak_price', 'peak_pnl_pct', 'trough_price', 'trough_pnl_pct',
  'resistance_4h', 'gap_4h_pct', 'resistance_1d', 'gap_1d_pct',
  'volume_ratios', 'volume_vs_macd', 'body_ratio',
  'pump_high', 'local_low', 'fib_level', 'notes',
  // quant scoring + decision
  'score', 'stars', 'rr', 'mode', 'data_confidence', 'is_shadow',
  'size_factor', 'risk_pct', 'vetoes', 'acc_score', 'acc_label',
  // raw factor readings (so we can mine which ones predict winners)
  'atr_pct', 'rsi', 'ext_atr', 'consec_green', 'oi_change_pct', 'funding',
  'taker_ratio', 'top_trader_ls', 'btc_1h_pct',
  // per-factor weighted contributions, pipe-joined (e.g. taker:12.6|oi:9.1|...)
  'contributions'
];

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
    var data = JSON.parse(e.postData.contents);

    // Write the header row once.
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(HEADERS);
    }

    // Self-healing: if the bot ever sends a NEW field we don't have a column for,
    // append it to the header automatically so data is never silently dropped.
    var header = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    var changed = false;
    Object.keys(data).forEach(function (k) {
      if (header.indexOf(k) === -1) { header.push(k); changed = true; }
    });
    if (changed) {
      sheet.getRange(1, 1, 1, header.length).setValues([header]);
    }

    // Map the row to the (possibly extended) live header order.
    var row = header.map(function (h) {
      return data[h] !== undefined ? data[h] : '';
    });
    sheet.appendRow(row);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService.createTextOutput('KryptoPumpTrader webhook is live.');
}
