# Accumulation Engine & Watchlist

Detects the *accumulation* phase that precedes a big markup — the
"spike-and-drop, spike-and-drop, then 10x" pattern — and uses it two ways.

## Why it's a separate background engine (not part of the pump scorer)

Pump detection is reactive and fast (a 1-minute event). Accumulation is slow and
continuous — it needs hours-to-weeks of history per coin and scans the whole
universe looking for coils. Bolting that onto every pump check would be slow and
mostly wasted. So it runs as its **own background loop** that rotates through the
universe in chunks (`ACC_SCAN_CHUNK` symbols every `ACC_SCAN_INTERVAL` seconds),
scores each coin, and writes a cache (`accumulation.json`). Nothing in the fast
pump path waits on it — the pump path just does a dict lookup.

This bounds API load: each coin is re-scored at most every `ACC_REFRESH_HOURS`,
and a full universe sweep is spread over many cycles. Accumulation moves slowly,
so a ~1–2 hour-old read is fine.

## The accumulation score (0–100), on 4h data

Each coil is scored from footprints that *tilt the odds* (they don't predict —
see the caveat):

| Signal | Weight | Reads |
|---|---|---|
| `oi_accum` | 24 | OI rising while price stays flat = positions building quietly |
| `squeeze` | 22 | Bollinger bandwidth in the low end of its range = coiling |
| `springs` | 18 | Wicks that pierce support and reclaim on volume = absorbed stop-hunts |
| `absorption` | 16 | Persistent taker buying without price appreciation |
| `volume_dryup` | 12 | Volume contracting = sellers exhausting |
| `flat` | 8 | Price not yet marked up (penalizes coins that already ran) |

Missing data redistributes its weight (adaptive weighting), and `data_confidence`
records how complete the read was — same philosophy as the pump scorer. There's a
liquidity floor so we don't stalk illiquid names.

## Use 1 — conviction multiplier on a confirmed pump

When a pump fires, Bot 2 looks up the coin's cached accumulation score (no API
call) and, if it's `>= ACC_BOOST_MIN`:

- **Sizes up** — up to `+ACC_SIZE_BONUS` (60%) more size at a max base.
- **Bonus pump-score points** — up to `+ACC_SCORE_BONUS` (12).
- **Borderline upgrade** — a base strong enough can lift a *borderline* shadow
  (within `ACC_UPGRADE_WINDOW` of the trade threshold) into a real trade. Deep
  shadows are never upgraded — accumulation amplifies a valid setup, it doesn't
  rescue junk.

The thesis: a pump breaking out of a real accumulation base is far more likely to
be the start of the markup (the VELVET-style 10x) than a one-off spike that fades.
You still enter on the confirmed pump (high precision) but lean into the ones with
a real base behind them. Every trade logs its `acc_score` so this can be validated
against the shadow group later.

## Use 2 — the watchlist (the stalk list)

Any coil crossing `WATCHLIST_ADD` (70) joins `watchlist.json` and fires a Telegram
alert:

```
👁 STALKING — accumulation 👁
Pair: VELVETUSDT
Accumulation score: 78/100
Read: coiling 16d · OI +42% · 3 springs
Setting up — not a trade. If it pumps, the breakout gets boosted conviction.
```

The list is maintained automatically: a coil drops off below `WATCHLIST_DROP`,
auto-expires after `WATCHLIST_MAX_AGE_H`, and — the satisfying part — when a
watched coil finally pumps, it's resolved with a **breakout** alert and traded with
the boosted conviction from Use 1. A periodic digest lists the strongest coils.

## The honest caveat (why this never trades on its own)

Accumulation only looks like accumulation in hindsight. For every coil that breaks
out, many just chop and die — and in real time they look identical. So this engine
**never triggers a trade by itself**. It only amplifies a confirmed pump and
populates a stalk list you watch. That keeps the precision of the breakout trigger
while leaning into the setups with a real base. Treat the watchlist as a
positive-skew lottery, not a portfolio.

## Config (top of `krypto_pump_trader.py`)

| Setting | Default | Controls |
|---|---|---|
| `ACC_SCAN_CHUNK` / `ACC_SCAN_INTERVAL` | 40 / 180s | Background scan rate |
| `ACC_REFRESH_HOURS` | 2 | Per-coin re-score interval |
| `ACC_BOOST_MIN` | 60 | Score at which a pump gets boosted |
| `ACC_SIZE_BONUS` / `ACC_SCORE_BONUS` | 0.6 / 12 | Boost strength |
| `ACC_CAN_UPGRADE` / `ACC_UPGRADE_WINDOW` | on / 8 | Borderline shadow→trade |
| `WATCHLIST_ADD` / `WATCHLIST_DROP` | 70 / 55 | Stalk-list thresholds |
| `WATCHLIST_MAX_AGE_H` | 240 | Auto-expire a coil |

Files written: `accumulation.json` (cache), `watchlist.json` (stalk list). Both
can be surfaced on the website later via a small `/api/watchlist` endpoint.
