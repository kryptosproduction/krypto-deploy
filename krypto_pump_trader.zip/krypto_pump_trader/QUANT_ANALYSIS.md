# Bot 2 — Quant Upgrade & Analysis Framework

How Bot 2 went from a *detector* to a *decider*, and how to use the data it now
logs to decide whether the screener is actually worth trading.

---

## 1. What changed

Before: every 15× pump was traded the same way — flat −20% stop, target = nearest
resistance, no read on whether the move was real or already exhausted.

Now: each entry candidate is scored 0–100 by `pump_quality.py`, which ports Bot 1's
microstructure read into the pump context and adds pump-specific exhaustion
features. The score drives a **TRADE / SHADOW / SKIP** decision with a proper plan.

```
detect pump (15×)  →  score it  →  decision:
                                    ≥58 & R:R≥1.5  → TRADE  (size + ATR stop + target)
                                    45–58          → SHADOW (track, don't trade)
                                    <45 or vetoed  → SKIP   (radar only)
```

## 2. The signal gate vs. the score (important distinction)

The **abnormal-volume pump is the trigger** — the precondition for a signal to
exist at all. It is deliberately **not** a scored factor (scoring it would
double-count the very thing that fired the signal). A pump only becomes a tradeable
*signal* when it also clears these confirmation gates:

- *Volume* — each of the last 3 candles ≥ `VOLUME_MULTIPLIER`× the 24h baseline.
- *Real body* — the pump candle is a directional body, not a wick (`MIN_BODY_RATIO`).
- *Liquidity floor* — minimum $ traded in the window (`MIN_PUMP_NOTIONAL_USD`); kills
  illiquid names where the multiple is noise and slippage would be brutal.
- *Range breakout* — price makes a new high vs the prior ~20 candles, confirming a
  breakout rather than chop inside a range.

Only *after* all of that does the candidate go to the score.

## 2b. What the SCORE judges (everything except volume)

**Is the move REAL?**
- *Taker buy/sell ratio* — aggressive buyers lifting offers, not passive fills.
- *Open-interest change* — rising OI = new positioning / squeeze fuel (Bot 1's
  ORCA logic); flat/falling OI during a pump = hollow, spot-churn move.
- *Close location in range* — closing near the high = buyers in control (CVD-lite).

**Is there FUEL?**
- *Top-trader long/short ratio* — smart-money positioning.
- *Funding rate* — mild positive is fine; extreme positive = crowded longs =
  exhaustion risk, so it's scored inversely.

**Is the TAPE with us?**
- *BTC 1h trend* — don't long alts while BTC is flushing (hard veto past −2.5%).

**Is it EARLY?**
- *RSI* — rewards 55–70, punishes >80.
- *Extension above EMA20 in ATR units* — measures how stretched the entry is.
- *Consecutive green candles* — blow-off proxy.

Missing data (an endpoint fails) has its weight redistributed across the available
factors, and `data_confidence` records how complete the read was. A trade on a thin
read (<0.5 confidence) is auto-downgraded to shadow — never sized up on guesswork.

## 3. Risk plan (the part that actually drives returns)

- **Dynamic stop**: `ATR_STOP_MULT × ATR%`, clamped to 3–12%. The flat −20% was
  the single biggest leak — it let losers run far past invalidation and wrecked R:R.
- **R:R gate**: target is the nearest resistance, capped at 4R; if reward:risk < 1.5
  the trade is rejected (shadowed). You only take trades the math likes.
- **Volatility-targeted size**: `size_factor = conviction × (vol_target / ATR%)`.
  Calmer names get more size, violent ones less, so each trade risks a similar amount.
- **R-multiples logged**: every trade's P&L is also expressed in units of risk, the
  only unit in which trades are comparable.

## 4. How to decide if we should trade it — the validation loop

The screener earns the right to be traded with **money** only after the data says so.
Bot 2 now logs everything needed (`pump_trades.csv` + the Sheet). Run these once you
have a meaningful sample (aim for **100+ closed trades**; below ~30 nothing is real).

**a) Expectancy by score bucket.** Group closed trades by score band (45–58 shadow,
58–70, 70–80, 80+). For each: win rate, avg win, avg loss, and
`expectancy = win% × avgWin − loss% × avgLoss` in R. **Only trade buckets with
positive expectancy and adequate sample.** If 80+ prints +0.6R and 58–70 prints
−0.1R, raise `MIN_SCORE_TO_TRADE` to where expectancy turns positive.

**b) Shadow vs traded.** The shadow group is your control. If shadows (45–58) win as
often as trades (≥58), the score adds no value at that boundary — move the threshold.
If traded clearly beats shadow, the gate is doing real work.

**c) MFE/MAE → stop & target tuning.** You log peak (MFE) and trough (MAE) per trade.
- If winners routinely show MAE of only −2 to −3% before working, your stops are too
  wide — tighten `ATR_STOP_MULT`.
- If price regularly tags +8% (MFE) then you exit flat, targets are too far or you
  need a partial/trail. The `peak_pnl_pct` column quantifies money left on the table.

**d) Factor attribution.** Regress outcome (win / R-multiple) on the logged factors
(oi_change, taker_ratio, funding, ext_atr, rsi, btc_1h…). Keep the factors that
predict; drop or down-weight the ones that don't. This is how the weights in
`_score()` should evolve — from data, not intuition.

**e) Regime conditioning.** Slice win rate by `btc_1h_pct` bucket and by session
(Asia/EU/US). Many pump edges exist *only* in risk-on regimes. If so, gate entries on
regime rather than trading them flat.

**f) Holding-time / time-stop.** Bucket P&L by `hold_minutes`. If edge decays after,
say, 90 minutes, add a time stop.

**Recalibration cadence:** re-run (a)–(f) every ~2–4 weeks, adjust the config
constants at the top of `krypto_pump_trader.py`, and let the shadow group keep
validating the new boundary. Never optimize on <30 trades; expect parameters to be
noisy until 100+.

## 5. The honest caveat

This is still paper, and paper omits the two things that kill pump strategies live:
**slippage** (you won't fill the breakout candle at its print) and **fees/funding**.
Before any real capital, re-run expectancy after subtracting a realistic per-trade
cost (e.g. 0.1–0.3% round-trip + slippage proportional to how violently it pumped).
A strategy that's +0.3R gross can be break-even net. The forward test exists to find
that out *before* it costs anything.

---

### Config quick-reference (top of `krypto_pump_trader.py`)

| Constant | Does | Tune from |
|---|---|---|
| `MIN_SCORE_TO_TRADE` | trade/shadow boundary | expectancy by bucket (4a, 4b) |
| `MIN_RR` | reject poor reward:risk | (4c) |
| `ATR_STOP_MULT` / `MAX_STOP_PCT` | stop width | MAE of winners (4c) |
| `VOL_TARGET_PCT` | position size | realized vol of P&L |
| `BTC_DUMP_VETO_PCT` | regime veto | regime slice (4e) |
| `RADAR_VOLUME_MULTIPLIER` | website firehose loudness | — |
