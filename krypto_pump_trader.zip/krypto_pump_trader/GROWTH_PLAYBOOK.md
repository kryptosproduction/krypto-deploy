# KryptoSniper — Growth Playbook (X / Social)

Thinking like a growth marketer, not just a poster. Posting good content into the
void does nothing — the account grows from **media + distribution + consistency**.
This playbook covers all three.

---

## 1. The visual system (your unfair advantage)

`social_cards.py` generates three branded card types at 1600×900 (X's best inline
ratio). **Every post that can have an image should have one** — media posts get
multiples of the reach of text-only on X.

| Card | When to post | Why it works |
|------|-------------|--------------|
| **pump_card** | live pump alerts (teaser, locked fields shown) | scroll-stopper; the padlocks create "what am I missing?" |
| **result_card** | every closed trade — win AND loss | proof you can SEE, not just claim; the loss cards build the most trust |
| **quote_card** | insight/education posts | save-able + shareable; these recirculate for months |

Generate one inline:
```python
from social_cards import pump_card, result_card, quote_card
result_card('ARB/USDT:USDT', 21.92, 4.13, is_win=True, strategy='GOLDEN_POCKET', out='post.png')
# then attach post.png to the tweet (social_poster.py handles media upload)
```

**The brand rules** (consistency = recognisability = follows):
- Always the same dark/purple palette, same logo, same footer.
- Numbers are the hero. Big, monospace, green/red.
- One idea per card. Never crowd it.

---

## 2. The counterintuitive winner: LOSS cards

Most accounts only post wins. Post your losses *as cards*, with the framing
"stop did its job, small loss, no drama." This does three things no win can:
- **Builds trust** — you're visibly not hiding anything.
- **Differentiates** — every other signal account looks like a scam by comparison.
- **Travels** — "a signal account posting its losses" is itself novel enough to share.

Your transparency isn't just honest — it's the *most marketable* thing you have.
Lean into it harder than feels comfortable.

---

## 3. Distribution — where the first 1,000 followers actually come from

Posting alone won't grow you. The mechanics that do:

**Reply game (highest ROI early).** Spend 20 min/day replying with genuine value to
bigger crypto-trading accounts (10k–200k followers). Thoughtful replies on a big
post get seen by thousands and send follows. This matters MORE than your own posts
for the first month. Don't shill — add insight.

**Timing.** Crypto X is most active ~13:00–16:00 and ~20:00–23:00 UTC. Post your best
content then. (For you in Thailand UTC+7: roughly 8pm–11pm and 3am–6am — schedule the
late ones.)

**Quote-tweet the market.** When something big happens (a major liquidation cascade,
a violent pump), quote it with your read. Riding live events = reach.

**The hook is the whole game.** First line decides if anyone reads the rest. Lead with
tension or a claim, never a windup. "most signal accounts hide their losses." > "Hey
everyone, today I wanted to talk about transparency..."

**Consistency beats intensity.** 3 posts/day every day for 60 days beats 20 posts one
day and silence. The algorithm rewards showing up.

---

## 4. The 30-day launch sequence

**Week 1 — voice & proof.** Establish the transparency thesis. Post the content in
`X_CONTENT_WEEK1.md`. Goal: 100 followers, find your voice. No hard selling.

**Week 2 — education engine.** Post 1 thread/day teaching a real concept (use the
Handbook chapters as source material — expectancy, order flow, R:R, regimes). These
get bookmarked and recirculate. Goal: establish authority.

**Week 3 — proof ramps up.** Now the bot has more logged trades; let `social_poster.py`
post result cards daily. Pair each with a human caption. Start mentioning the free
channel more (still soft). Goal: channel signups.

**Week 4 — first soft monetisation.** Once the public record looks credible, start
mentioning premium. Never more than 1-in-4 posts a pitch. Let the track record sell.
Goal: first paying members.

---

## 5. Caption + card pairing (the formula)

The card carries the data; the caption carries the *voice*. Example:

> **Card:** result_card ARB +21.9% WIN
> **Caption:** "entered a deep fib retrace most people would've been scared of.
> banked a third at resistance, trailed the rest. this is what patience pays.
> every trade logged 👇"

> **Card:** result_card SYN -1R LOSS
> **Caption:** "red one today. breakout failed, stop did its job, moved on.
> i post these because the green ones don't mean anything without them."

The caption should never just repeat the card. Card = what happened. Caption = the
lesson, the voice, the human.

---

## 6. What NOT to do

- Don't buy followers — kills your engagement rate and credibility.
- Don't post signals as your *only* content — you become noise, not a person.
- Don't fake results — your whole moat is that you don't. One caught lie ends it.
- Don't over-pitch — the track record is the pitch.
- Don't use 8 hashtags or rocket-emoji spam — reads as desperate/bot.
- Don't automate replies/DMs with bots — bannable and obvious.

---

## 7. Bio + profile (first impression)

- **Name:** KryptoSniper
- **Handle:** @KryptoSniperAI (or similar — short, clear)
- **Bio:** "Quant pump signals for crypto perps · every trade logged, wins AND losses · free alerts 👇"
- **Pic:** the crosshair logo on dark — matches the cards.
- **Banner:** a result-card-style image with the tagline "We post every trade."
- **Pinned:** the Day-1 thesis post.
- **Link:** free Telegram channel.

Consistency between your profile, cards, and Telegram = one recognisable brand.
