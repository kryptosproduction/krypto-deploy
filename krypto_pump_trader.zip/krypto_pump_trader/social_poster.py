#!/usr/bin/env python3
"""
social_poster.py — auto-posts KryptoSniper results to X, a public Telegram
channel, and Discord.

The content strategy IS the product thesis: post every closed trade — wins AND
losses — plus a daily recap. The losses are what make the wins believable; no
other signal service dares to do it.

What it posts:
  • every newly closed real trade (skips shadows)
  • a daily recap (yesterday's W/L, net P&L) once per day
  • watchlist breakouts (a coil we publicly stalked actually popped)

Run it from the bot folder on a timer (systemd unit in RUN_GUIDE.md):
  python3 social_poster.py            # post anything new
  python3 social_poster.py --dry-run  # print what WOULD be posted

Dependency-free: X OAuth 1.0a is implemented with hmac/sha1 from the stdlib.
"""
import csv
import json
import os
import sys
import time
import hmac
import base64
import hashlib
import secrets
import logging
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta

# ----------------------------------------------------------------- config
SITE_URL = 'https://YOURDOMAIN.com'      # shown in every post; set your domain
TRADES_CSV = 'pump_trades.csv'
OUTCOMES_CSV = 'watchlist_outcomes.csv'
STATE_FILE = 'social_state.json'

POST_EVERY_TRADE = True       # each closed real trade (win or loss)
POST_DAILY_RECAP = True
POST_WATCHLIST_BREAKOUTS = True
MIN_ABS_PNL_TO_POST = 0.0     # set e.g. 1.0 to skip tiny scratches

# --- X / Twitter (developer portal -> app with Read & Write, OAuth 1.0a keys) ---
X_ENABLED = False
X_API_KEY = ''                # "API Key" (consumer key)
X_API_SECRET = ''
X_ACCESS_TOKEN = ''           # user access token
X_ACCESS_SECRET = ''

# --- Public Telegram channel (add your bot as channel admin) ---
TG_CHANNEL_ENABLED = False
TG_BOT_TOKEN = ''             # can reuse the alerts bot token
TG_CHANNEL = '@YourChannel'   # channel username or -100... id

# --- Discord (server settings -> integrations -> webhooks) ---
DISCORD_ENABLED = False
DISCORD_WEBHOOK_URL = ''

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('social')
DRY = '--dry-run' in sys.argv


# ----------------------------------------------------------------- helpers
def _f(x, d=0.0):
    try:
        return float(x) if x not in (None, '', 'None') else d
    except (ValueError, TypeError):
        return d


def load_state():
    try:
        return json.load(open(STATE_FILE))
    except Exception:
        return {'posted_trades': [], 'last_recap_date': '', 'posted_breakouts': []}


def save_state(s):
    s['posted_trades'] = s['posted_trades'][-500:]
    s['posted_breakouts'] = s['posted_breakouts'][-200:]
    json.dump(s, open(STATE_FILE, 'w'))


def short_sym(s):
    return str(s).replace('/USDT:USDT', '').replace('/USDT', '').replace(':USDT', '')


# ----------------------------------------------------------------- X (OAuth 1.0a)
def _pct_encode(s):
    return urllib.parse.quote(str(s), safe='~')


def _oauth1_header(method, url, body_params=None):
    """Build an OAuth 1.0a Authorization header (HMAC-SHA1), stdlib only."""
    oauth = {
        'oauth_consumer_key': X_API_KEY,
        'oauth_nonce': secrets.token_hex(16),
        'oauth_signature_method': 'HMAC-SHA1',
        'oauth_timestamp': str(int(time.time())),
        'oauth_token': X_ACCESS_TOKEN,
        'oauth_version': '1.0',
    }
    all_params = dict(oauth)
    if body_params:
        all_params.update(body_params)
    param_str = '&'.join(f'{_pct_encode(k)}={_pct_encode(v)}'
                         for k, v in sorted(all_params.items()))
    base = f"{method.upper()}&{_pct_encode(url)}&{_pct_encode(param_str)}"
    key = f"{_pct_encode(X_API_SECRET)}&{_pct_encode(X_ACCESS_SECRET)}"
    sig = base64.b64encode(hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()).decode()
    oauth['oauth_signature'] = sig
    return 'OAuth ' + ', '.join(f'{_pct_encode(k)}="{_pct_encode(v)}"'
                                for k, v in sorted(oauth.items()))


def post_x(text):
    """POST /2/tweets — JSON body is NOT part of the OAuth1 signature base."""
    url = 'https://api.twitter.com/2/tweets'
    body = json.dumps({'text': text}).encode()
    req = urllib.request.Request(url, data=body, headers={
        'Authorization': _oauth1_header('POST', url),
        'Content-Type': 'application/json',
    })
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def _x_upload_media(image_path):
    """Upload an image to X (v1.1 media endpoint) and return its media_id.
    Media upload IS part of the OAuth1 signature base (multipart form)."""
    url = 'https://upload.twitter.com/1.1/media/upload.json'
    with open(image_path, 'rb') as f:
        img = f.read()
    boundary = '----KryptoSniper' + secrets.token_hex(8)
    body = (f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="media"; filename="card.png"\r\n'
            f'Content-Type: image/png\r\n\r\n').encode() + img + f'\r\n--{boundary}--\r\n'.encode()
    req = urllib.request.Request(url, data=body, headers={
        'Authorization': _oauth1_header('POST', url),   # no body params for multipart
        'Content-Type': f'multipart/form-data; boundary={boundary}',
    })
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())['media_id_string']


def post_x_with_image(text, image_path):
    """Upload an image, then post a tweet that attaches it. Media posts get far
    more reach than text-only — this is the main social-growth lever."""
    media_id = _x_upload_media(image_path)
    url = 'https://api.twitter.com/2/tweets'
    body = json.dumps({'text': text, 'media': {'media_ids': [media_id]}}).encode()
    req = urllib.request.Request(url, data=body, headers={
        'Authorization': _oauth1_header('POST', url),
        'Content-Type': 'application/json',
    })
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


# ----------------------------------------------------------------- other platforms
def post_telegram_channel(text, image_path=None):
    if image_path:
        # sendPhoto with caption (multipart)
        boundary = '----KS' + secrets.token_hex(8)
        with open(image_path, 'rb') as f:
            img = f.read()
        parts = []
        for k, v in (('chat_id', TG_CHANNEL), ('caption', text), ('parse_mode', 'Markdown')):
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="photo"; '
                      f'filename="card.png"\r\nContent-Type: image/png\r\n\r\n').encode() + img + b'\r\n')
        parts.append(f'--{boundary}--\r\n'.encode())
        body = b''.join(parts)
        req = urllib.request.Request(
            f'https://api.telegram.org/bot{TG_BOT_TOKEN}/sendPhoto',
            data=body, headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})
        urllib.request.urlopen(req, timeout=30).read()
    else:
        data = urllib.parse.urlencode({'chat_id': TG_CHANNEL, 'text': text,
                                       'disable_web_page_preview': 'true'}).encode()
        urllib.request.urlopen(
            f'https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage',
            data=data, timeout=15).read()


def post_discord(text):
    body = json.dumps({'content': text}).encode()
    req = urllib.request.Request(DISCORD_WEBHOOK_URL, data=body,
                                 headers={'Content-Type': 'application/json'})
    urllib.request.urlopen(req, timeout=15).read()


def publish(text, image_path=None):
    log.info(('[DRY RUN] ' if DRY else '') + text.replace('\n', ' | ')
             + (f'  [+image {image_path}]' if image_path else ''))
    if DRY:
        return
    # X
    if X_ENABLED:
        try:
            post_x_with_image(text, image_path) if image_path else post_x(text)
        except Exception as e:
            log.warning(f"X post failed: {e}")
    # Telegram channel
    if TG_CHANNEL_ENABLED:
        try:
            post_telegram_channel(text, image_path)
        except Exception as e:
            log.warning(f"Telegram post failed: {e}")
    # Discord (text only)
    if DISCORD_ENABLED:
        try:
            post_discord(text)
        except Exception as e:
            log.warning(f"Discord post failed: {e}")


def publish_trade_result(symbol, pnl_pct, r_multiple, is_win, strategy='', caption=None):
    """Generate a branded result card and post it with a caption. This is what the
    bot calls when a trade closes — turns every win/loss into shareable proof."""
    try:
        from social_cards import result_card
        img = f'/tmp/result_{symbol.split("/")[0]}_{int(time.time())}.png'
        result_card(symbol, pnl_pct, r_multiple, is_win, strategy, out=img)
    except Exception as e:
        log.warning(f"card generation failed, posting text only: {e}")
        img = None
    if caption is None:
        sym = symbol.split('/')[0]
        if is_win:
            caption = (f"Closed {sym} +{pnl_pct:.1f}% ({r_multiple:+.1f}R).\n\n"
                       f"Banked a partial, trailed the rest. Every trade logged \u2014 "
                       f"the losers too.")
        else:
            caption = (f"Closed {sym} {pnl_pct:.1f}% ({r_multiple:+.1f}R).\n\n"
                       f"Stop did its job. Small loss, no drama. I post these because "
                       f"the green ones don't mean anything without them.")
    publish(caption, img)


# ----------------------------------------------------------------- content
def trade_post(t):
    sym = short_sym(t['symbol'])
    pnl = _f(t.get('pnl_pct'))
    net = _f(t.get('net_pnl_pct'), pnl)
    r = t.get('r_multiple', '')
    hold = _f(t.get('hold_minutes'))
    reason = (t.get('exit_reason') or '').replace('_', ' ').lower()
    if pnl > 0:
        head = f"✅ {sym} +{pnl:.1f}%" + (f" ({r}R)" if r else '')
        line2 = f"{reason} in {hold:.0f}m · net +{net:.1f}% after est. costs"
    else:
        head = f"🔻 {sym} {pnl:.1f}%" + (f" ({r}R)" if r else '')
        line2 = f"{reason} · posted like every loss — that's the point"
    return (f"{head}\n{line2}\n\n"
            f"Every signal logged, wins and losses (paper):\n{SITE_URL}/track-record")


def recap_post(rows, day):
    n = len(rows)
    wins = sum(1 for r in rows if _f(r.get('pnl_pct')) > 0)
    pnl = sum(_f(r.get('pnl_pct')) for r in rows)
    net = sum(_f(r.get('net_pnl_pct'), _f(r.get('pnl_pct'))) for r in rows)
    best = max(rows, key=lambda r: _f(r.get('pnl_pct')))
    worst = min(rows, key=lambda r: _f(r.get('pnl_pct')))
    return (f"📊 {day} recap — {n} closed signals\n"
            f"{wins}W / {n - wins}L · gross {pnl:+.1f}% · net {net:+.1f}% (est. costs)\n"
            f"best {short_sym(best['symbol'])} {_f(best.get('pnl_pct')):+.1f}% · "
            f"worst {short_sym(worst['symbol'])} {_f(worst.get('pnl_pct')):+.1f}%\n\n"
            f"Full record, nothing hidden: {SITE_URL}/track-record")


def breakout_post(w):
    return (f"🚀 {short_sym(w['symbol'])} just broke out — we publicly stalked this "
            f"coil for {w.get('days_stalked')}d (accumulation score peaked "
            f"{w.get('peak_score')}/100) before it moved.\n\n"
            f"The watchlist is on the dashboard: {SITE_URL}")


# ----------------------------------------------------------------- main
def main():
    state = load_state()

    rows = []
    if os.path.exists(TRADES_CSV):
        with open(TRADES_CSV, newline='') as f:
            rows = [r for r in csv.DictReader(f)
                    if (r.get('event') or '').upper() == 'EXIT'
                    and str(r.get('is_shadow')).lower() not in ('true', '1')]

    # 1) new closed trades
    if POST_EVERY_TRADE:
        for t in rows:
            tid = t.get('trade_id')
            if not tid or tid in state['posted_trades']:
                continue
            if abs(_f(t.get('pnl_pct'))) < MIN_ABS_PNL_TO_POST:
                state['posted_trades'].append(tid)
                continue
            publish(trade_post(t))
            state['posted_trades'].append(tid)
            time.sleep(1)

    # 2) daily recap for yesterday (posts once, after the day closes UTC)
    if POST_DAILY_RECAP:
        yday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d')
        if state.get('last_recap_date') != yday:
            yrows = [r for r in rows if str(r.get('timestamp', '')).startswith(yday)]
            if yrows:
                publish(recap_post(yrows, yday))
            state['last_recap_date'] = yday

    # 3) watchlist breakouts
    if POST_WATCHLIST_BREAKOUTS and os.path.exists(OUTCOMES_CSV):
        with open(OUTCOMES_CSV, newline='') as f:
            for w in csv.DictReader(f):
                key = f"{w.get('symbol')}|{w.get('resolved_ts')}"
                if w.get('outcome') == 'BREAKOUT' and key not in state['posted_breakouts']:
                    publish(breakout_post(w))
                    state['posted_breakouts'].append(key)
                    time.sleep(1)

    save_state(state)
    log.info("done")


if __name__ == '__main__':
    main()
