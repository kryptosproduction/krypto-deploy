"""
KryptoPumpTrader — Paper-trading engine for the Krypto Pump Screener strategy.

IMPORTANT: This is a PAPER TRADER. It reads PUBLIC market data only, places NO
real orders, and needs NO exchange API keys. Every "buy" and "sell" is simulated
and logged so you can measure entry/exit quality and win rate before risking money.

Two strategies run in parallel:
  A) PUMP_BREAKOUT  — enter on a sustained pump if 4h resistance gap > 5%,
                      take profit at the 4h resistance, stop loss at -20%.
  B) GOLDEN_POCKET  — after a pump, if price retraces into the 0.618-0.70 fib
                      zone with volume, enter; take profit near the pump high,
                      stop loss at -20%.

Guards:
  - Only one open position per ticker at a time.
  - Only GREEN pumps are detected, never red dumps.

Every entry and exit is sent to Telegram and logged to a Google Sheet webhook.
"""

import ccxt
import time
import json
import os
import asyncio
import logging
import urllib.request
from datetime import datetime, timezone, timedelta
from collections import deque

import pandas as pd
import numpy as np
from telegram import Bot
from telegram.error import RetryAfter, TimedOut, NetworkError

try:
    from pump_quality import PumpScorer
except Exception:
    PumpScorer = None

try:
    from accumulation import AccumulationScanner
except Exception:
    AccumulationScanner = None

# ============================================================================
# CONFIGURATION  — EDIT THESE
# ============================================================================

# --- Telegram (separate Krypto Pump Screener bot) ---
TELEGRAM_BOT_TOKEN = '8530188125:AAFu0r2b4gSv09JEvVTimpv7DnGiTwGtQ-Y'
TELEGRAM_CHAT_ID   = '5547784306'

# --- Google Sheet webhook (paste your Apps Script Web App URL after deploying) ---
SHEET_WEBHOOK_URL  = 'https://script.google.com/macros/s/AKfycbxg5EKAwC6-bPyuk0vNOqn5Ai_yIrAahgAlbHMKy9mPknvd-7xPgSGrgPnsDqOWyW1mww/exec'

# --- Exchange ---
EXCHANGE = 'binance'   # 'binance' or 'bybit'

# --- Pump detection ---
PUMP_THRESHOLD          = 2.0    # min % price rise over 3 minutes
VOLUME_MULTIPLIER       = 15.0   # each of last 3 candles >= this x the 24h baseline (the SIGNAL GATE)
VOLUME_MOMENTUM_CANDLES = 3      # sustained across this many candles
USE_HOURLY_BASELINE     = True   # compare to 24h average (true abnormal volume)
HOURLY_BASELINE_PERIODS = 24

# --- What QUALIFIES as a tradeable pump signal (confirmation gate, NOT scored) ---
# The abnormal-volume pump is the trigger; these confirm it's real and tradeable
# before it's even passed to the quality score.
MIN_BODY_RATIO        = 0.5      # the pump candle must be a real directional body, not a wick
MIN_PUMP_NOTIONAL_USD = 50000    # liquidity floor: min $ traded across the pump candles
REQUIRE_BREAKOUT      = True     # require a breakout above the prior-range high
BREAKOUT_LOOKBACK     = 20       # candles to define that prior-range high

# --- MACD (show it, do not require it) ---
REQUIRE_MACD   = False           # do NOT gate entries on MACD
MACD_MULTIPLIER = 5.0            # only used if REQUIRE_MACD = True

# --- Live radar feed (powers the website's live activity ticker) ---
# Logs EVERY pump at/above this looser bar to detections.json so the site has a
# loud, real-time firehose to show. The strict VOLUME_MULTIPLIER above still
# governs what becomes an actual tracked trade. Radar = "what we saw";
# tracked trades = "what we acted on".
RADAR_VOLUME_MULTIPLIER = 4.0
RADAR_FILE     = 'detections.json'
RADAR_KEEP     = 150             # rolling buffer size
RADAR_FLUSH_SECONDS = 8          # how often the buffer is written to disk

# --- Dual-timeframe resistance ---
RESISTANCE_TIMEFRAMES = ['4h', '1d']
RESISTANCE_LOOKBACK   = 50
ENTRY_MIN_4H_GAP_PCT  = 5.0      # only enter PUMP_BREAKOUT if 4h resistance gap > this

# --- Fibonacci retracement entry ---
FIB_TIMEFRAME      = '4h'
FIB_LOOKBACK       = 100
# The ENTRY zone: we currently trade the 0.786 retrace (a deeper pullback than the
# 0.618–0.65 golden pocket — better price/R:R, fewer fills, last line before the move
# is considered failed). The band has a little width so a bounce near 0.786 still fills.
FIB_ENTRY_LOW      = 0.75        # top of the entry band (shallower)
FIB_ENTRY_HIGH     = 0.786       # bottom of the entry band (the 0.786 line)
# Every fib level is TRACKED for analysis even though we only trade the band above —
# so analyze.py can tell us whether 0.786 actually beats the 0.618–0.65 pocket.
FIB_TRACK_LEVELS   = [0.382, 0.5, 0.618, 0.65, 0.786]
FIB_TOLERANCE      = 0.01
FIB_VOLUME_REQUIRED = 2.5        # volume must be >= 2.5x baseline at entry (bounce confirm)
RETRACE_TRACK_HOURS = 3          # watch each pump for a retrace this long (deeper = more time)

# --- Risk ---
STOP_LOSS_PCT = 20.0             # fallback flat stop (used only if scoring is off)

# --- Quant quality scoring (the upgrade) ---
USE_QUALITY_SCORE  = True        # score every entry candidate; gate/size/plan from it
MIN_SCORE_TO_TRADE = 58          # >= this and R:R ok -> real trade
SHADOW_MIN_SCORE   = 45          # 45-58 -> shadow (tracked, not traded) control group
MIN_RR             = 1.5         # reject trades below this reward:risk
ATR_STOP_MULT      = 2.0         # dynamic stop = ATR_STOP_MULT x ATR%, clamped
MAX_STOP_PCT       = 12.0        # never risk more than this on one trade
MIN_STOP_PCT       = 3.0         # floor so stops aren't inside the noise
VOL_TARGET_PCT     = 4.0         # volatility-targeted position sizing
BTC_DUMP_VETO_PCT  = -2.5        # don't long alts when BTC is dumping this hard (1h)
TARGET_R_CAP       = 4.0         # cap target at this many R
LOCAL_TRADES_CSV   = 'pump_trades.csv'   # per-trade history (feeds the website record)

# --- Execution-cost modeling (the honesty layer) ---
# Paper fills are perfect; live fills aren't. Every closed trade also logs a NET
# P&L after estimated costs, so expectancy can be judged the way it will trade live.
FEE_PCT_PER_SIDE   = 0.05     # taker fee per fill (Binance futures ~0.04-0.05%)
SLIPPAGE_PCT       = 0.10     # est. slippage entering a fast-moving breakout
# round trip = entry + exit fills + entry slippage (exits via stop/limit ~ at price)
COST_ROUND_TRIP_PCT = round(2 * FEE_PCT_PER_SIDE + SLIPPAGE_PCT, 3)

# --- Volume z-score trigger (A/B alternative to the fixed multiple) ---
# A fixed 15x means different things for BTC vs a microcap. The z-score asks
# "how many standard deviations above THIS coin's own recent volume" — one
# threshold that normalizes across the whole universe. Off by default so the
# fixed-multiple baseline keeps running; flip on to A/B.
USE_VOLUME_ZSCORE  = False
VOLUME_ZSCORE_MIN  = 6.0      # each pump candle's volume z-score must be >= this
ZSCORE_BASELINE_N  = 40       # 1m candles (excluding the pump) used for mean/std

# --- Order-flow signals ported from Bot 1 ---
# Short-liquidation ratio needs a live websocket (pip install websocket-client).
# CVD slope, OI z-score and global L/S are REST-based and always on. Set this False
# to skip only the websocket feed (the other three still score).
USE_LIQUIDATION_FEED = True

# --- Pump signal alerts (send for EVERY scored pump, traded or not) ---
# A pump that passes the signal gate gets a Telegram alert with its score and the
# trade decision (TRADE / SHADOW / SKIP) — so you see every pump the screener finds,
# regardless of whether the quant engine chose to trade it. Deduped per symbol.
ALERT_EVERY_PUMP        = True
PUMP_ALERT_COOLDOWN_MIN = 30
# ALERT sensitivity (separate from the strict TRADE gate). The screener feed alerts
# on this looser bar — like the early versions that surfaced many pumps to look at —
# while actual TRADES still require the strict meets_entry gate (breakout + notional).
ALERT_VOLUME_MULTIPLIER = 6.0    # alert when each of the last 3 candles >= this x baseline
ALERT_MIN_PRICE_PCT     = 3.0    # ...and the pump moved at least this %
ALERT_REQUIRE_BREAKOUT  = False  # the ALERT path does NOT require a fresh breakout
ALERT_MIN_NOTIONAL_USD  = 10000  # lighter liquidity floor for alerts than for trades

# --- Daily summary (a once-a-day scorecard per strategy) ---
# Thailand is UTC+7. The summary covers the day that just ended, so we send it
# in the morning Thai time. 1 UTC = 08:00 Thailand.
DAILY_SUMMARY_ENABLED  = True
DAILY_SUMMARY_HOUR_UTC = 1       # 08:00 Thailand time (UTC+7)

# === STRATEGY C — SHORT REVERSION (fade overextended pumps) ===========
# Short a pair that has overextended far above its short EMA, targeting a snap-back
# to the EMA. Three INDEPENDENT timeframe triggers (any one fires). The quant score
# is INVERTED here as a gatekeeper: only short HOLLOW pumps (squeeze / weak CVD /
# perp-froth) — never organic ones that tend to keep running.
SHORT_REVERSION_ENABLED = True
SHORT_EMA_LENGTH        = 20      # the EMA the price reverts to (the target line)
SHORT_EMA_SMOOTHING     = 14      # smoothing MA of the EMA (logged for optimization)
SHORT_BB_STD            = 2.0     # bollinger std on the smoothing line (logged)
# (timeframe, % above EMA to trigger a short)
SHORT_TRIGGERS = [('3m', 10.0), ('5m', 15.0), ('15m', 20.0)]
SHORT_STOP_PCT          = 15.0    # stop this % ABOVE entry (wide; sizing keeps risk small)
SHORT_STOP_ATR_BUFFER   = True    # widen stop to max(SHORT_STOP_PCT, pump-high + ATR) if needed
SHORT_TIME_STOP_MIN     = 20      # reversion should be fast; bail if it stalls
SHORT_PARTIAL_AT_EMA    = True    # bank most of it on the EMA touch
SHORT_COOLDOWN_MIN      = 30      # per-symbol cooldown after a short
# Gatekeeper: only short when the pump looks hollow. These are the inverted reads.
SHORT_MIN_SQUEEZE_OR_WEAKCVD = True   # require squeeze OR weak CVD evidence
SHORT_VETO_IF_ORGANIC        = True   # veto if strong CVD + smart-money-long + accumulation base
SHORT_VETO_BTC_PUMP_PCT      = 2.0    # don't short into a market-wide rip (BTC +2%/1h)
SHORT_MAX_CONCURRENT         = 4


# --- Watchlist outcome tracking (does the accumulation engine itself work?) ---
WATCHLIST_OUTCOMES_CSV = 'watchlist_outcomes.csv'   # every resolved coil: BREAKOUT / FADED / EXPIRED

# --- Subscriber alert broadcasting (the commercial layer) ---
# The web backend writes subscribers.json (paid users who linked Telegram).
# Bot 2 broadcasts entry/exit alerts to them via the ALERTS bot token (the
# customer-facing bot from @BotFather) — your own alerts keep using this bot's
# main token, so your feed is unaffected if broadcasting is off.
BROADCAST_ALERTS  = True
ALERTS_BOT_TOKEN  = ''     # same token as alerts_bot.py; empty = broadcasting off
SUBSCRIBERS_FILE  = os.path.expanduser('~/kryptosniper_app/backend/subscribers.json')
BROADCAST_TIERS   = {'sniper', 'overwatch'}

# --- Universe: crypto perpetuals ONLY (exclude tokenized stocks / pre-IPO) ---
# Seed list of equity / pre-IPO / tokenized-stock bases to exclude. Add any you spot.
EXCLUDE_BASES = {
    'OPENAI', 'ORACLE', 'ORCL', 'NVDA', 'AAPL', 'TSLA', 'MSFT', 'META', 'GOOGL', 'GOOG',
    'AMZN', 'NFLX', 'COIN', 'HOOD', 'MSTR', 'SPY', 'QQQ', 'AMD', 'INTC', 'PLTR',
    'CRCL', 'SBET', 'IPO', 'PREIPO', 'SPACEX', 'STRIPE', 'ANTHROPIC', 'XAUT_STOCK',
}

# --- Exit management (the biggest expectancy lever) ---
USE_EXIT_MANAGEMENT = True
# 2-tier exit: bank a third at TP1, let two-thirds RIDE on a trailing stop (uncapped,
# so parabolic breakouts to new highs run free). TP1 sits at the nearest resistance if
# one is close, otherwise at +1R — structure governs when it exists, R is the fallback.
PARTIAL_TP_R        = 1.0     # fallback TP1 level (in R) when no near resistance
PARTIAL_TP_FRACTION = 0.34    # bank ~1/3 at TP1, ride 2/3 (momentum lives on the runner)
TP1_USE_RESISTANCE  = True    # prefer nearest resistance as TP1 if within this R range
TP1_RES_MIN_R       = 0.6     # ...but only if that resistance is at least this many R away
TP1_RES_MAX_R       = 2.5     # ...and not further than this (else it's not a real "near" TP1)
MOVE_TO_BREAKEVEN   = True    # after TP1, stop -> entry (trade can no longer lose)
# Early breakeven safety: if a trade runs up nicely but stalls BEFORE TP1, protect it.
EARLY_BE_TRIGGER_R  = 0.6     # at +0.6R unrealized, ratchet the stop up toward breakeven
USE_TRAILING_STOP   = True    # trail the runner via chandelier (peak - mult*ATR)
TRAIL_ATR_MULT      = 3.0      # base (loose) trail while the runner is developing
# Progressive trail: tighten the leash as the runner gains, so a big move can't give
# back most of its profit before exiting — while still staying UNCAPPED (a parabolic
# move keeps running, just on a shorter leash). Tiers are in R of unrealized profit.
TRAIL_PROGRESSIVE   = True
TRAIL_TIER_1_R      = 1.0     # above +1R profit -> medium trail
TRAIL_TIER_1_MULT   = 2.0
TRAIL_TIER_2_R      = 3.0     # above +3R profit -> tight trail (lock the windfall)
TRAIL_TIER_2_MULT   = 1.5
RUNNER_UNCAPPED     = True    # the runner has NO fixed target — rides the trail only
TIME_STOP_MIN       = 45      # if no follow-through (no +1R) within this, exit flat

# --- Entry vetoes (gate, not scored) ---
MAX_DAY_EXTENSION_PCT = 40.0  # skip if the coin already ran > this on the day (blow-off risk)
MAX_SPREAD_BPS        = 12.0  # skip if bid/ask spread wider than this (unfillable)
COOLDOWN_AFTER_LOSS_MIN = 120 # don't re-enter a symbol for this long after a stop-out

# --- Portfolio risk controls ---
MAX_CONCURRENT_TRADES = 6     # cap simultaneous real positions (correlation control)
MAX_PORTFOLIO_RISK_PCT = 30.0 # cap summed risk across open real trades
DAILY_LOSS_LIMIT_PCT   = 25.0 # kill switch: stop new real trades after this daily loss

# --- Accumulation engine (smart-money base detection + watchlist) ---
USE_ACCUMULATION   = True
ACC_SCAN_CHUNK     = 40       # symbols scored per slow cycle (rotates the universe)
ACC_SCAN_INTERVAL  = 180      # seconds between accumulation chunks
ACC_REFRESH_HOURS  = 2        # don't re-score a symbol more often than this
ACC_FILE           = 'accumulation.json'
ACC_MIN_QUOTE_VOL  = 300000   # 24h $ vol floor to bother scoring a coil
# how accumulation amplifies a confirmed pump:
ACC_BOOST_MIN      = 60       # acc score >= this starts boosting the pump
ACC_SIZE_BONUS     = 0.6      # up to +60% size at acc score 100
ACC_SCORE_BONUS    = 12       # up to +12 pump-score points from a strong base
ACC_CAN_UPGRADE    = True     # let a strong base upgrade a borderline SHADOW -> TRADE
ACC_UPGRADE_WINDOW = 8        # only if base pump score within this of the trade threshold
# watchlist (the separate stalk list):
WATCHLIST_FILE     = 'watchlist.json'
WATCHLIST_ADD      = 70       # acc score to join the stalk list (+ Telegram alert)
WATCHLIST_DROP     = 55       # drop from the list below this
WATCHLIST_MAX_AGE_H = 240     # auto-expire a coil after this long (10 days)
WATCHLIST_DIGEST_HOURS = 12   # periodic "top coils" digest to Telegram (0 = off)

# --- Engine ---
CHECK_INTERVAL   = 20            # seconds between full-universe scan cycles
MONITOR_INTERVAL = 30            # seconds between open-position exit checks (independent loop)
STATE_FILE     = 'pump_trader_state.json'

# ============================================================================
# END CONFIG
# ============================================================================

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def _utcnow_iso():
    return datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')


class KryptoPumpTrader:
    def __init__(self):
        self.exchange = self._init_exchange()
        self.bot = Bot(token=TELEGRAM_BOT_TOKEN)
        self.chat_id = TELEGRAM_CHAT_ID

        self.macd_fast, self.macd_slow, self.macd_signal = 12, 26, 9

        # State: open positions keyed by symbol; pump tracker for retrace entries
        self.open_positions = {}     # symbol -> position dict
        self.pump_tracker = {}       # symbol -> {local_low, pump_high, fib_levels, ts}
        self.trade_counter = 0
        self.stats = {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0}
        self.shadow_stats = {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0}
        # per-strategy running stats (separate win rates for each strategy)
        self.strat_stats = {
            'PUMP_BREAKOUT': {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0},
            'GOLDEN_POCKET': {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0},
            'SHORT_REVERSION': {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0},
        }
        self.short_candidates = set()   # symbols that pumped -> check for short trigger
        self.short_cooldowns = {}       # symbol -> ts
        self.pump_alerted = {}   # symbol -> ts, dedup for the every-pump scoring alert
        self.last_summary_date = ''   # last date a daily summary was sent
        self.cooldowns = {}                      # symbol -> unix ts until which it's blocked
        self.daily = {'date': '', 'pnl': 0.0}    # daily loss kill-switch tracking

        # Accumulation engine: background scanner + cache + watchlist
        self.acc = None
        if USE_ACCUMULATION and AccumulationScanner is not None:
            self.acc = AccumulationScanner({'min_quote_vol_24h': ACC_MIN_QUOTE_VOL})
        self.acc_cache = {}      # symbol -> {score, label, ts, ...}
        self.watchlist = {}      # symbol -> {added_ts, score, peak_score, label, signals}
        self.acc_index = 0       # rotating scan pointer
        self._last_digest = 0
        self._load_json_into(ACC_FILE, 'acc_cache')
        self._load_json_into(WATCHLIST_FILE, 'watchlist')

        # Quant scorer (gates/sizes/plans entries). Degrades if module missing.
        self.scorer = None
        if USE_QUALITY_SCORE and PumpScorer is not None:
            self.scorer = PumpScorer({
                'min_score_to_trade': MIN_SCORE_TO_TRADE,
                'shadow_min_score': SHADOW_MIN_SCORE,
                'min_rr': MIN_RR, 'atr_stop_mult': ATR_STOP_MULT,
                'max_stop_pct': MAX_STOP_PCT, 'min_stop_pct': MIN_STOP_PCT,
                'vol_target_pct': VOL_TARGET_PCT, 'btc_dump_veto_pct': BTC_DUMP_VETO_PCT,
                'target_r_cap': TARGET_R_CAP,
            })
            # Live liquidation feed (organic-pump vs squeeze). Background WS thread;
            # degrades to neutral if websocket-client isn't installed.
            self.liq_feed = None
            if USE_LIQUIDATION_FEED:
                try:
                    from liquidation_feed import LiquidationFeed
                    self.liq_feed = LiquidationFeed()
                    self.liq_feed.start()
                    self.scorer.liq_feed = self.liq_feed
                except Exception as e:
                    logger.warning(f"liquidation feed unavailable: {e}")

        # Live radar buffer (powers the website ticker). Load any existing detections.
        self.radar = deque(maxlen=RADAR_KEEP)
        self._last_radar_flush = 0
        try:
            if os.path.exists(RADAR_FILE):
                for d in (json.load(open(RADAR_FILE)) or [])[-RADAR_KEEP:]:
                    self.radar.append(d)
        except Exception:
            pass

        self._load_state()

    # ---------------------------------------------------------------- exchange
    def _init_exchange(self):
        cfg = {'enableRateLimit': True}
        if EXCHANGE.lower() == 'binance':
            ex = ccxt.binance(cfg); ex.options['defaultType'] = 'future'
        elif EXCHANGE.lower() == 'bybit':
            ex = ccxt.bybit(cfg); ex.options['defaultType'] = 'linear'
        else:
            raise ValueError(f"Unsupported exchange: {EXCHANGE}")
        return ex

    def _is_crypto_perp(self, symbol, m):
        """Keep only genuine crypto USDT-margined perpetuals. Excludes tokenized
        equities / pre-IPO names (OPENAI, ORACLE, NVDA...), leveraged tokens, and
        anything the exchange flags as a non-crypto product."""
        if m.get('quote') != 'USDT' or not m.get('active', True):
            return False
        if m.get('type') not in ('future', 'swap', 'linear'):
            return False
        # must be a perpetual (no expiry)
        if m.get('expiry') or m.get('future') and not m.get('swap'):
            # allow swaps/perps; reject dated futures
            if m.get('type') == 'future' and m.get('expiry'):
                return False

        base = (m.get('base') or '').upper()
        if base in EXCLUDE_BASES:
            return False
        # leveraged tokens (3L/3S/UP/DOWN/BULL/BEAR)
        if any(tok in base for tok in ('UP', 'DOWN', 'BULL', 'BEAR')) and base not in ('UP',):
            pass  # handled below by explicit suffix check to avoid false positives
        if base.endswith(('3L', '3S', '5L', '5S', 'UP', 'DOWN', 'BULL', 'BEAR')):
            return False

        # exchange metadata: drop products tagged as equities / pre-market / stocks
        info = m.get('info', {}) or {}
        tags = ' '.join(str(info.get(k, '')) for k in
                        ('contractType', 'underlyingType', 'underlyingSubType',
                         'category', 'productType', 'innovation')).upper()
        if any(w in tags for w in ('STOCK', 'EQUITY', 'PRE_MARKET', 'PREMARKET', 'PRE-IPO', 'INDEX')):
            return False
        return True

    def get_futures_pairs(self):
        try:
            markets = self.exchange.load_markets()
            pairs = [s for s, m in markets.items() if self._is_crypto_perp(s, m)]
            total = sum(1 for m in markets.values() if m.get('type') in ('future', 'swap', 'linear'))
            excluded = total - len(pairs)
            if excluded > 0:
                logger.info(f"Universe filter: {len(pairs)} crypto perps kept, {excluded} excluded (equities/pre-IPO/leveraged tokens)")
            return pairs
        except Exception as e:
            logger.error(f"Error loading markets: {e}")
            return []

    def get_candles(self, symbol, timeframe='1m', limit=50):
        try:
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            return df
        except Exception as e:
            logger.debug(f"Candle fetch failed {symbol}: {e}")
            return None

    def get_price(self, symbol):
        try:
            return self.exchange.fetch_ticker(symbol)['last']
        except Exception as e:
            logger.debug(f"Price fetch failed {symbol}: {e}")
            return None

    # ---------------------------------------------------------------- indicators
    def get_hourly_baseline_volume(self, symbol):
        try:
            data = self.exchange.fetch_ohlcv(symbol, '1h', limit=HOURLY_BASELINE_PERIODS)
            if not data or len(data) < 10:
                return None
            vols = [c[5] for c in data]
            return (sum(vols) / len(vols)) / 60.0   # per-minute baseline
        except Exception as e:
            logger.debug(f"Baseline failed {symbol}: {e}")
            return None

    def calculate_volume_macd(self, volumes):
        if len(volumes) < self.macd_slow:
            return None
        s = pd.Series(volumes)
        macd = s.ewm(span=self.macd_fast, adjust=False).mean() - s.ewm(span=self.macd_slow, adjust=False).mean()
        return abs(macd.iloc[-1])

    def candle_body_ratio(self, candle):
        rng = candle['high'] - candle['low']
        if rng == 0:
            return 0
        return abs(candle['close'] - candle['open']) / rng

    def find_local_resistance(self, symbol, timeframe):
        try:
            candles = self.exchange.fetch_ohlcv(symbol, timeframe, limit=RESISTANCE_LOOKBACK)
            if not candles or len(candles) < 10:
                return None, None
            highs = []
            for i in range(2, len(candles) - 2):
                h = candles[i][2]
                if (h > candles[i-1][2] and h > candles[i-2][2] and
                        h > candles[i+1][2] and h > candles[i+2][2]):
                    highs.append(h)
            cur = candles[-1][4]
            above = [r for r in highs if r > cur]
            if above:
                nearest = min(above)
                gap = ((nearest - cur) / cur) * 100
                return nearest, gap
            return None, None
        except Exception as e:
            logger.debug(f"Resistance failed {symbol} {timeframe}: {e}")
            return None, None

    def find_local_support(self, symbol, timeframe):
        """Mirror of find_local_resistance: the nearest swing LOW below current price.
        Used to place a stop just under real support instead of at an arbitrary %."""
        try:
            candles = self.exchange.fetch_ohlcv(symbol, timeframe, limit=RESISTANCE_LOOKBACK)
            if not candles or len(candles) < 10:
                return None, None
            lows = []
            for i in range(2, len(candles) - 2):
                lo = candles[i][3]
                if (lo < candles[i-1][3] and lo < candles[i-2][3] and
                        lo < candles[i+1][3] and lo < candles[i+2][3]):
                    lows.append(lo)
            cur = candles[-1][4]
            below = [s for s in lows if s < cur]
            if below:
                nearest = max(below)                       # closest support under price
                gap = ((cur - nearest) / cur) * 100
                return nearest, gap
            return None, None
        except Exception as e:
            logger.debug(f"Support failed {symbol} {timeframe}: {e}")
            return None, None

    def analyze_resistance(self, symbol):
        out = {}
        for tf in RESISTANCE_TIMEFRAMES:
            r, g = self.find_local_resistance(symbol, tf)
            out[tf] = {'resistance': r, 'gap': g}
        return out

    def find_local_low(self, symbol):
        try:
            candles = self.exchange.fetch_ohlcv(symbol, FIB_TIMEFRAME, limit=FIB_LOOKBACK)
            if not candles or len(candles) < 10:
                return None
            return min(c[3] for c in candles)
        except Exception as e:
            logger.debug(f"Local low failed {symbol}: {e}")
            return None

    # ---------------------------------------------------------------- detection
    def check_pump(self, symbol, df):
        """Return pump_data if a pump is detected at the RADAR threshold, else None.
        Sets meets_entry=True when it also clears the strict entry bar. Resistance
        is NOT computed here (deferred to entry candidates only, to save API calls)."""
        if df is None or len(df) < 10:
            return None

        recent = df.tail(3)
        p_start = recent.iloc[0]['open']
        p_end   = recent.iloc[-1]['close']
        change_pct = ((p_end - p_start) / p_start) * 100

        # Require a positive move — threshold being > 0 is sufficient to exclude dumps
        if change_pct < PUMP_THRESHOLD:
            return None

        last = recent.iloc[-1]

        # Sustained volume vs 24h baseline
        baseline = self.get_hourly_baseline_volume(symbol) if USE_HOURLY_BASELINE \
            else df['volume'].tail(20).mean()
        if not baseline:
            return None

        ratios = [row['volume'] / baseline for _, row in recent.iterrows()]
        # z-scores vs this coin's own recent volume (used in z-mode)
        zscores = None
        if USE_VOLUME_ZSCORE and len(df) >= ZSCORE_BASELINE_N + 3:
            hist = df['volume'].iloc[-(ZSCORE_BASELINE_N + 3):-3]
            mu, sigma = float(hist.mean()), float(hist.std())
            if sigma > 0:
                zscores = [(float(row['volume']) - mu) / sigma for _, row in recent.iterrows()]

        z_qualifies = bool(zscores) and all(z >= VOLUME_ZSCORE_MIN for z in zscores)
        radar_qualifies = all(r >= RADAR_VOLUME_MULTIPLIER for r in ratios)
        # Radar bar (loud) opens detection; in z-mode a statistically extreme pump
        # on a calm coin also qualifies even if the raw multiple is modest.
        if not (radar_qualifies or z_qualifies):
            return None
        # Entry bar (strict): fixed multiple by default, z-score when toggled.
        meets_entry = z_qualifies if USE_VOLUME_ZSCORE \
            else all(r >= VOLUME_MULTIPLIER for r in ratios)
        # ...plus confirmation that the pump is REAL and tradeable (not scored).
        if meets_entry:
            body_ok = self.candle_body_ratio(last) >= MIN_BODY_RATIO
            notional = float((recent['close'] * recent['volume']).sum())
            notional_ok = notional >= MIN_PUMP_NOTIONAL_USD
            breakout_ok = True
            if REQUIRE_BREAKOUT and len(df) >= BREAKOUT_LOOKBACK + 3:
                prior_high = float(df['high'].iloc[-(BREAKOUT_LOOKBACK + 3):-3].max())
                breakout_ok = float(last['close']) > prior_high
            meets_entry = body_ok and notional_ok and breakout_ok

        macd_val = self.calculate_volume_macd(df['volume'].values)
        cur_vol = last['volume']
        vol_vs_macd = (cur_vol / macd_val) if (macd_val and macd_val > 0) else None

        if REQUIRE_MACD and meets_entry and (vol_vs_macd is None or vol_vs_macd < MACD_MULTIPLIER):
            meets_entry = False

        # Looser ALERT bar (the screener feed): volume surge + a real price move, but
        # NO breakout requirement and a lighter notional floor. This is what surfaces
        # "pumps worth looking at" like the early versions — independent of the strict
        # TRADE gate above. A pump that meets_entry also meets_alert by construction.
        notional_all = float((recent['close'] * recent['volume']).sum())
        meets_alert = (
            all(r >= ALERT_VOLUME_MULTIPLIER for r in ratios)
            and abs(change_pct) >= ALERT_MIN_PRICE_PCT
            and notional_all >= ALERT_MIN_NOTIONAL_USD
        )
        if ALERT_REQUIRE_BREAKOUT and meets_alert and len(df) >= BREAKOUT_LOOKBACK + 3:
            prior_high = float(df['high'].iloc[-(BREAKOUT_LOOKBACK + 3):-3].max())
            meets_alert = float(last['close']) > prior_high
        meets_alert = meets_alert or meets_entry

        return {
            'symbol': symbol,
            'price_change_pct': round(change_pct, 2),
            'current_price': float(p_end),
            'volume_ratios': [round(r, 2) for r in ratios],
            'max_vol_ratio': round(max(ratios), 2),
            'volume_vs_macd': round(vol_vs_macd, 2) if vol_vs_macd else None,
            'body_ratio': round(self.candle_body_ratio(last), 2),
            'meets_entry': meets_entry,
            'meets_alert': meets_alert,
            'timestamp': time.time(),
        }

    # ---------------------------------------------------------------- radar feed
    def log_detection(self, pump, became_entry):
        """Append a pump to the rolling radar buffer that powers the website ticker."""
        clean = pump['symbol'].replace('/', '').replace(':USDT', '')
        self.radar.append({
            't': round(pump['timestamp'], 1),
            'time_str': datetime.now(timezone.utc).strftime('%H:%M:%S'),
            'symbol': clean,
            'pct': pump['price_change_pct'],
            'vol': pump['max_vol_ratio'],
            'price': pump['current_price'],
            'entry': bool(became_entry),
        })
        now = time.time()
        if now - self._last_radar_flush >= RADAR_FLUSH_SECONDS:
            self._flush_radar()

    def _flush_radar(self):
        try:
            with open(RADAR_FILE, 'w') as f:
                json.dump(list(self.radar), f)
            self._last_radar_flush = time.time()
        except Exception as e:
            logger.debug(f"radar flush failed: {e}")

    def register_pump_for_retrace(self, symbol, pump_high, ts):
        low = self.find_local_low(symbol)
        if low is None or low >= pump_high:
            return
        rng = pump_high - low
        fibs = {lvl: pump_high - rng * lvl for lvl in FIB_TRACK_LEVELS}
        self.pump_tracker[symbol] = {
            'local_low': low, 'pump_high': pump_high,
            'fib_levels': fibs, 'timestamp': ts,
        }
        logger.info(f"Tracking {symbol} for golden-pocket retrace: {low:.6g} -> {pump_high:.6g}")

    # ---------------------------------------------------------------- positions
    def has_open_position(self, symbol):
        return symbol in self.open_positions

    def _in_cooldown(self, symbol):
        return time.time() < self.cooldowns.get(symbol, 0)

    def _real_open_count(self):
        return sum(1 for p in self.open_positions.values() if not p.get('is_shadow'))

    def _open_risk_pct(self):
        return sum((p.get('risk_pct') or 0) for p in self.open_positions.values()
                   if not p.get('is_shadow'))

    def _day_extension_pct(self, symbol, price):
        """How far the coin has already run today (vs the daily open)."""
        try:
            d = self.exchange.fetch_ohlcv(symbol, '1d', limit=1)
            if d and len(d):
                day_open = float(d[-1][1])
                return (price - day_open) / day_open * 100 if day_open else None
        except Exception:
            return None
        return None

    def _spread_bps(self, symbol):
        try:
            t = self.exchange.fetch_ticker(symbol)
            bid, ask = t.get('bid'), t.get('ask')
            if bid and ask and ask > 0:
                return (ask - bid) / ((ask + bid) / 2) * 10000
        except Exception:
            return None
        return None

    def _portfolio_block(self):
        self._roll_day()
        if self.daily['pnl'] <= -DAILY_LOSS_LIMIT_PCT:
            return 'daily_kill'
        if self._real_open_count() >= MAX_CONCURRENT_TRADES:
            return 'max_concurrent'
        if self._open_risk_pct() >= MAX_PORTFOLIO_RISK_PCT:
            return 'max_risk'
        return None

    def open_position(self, symbol, strategy, entry_price, target_price, context,
                      stop_loss=None, is_shadow=False, size_factor=1.0, quant=None,
                      side='long'):
        if self.has_open_position(symbol):
            return None   # one position per ticker
        self.trade_counter += 1
        tid = f"T{self.trade_counter:05d}"
        if side == 'short':
            sl = stop_loss if stop_loss is not None else entry_price * (1 + SHORT_STOP_PCT / 100.0)
            risk_abs = sl - entry_price                      # stop is ABOVE entry
            r1_price = entry_price - PARTIAL_TP_R * risk_abs  # profit is DOWN
            tp1_basis = 'R'
        else:
            sl = stop_loss if stop_loss is not None else entry_price * (1 - STOP_LOSS_PCT / 100.0)
            risk_abs = entry_price - sl
            r1_price = entry_price + PARTIAL_TP_R * risk_abs
            tp1_basis = 'R'
            # Prefer the nearest resistance as TP1 if it sits in a sensible R range —
            # structure governs where we bank when it exists, +1R is the fallback.
            if TP1_USE_RESISTANCE and risk_abs > 0:
                res_levels = []
                for tf in ('4h', '1d'):
                    rv = (context.get('resistance') or {}).get(tf, {}).get('resistance')
                    if rv and rv > entry_price:
                        res_levels.append(rv)
                if res_levels:
                    nearest_res = min(res_levels)
                    res_r = (nearest_res - entry_price) / risk_abs
                    if TP1_RES_MIN_R <= res_r <= TP1_RES_MAX_R:
                        r1_price = nearest_res        # bank TP1 just at the wall
                        tp1_basis = 'resistance'
        risk_pct = abs(risk_abs) / entry_price * 100 if entry_price else 0
        atr_pct = ((quant or {}).get('factors', {}) or {}).get('atr_pct')
        atr_abs = entry_price * atr_pct / 100 if atr_pct else entry_price * 0.04
        pos = {
            'trade_id': tid,
            'symbol': symbol,
            'strategy': strategy,
            'side': side,
            'entry_price': entry_price,
            'target_price': target_price,
            'stop_loss': sl,
            'risk_abs': abs(risk_abs),
            'risk_pct': round(risk_pct, 2),
            'atr_abs': atr_abs,
            'r1_price': r1_price,
            'tp1_basis': tp1_basis,
            'remaining': 1.0,
            'partial_done': False,
            'realized_pnl_pct': 0.0,
            'is_shadow': bool(is_shadow),
            'size_factor': size_factor,
            'entry_time': time.time(),
            'peak_price': entry_price,
            'trough_price': entry_price,
            'quant': quant or {},
            'context': context,
        }
        self.open_positions[symbol] = pos
        self._save_state()
        return pos

    def update_excursions(self, pos, price):
        if price > pos['peak_price']:
            pos['peak_price'] = price
        if price < pos['trough_price']:
            pos['trough_price'] = price

    def close_position(self, symbol, exit_price, reason):
        pos = self.open_positions.pop(symbol, None)
        if not pos:
            return None
        entry = pos['entry_price']
        remaining = pos.get('remaining', 1.0)
        if pos.get('side') == 'short':
            raw_pnl = ((entry - exit_price) / entry) * 100    # short: profit when price falls
        else:
            raw_pnl = ((exit_price - entry) / entry) * 100
        realized = pos.get('realized_pnl_pct', 0.0)   # already size-weighted by partial fraction
        pnl_pct = realized + remaining * raw_pnl
        hold_min = (time.time() - pos['entry_time']) / 60.0
        if pos.get('side') == 'short':
            # for a short, the favorable excursion is DOWN (trough), adverse is UP (peak)
            peak_pnl = ((entry - pos['trough_price']) / entry) * 100    # best (price fell)
            trough_pnl = ((entry - pos['peak_price']) / entry) * 100    # worst (price rose)
        else:
            peak_pnl = ((pos['peak_price'] - entry) / entry) * 100
            trough_pnl = ((pos['trough_price'] - entry) / entry) * 100

        # R-multiple: P&L expressed in units of risk taken (the metric that matters)
        risk_pct = pos.get('risk_pct') or STOP_LOSS_PCT
        r_multiple = round(pnl_pct / risk_pct, 2) if risk_pct else 0
        # NET of estimated execution costs (fees + entry slippage) — how it would trade live
        net_pnl_pct = pnl_pct - COST_ROUND_TRIP_PCT
        net_r = round(net_pnl_pct / risk_pct, 2) if risk_pct else 0
        # size-weighted contribution for capital-aware aggregation
        size_factor = pos.get('size_factor', 1.0) or 1.0
        weighted_pnl = round(pnl_pct * size_factor, 2)

        bucket = self.shadow_stats if pos.get('is_shadow') else self.stats
        bucket['trades'] += 1
        bucket['pnl_sum'] += pnl_pct
        if pnl_pct > 0:
            bucket['wins'] += 1
        else:
            bucket['losses'] += 1

        # per-strategy running stats (real trades only) — separate win rate each
        if not pos.get('is_shadow'):
            ss = self.strat_stats.setdefault(
                pos.get('strategy', 'PUMP_BREAKOUT'),
                {'trades': 0, 'wins': 0, 'losses': 0, 'pnl_sum': 0.0})
            ss['trades'] += 1
            ss['pnl_sum'] += pnl_pct
            if pnl_pct > 0:
                ss['wins'] += 1
            else:
                ss['losses'] += 1

        # portfolio: track daily NET P&L (kill switch) and set per-symbol cooldown on a loss
        if not pos.get('is_shadow'):
            self._roll_day()
            self.daily['pnl'] += net_pnl_pct
            if pnl_pct <= 0:
                self.cooldowns[symbol] = time.time() + COOLDOWN_AFTER_LOSS_MIN * 60

        result = dict(pos)
        result.update({
            'exit_price': exit_price,
            'exit_reason': reason,
            'pnl_pct': round(pnl_pct, 2),
            'net_pnl_pct': round(net_pnl_pct, 2),
            'r_multiple': r_multiple,
            'net_r_multiple': net_r,
            'weighted_pnl_pct': weighted_pnl,
            'hold_minutes': round(hold_min, 1),
            'peak_pnl_pct': round(peak_pnl, 2),
            'trough_pnl_pct': round(trough_pnl, 2),
        })
        self._save_state()
        return result

    # ---------------------------------------------------------------- logging
    def _sheet_post(self, row):
        if not SHEET_WEBHOOK_URL:
            return
        try:
            data = json.dumps(row).encode('utf-8')
            req = urllib.request.Request(SHEET_WEBHOOK_URL, data=data,
                                         headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            logger.warning(f"Sheet log failed: {e}")

    def _quant_fields(self, pos):
        q = pos.get('quant', {}) or {}
        fac = q.get('factors', {}) or {}
        return {
            'score': q.get('score', ''), 'stars': q.get('stars', ''),
            'rr': q.get('rr', ''), 'mode': q.get('mode', ''),
            'data_confidence': q.get('data_confidence', ''),
            'is_shadow': pos.get('is_shadow', False),
            'size_factor': pos.get('size_factor', ''),
            'risk_pct': pos.get('risk_pct', ''),
            'vetoes': q.get('vetoes', ''),
            'acc_score': q.get('acc_score', ''),
            'acc_label': q.get('acc_label', ''),
            'atr_pct': fac.get('atr_pct', ''), 'rsi': fac.get('rsi', ''),
            'ext_atr': fac.get('ext_atr', ''), 'consec_green': fac.get('consec_green', ''),
            'oi_change_pct': fac.get('oi_change_pct', ''), 'funding': fac.get('funding', ''),
            'taker_ratio': fac.get('taker_ratio', ''), 'top_trader_ls': fac.get('top_trader_ls', ''),
            'btc_1h_pct': fac.get('btc_1h_pct', ''),
            # order-flow factors ported from Bot 1 (raw readings, for gatekeeper mining)
            'oi_zscore': fac.get('oi_zscore', ''), 'global_ls': fac.get('global_ls', ''),
            'cvd_slope': fac.get('cvd_slope', ''), 'price_slope': fac.get('price_slope', ''),
            'short_liq_ratio': fac.get('short_liq_ratio', ''),
            'basis_pct': fac.get('basis_pct', ''), 'htf_align': fac.get('htf_align', ''),
            'sym_1h_pct': fac.get('sym_1h_pct', ''),
            'liq_cascade': fac.get('liq_cascade', ''), 'btc_lead_15m': fac.get('btc_lead_15m', ''),
            'side': pos.get('side', 'long'),
            'short_tf': (pos.get('context') or {}).get('short_tf', ''),
            'short_dist_pct': (pos.get('context') or {}).get('short_dist_pct', ''),
            'ema_value': (pos.get('context') or {}).get('ema_value', ''),
            'contributions': '|'.join(f"{k}:{v}" for k, v in (q.get('contributions') or {}).items()),
        }

    def _csv_append_to(self, path, row):
        """Append a row to any CSV, writing the header on first use."""
        try:
            import csv as _csv
            new = not os.path.exists(path)
            with open(path, 'a', newline='') as f:
                w = _csv.DictWriter(f, fieldnames=list(row.keys()))
                if new:
                    w.writeheader()
                w.writerow(row)
        except Exception as e:
            logger.debug(f"csv append failed ({path}): {e}")

    def _csv_append(self, row):
        """Append a completed-trade row to the local CSV that feeds the website record."""
        self._csv_append_to(LOCAL_TRADES_CSV, row)

    def log_entry(self, pos):
        ctx = pos['context']
        r = ctx.get('resistance', {})
        row = {
            'event': 'ENTRY', 'trade_id': pos['trade_id'], 'timestamp': _utcnow_iso(),
            'symbol': pos['symbol'], 'strategy': pos['strategy'],
            'entry_price': pos['entry_price'], 'exit_price': '',
            'target_price': pos['target_price'], 'stop_loss': pos['stop_loss'],
            'exit_reason': '', 'pnl_pct': '', 'r_multiple': '', 'hold_minutes': '',
            'peak_price': '', 'peak_pnl_pct': '', 'trough_price': '', 'trough_pnl_pct': '',
            'resistance_4h': r.get('4h', {}).get('resistance', ''),
            'gap_4h_pct': r.get('4h', {}).get('gap', ''),
            'resistance_1d': r.get('1d', {}).get('resistance', ''),
            'gap_1d_pct': r.get('1d', {}).get('gap', ''),
            'volume_ratios': ' | '.join(str(x) for x in ctx.get('volume_ratios', [])),
            'volume_vs_macd': ctx.get('volume_vs_macd', ''), 'body_ratio': ctx.get('body_ratio', ''),
            'pump_high': ctx.get('pump_high', ''), 'local_low': ctx.get('local_low', ''),
            'fib_level': ctx.get('fib_level', ''), 'notes': ctx.get('notes', ''),
        }
        row.update(self._quant_fields(pos))
        self._sheet_post(row)

    def log_exit(self, result):
        row = {
            'event': 'EXIT', 'trade_id': result['trade_id'], 'timestamp': _utcnow_iso(),
            'symbol': result['symbol'], 'strategy': result['strategy'],
            'entry_price': result['entry_price'], 'exit_price': result['exit_price'],
            'target_price': result['target_price'], 'stop_loss': result['stop_loss'],
            'exit_reason': result['exit_reason'], 'pnl_pct': result['pnl_pct'],
            'net_pnl_pct': result.get('net_pnl_pct', ''),
            'r_multiple': result.get('r_multiple', ''),
            'net_r_multiple': result.get('net_r_multiple', ''),
            'weighted_pnl_pct': result.get('weighted_pnl_pct', ''),
            'hold_minutes': result['hold_minutes'],
            'peak_price': round(result['peak_price'], 8), 'peak_pnl_pct': result['peak_pnl_pct'],
            'trough_price': round(result['trough_price'], 8), 'trough_pnl_pct': result['trough_pnl_pct'],
            'resistance_4h': '', 'gap_4h_pct': '', 'resistance_1d': '', 'gap_1d_pct': '',
            'volume_ratios': '', 'volume_vs_macd': '', 'body_ratio': '',
            'pump_high': '', 'local_low': '', 'fib_level': '', 'notes': '',
        }
        row.update(self._quant_fields(result))
        self._sheet_post(row)
        self._csv_append(row)   # local history for the website track record

    # ---------------------------------------------------------------- telegram
    def _link(self, symbol):
        clean = symbol.replace('/', '').replace(':USDT', '')
        if EXCHANGE.lower() == 'binance':
            return f"https://www.binance.com/en/futures/{clean}"
        return f"https://www.bybit.com/trade/usdt/{clean}"

    async def tg_pump_signal(self, symbol, pump, q, decision, resistance=None, support=None):
        """Fire for EVERY scored pump (traded or not) so you see the full screener
        feed with its quant read. Deduped per symbol via PUMP_ALERT_COOLDOWN_MIN."""
        if not ALERT_EVERY_PUMP:
            return
        now = time.time()
        if now < self.pump_alerted.get(symbol, 0):
            return
        self.pump_alerted[symbol] = now + PUMP_ALERT_COOLDOWN_MIN * 60

        try:
            try:
                sc = float(q.get('score') or 0)
            except (TypeError, ValueError):
                sc = 0
            star_n = max(1, min(5, int(sc / 20) + 1))
            stars = '★' * star_n + '☆' * (5 - star_n)

            tag = {'TRADE': '🟢 TRADE', 'SHADOW': '⚪ SHADOW (tracked, not traded)',
                   'SKIP': '⛔ SKIP', 'alert_only': '👀 WATCH (not traded)'}.get(decision, str(decision))

            # Read: top factors by STRENGTH (each factor's closeness to its own max,
            # 0-1) — comparable across factors, unlike raw weighted contributions.
            strength = q.get('factor_strength') or {}
            nice = {'taker': 'taker buying', 'oi': 'open interest', 'regime': 'BTC regime',
                    'cvd': 'CVD', 'liq_organic': 'organic (not squeeze)', 'top_trader': 'smart money',
                    'rsi': 'RSI', 'extension': 'extension', 'basis': 'spot-led', 'htf_trend': 'HTF trend',
                    'rs_btc': 'rel strength', 'btc_lead': 'BTC tailwind', 'close_loc': 'close strength',
                    'smart_vs_retail': 'smart vs retail', 'liq_cascade': 'liq cascade', 'blowoff': 'blow-off'}
            def lbl(v):
                return 'maxed' if v >= 0.9 else 'strong' if v >= 0.7 else 'ok' if v >= 0.45 else 'weak'
            try:
                top = sorted(strength.items(), key=lambda kv: -kv[1])[:3]
                read = ', '.join(f"{nice.get(k, k)} {lbl(v)}" for k, v in top) if top else 'mixed'
            except Exception:
                read = 'mixed'

            acc = q.get('acc_score', 0) or 0
            acc_line = f"\n• 👁 Accumulation base: {acc}/100" if acc else ''

            vrs = pump.get('volume_ratios') or []
            vol_ladder = ' → '.join(f'{r}x' for r in vrs) if vrs else '?'
            pct = pump.get('price_change_pct', 0) or 0
            price = pump.get('current_price', 0) or 0
            vmacd = pump.get('volume_vs_macd')
            vmacd_line = f"\n• Vol vs MACD: {vmacd}x" if vmacd is not None else ''

            # support (nearest swing low below price) + 4h/1d resistance
            level_lines = ''
            if support:
                sgap = ((price - support) / price * 100) if price else 0
                level_lines += f"\n• Support: ${support:.6g} (-{sgap:.1f}% below)"
            r = resistance or {}
            r4 = r.get('4h', {}); r1 = r.get('1d', {})
            if r4.get('resistance'):
                level_lines += f"\n• 4h resistance: ${r4['resistance']:.6g} (+{r4.get('gap', 0):.1f}% away)"
            if r1.get('resistance'):
                level_lines += f"\n• 1d resistance: ${r1['resistance']:.6g} (+{r1.get('gap', 0):.1f}% away)"

            # explain the decision next to the score: which threshold it cleared/missed
            try:
                scv = float(q.get('score') or 0)
            except (TypeError, ValueError):
                scv = 0
            try:
                rrv = float(q.get('rr') or 0)
            except (TypeError, ValueError):
                rrv = 0
            # why this decision? Score+R:R gates first, then any downstream block
            # (the block is recorded in q['mode'] as BLOCK_xxx when a TRADE -> SHADOW).
            mode = str(q.get('mode', '') or '')
            block_labels = {
                'alert_only':    'alert only (vol <15x trade gate)',
                'cooldown':      'symbol in cooldown',
                'over_extended': 'over-extended on the day',
                'wide_spread':   'spread too wide',
                'max_risk':      'portfolio risk cap hit',
                'max_concurrent':'max open positions',
            }
            blk = next((lbl for key, lbl in block_labels.items() if mode == f'BLOCK_{key}'), None)
            if scv < SHADOW_MIN_SCORE:
                reason = f"score <{SHADOW_MIN_SCORE} → skip"
            elif scv < MIN_SCORE_TO_TRADE:
                reason = f"score {SHADOW_MIN_SCORE}–{MIN_SCORE_TO_TRADE} → shadow"
            elif rrv < MIN_RR:
                reason = f"R:R <{MIN_RR} → no trade"
            elif blk:
                reason = blk                     # passed score+R:R but a block downgraded it
            elif str(q.get('vetoes') or ''):
                reason = f"veto: {q.get('vetoes')}"
            else:
                reason = f"≥{MIN_SCORE_TO_TRADE} & R:R ≥{MIN_RR} → trade"
            # R:R pass/fail marker
            rr_mark = '✅' if rrv >= MIN_RR else '⚠️'

            msg = (f"📡 *PUMP SIGNAL* · score {q.get('score', 0)}/100 ({reason}) · {tag}\n\n"
                   f"*Pair:* `{symbol}`\n"
                   f"*Price:* ${price:.6g}\n"
                   f"*Pump:* {pct:+.1f}% in 3 min\n"
                   f"*Score:* {stars} {q.get('score', 0)} · R:R {q.get('rr', '?')} {rr_mark} · conf {q.get('data_confidence', '?')}\n"
                   f"• Volume: {vol_ladder} baseline{vmacd_line}{level_lines}\n"
                   f"• Driven by: {read}{acc_line}\n\n"
                   f"🔗 [Chart]({self._link(symbol)})")
            await self._send(msg)
            self._broadcast(msg)
        except Exception as e:
            logger.error(f"tg_pump_signal failed for {symbol}: {e}")

    async def tg_entry(self, pos):
        ctx = pos['context']
        if pos.get('side') == 'short':
            # short: target (EMA) is BELOW entry, stop is ABOVE
            tp_gap = ((pos['entry_price'] - pos['target_price']) / pos['entry_price']) * 100
            head = "🔻 *PAPER SHORT — EMA FADE* 🔻"
            extra = (f"\n• Overextended {ctx.get('short_dist_pct')}% above {ctx.get('short_tf')} EMA"
                     f"\n• Target = EMA reversion ${pos['target_price']:.6g}"
                     f"\n• Fading a hollow pump (squeeze / weak CVD)")
            q = pos.get('quant', {}) or {}
            quant_line = ""
            if q.get('score') not in (None, ''):
                quant_line = (f"\n\n*Quant gate (inverted):* score {q.get('score')}"
                              f"\n• Mode {q.get('mode','')} · conf {q.get('data_confidence')}")
                if q.get('acc_score'):
                    quant_line += f"\n• 👁 Accumulation: {q.get('acc_score')}/100"
            risk_pct = pos.get('risk_pct') or SHORT_STOP_PCT
            msg = (f"{head}\n\n"
                   f"*Pair:* `{pos['symbol']}`\n"
                   f"*Short entry:* ${pos['entry_price']:.6g}\n"
                   f"*Target (EMA):* ${pos['target_price']:.6g} (+{tp_gap:.1f}% on the short)\n"
                   f"*Stop:* ${pos['stop_loss']:.6g} (+{risk_pct:.1f}% above)"
                   f"{extra}{quant_line}\n\n"
                   f"🔗 [Chart]({self._link(pos['symbol'])})")
            await self._send(msg)
            self._broadcast(msg)
            return
        tp_gap = ((pos['target_price'] - pos['entry_price']) / pos['entry_price']) * 100
        if pos['strategy'] == 'PUMP_BREAKOUT':
            head = "🟢 *PAPER ENTRY — PUMP BREAKOUT* 🟢"
            extra = f"\n• Pump: +{ctx.get('price_change_pct')}% in 3 min" \
                    f"\n• Volume: {' → '.join(f'{r}x' for r in ctx.get('volume_ratios', []))} baseline" \
                    f"\n• Vol vs MACD: {ctx.get('volume_vs_macd', 'N/A')}x"
        else:
            head = "💎 *PAPER ENTRY — GOLDEN POCKET* 💎"
            extra = f"\n• Retrace into {ctx.get('fib_level')} fib" \
                    f"\n• Pump range: ${ctx.get('local_low'):.6g} → ${ctx.get('pump_high'):.6g}"
        q = pos.get('quant', {}) or {}
        risk_pct = pos.get('risk_pct') or STOP_LOSS_PCT
        quant_line = ""
        if q.get('score') is not None and q.get('score') != '':
            quant_line = (f"\n\n*Quant read:* {q.get('stars','')} score {q.get('score')}"
                          f"\n• R:R {q.get('rr')} · size ×{pos.get('size_factor',1)} · {q.get('mode','')}"
                          f"\n• Data conf {q.get('data_confidence')}")
            if q.get('acc_score'):
                quant_line += f"\n• 👁 Accumulation base: {q.get('acc_score')}/100 ({q.get('acc_label','')})"
        msg = (f"{head}\n\n"
               f"*Pair:* `{pos['symbol']}`\n"
               f"*Entry:* ${pos['entry_price']:.6g}\n"
               f"*Target:* ${pos['target_price']:.6g} (+{tp_gap:.1f}%)\n"
               f"*Stop:* ${pos['stop_loss']:.6g} (-{risk_pct:.1f}%)"
               f"{extra}{quant_line}\n\n"
               f"🔗 [Chart]({self._link(pos['symbol'])})")
        await self._send(msg)
        self._broadcast(msg)

    def log_partial(self, pos, fill_price, banked_pct):
        """Log the +1R partial take-profit as its own event row (P&L milestone)."""
        row = {
            'event': 'PARTIAL', 'trade_id': pos['trade_id'], 'timestamp': _utcnow_iso(),
            'symbol': pos['symbol'], 'strategy': pos['strategy'],
            'entry_price': pos['entry_price'], 'exit_price': round(fill_price, 8),
            'target_price': pos['target_price'], 'stop_loss': pos['stop_loss'],
            'exit_reason': 'PARTIAL_TP_1R', 'pnl_pct': round(banked_pct, 2),
            'net_pnl_pct': '', 'r_multiple': round(PARTIAL_TP_R, 2), 'net_r_multiple': '',
            'weighted_pnl_pct': '', 'hold_minutes': round((time.time() - pos['entry_time']) / 60, 1),
            'peak_price': round(pos['peak_price'], 8), 'peak_pnl_pct': '',
            'trough_price': round(pos['trough_price'], 8), 'trough_pnl_pct': '',
            'resistance_4h': '', 'gap_4h_pct': '', 'resistance_1d': '', 'gap_1d_pct': '',
            'volume_ratios': '', 'volume_vs_macd': '', 'body_ratio': '',
            'pump_high': '', 'local_low': '', 'fib_level': '', 'notes': f"TP1 ({pos.get('tp1_basis','R')}): banked {int(PARTIAL_TP_FRACTION*100)}%, stop->breakeven",
        }
        self._sheet_post(row)
        self._csv_append(row)

    async def tg_partial(self, pos, fill_price, banked_pct):
        frac = int(PARTIAL_TP_FRACTION * 100)
        msg = (f"🎯 *PARTIAL TAKE-PROFIT — +1R* 🎯\n\n"
               f"*Pair:* `{pos['symbol']}`\n"
               f"*Banked:* {frac}% of the position at ${fill_price:.6g} (+{banked_pct:.2f}% on that slice)\n"
               f"*Stop:* moved to breakeven (${pos['entry_price']:.6g}) — this trade can no longer lose\n"
               f"*Runner:* {100 - frac}% left, now trailing\n\n"
               f"🔗 [Chart]({self._link(pos['symbol'])})")
        await self._send(msg)
        self._broadcast(msg)

    async def tg_exit(self, r):
        win = r['pnl_pct'] > 0
        head = "✅ *PAPER EXIT — WIN*" if win else "🔻 *PAPER EXIT — LOSS*"
        reason = {'TARGET_HIT': 'Hit target', 'STOP_LOSS': 'Stopped out'}.get(r['exit_reason'], r['exit_reason'])
        wr = (self.stats['wins'] / self.stats['trades'] * 100) if self.stats['trades'] else 0
        # this strategy's own running win rate
        strat = r.get('strategy', 'PUMP_BREAKOUT')
        ss = self.strat_stats.get(strat, {})
        s_wr = (ss.get('wins', 0) / ss['trades'] * 100) if ss.get('trades') else 0
        s_name = {'PUMP_BREAKOUT': 'Pump Breakout', 'GOLDEN_POCKET': 'Golden Pocket',
                  'SHORT_REVERSION': 'Short Reversion'}.get(strat, strat)
        msg = (f"{head} ({r['strategy']})\n\n"
               f"*Pair:* `{r['symbol']}`\n"
               f"*Entry:* ${r['entry_price']:.6g}\n"
               f"*Exit:* ${r['exit_price']:.6g}  ({reason})\n"
               f"*P&L:* {r['pnl_pct']:+.2f}%  ({r.get('r_multiple','?')}R)\n"
               f"*Net (after est. costs):* {r.get('net_pnl_pct', r['pnl_pct']):+.2f}%\n"
               f"*Hold:* {r['hold_minutes']:.0f} min\n\n"
               f"📈 Best it reached: {r['peak_pnl_pct']:+.2f}%\n"
               f"📉 Worst drawdown: {r['trough_pnl_pct']:+.2f}%\n\n"
               f"📊 Running: {self.stats['trades']} trades · "
               f"{wr:.0f}% win · {self.stats['pnl_sum']:+.1f}% total\n"
               f"   ↳ {s_name}: {ss.get('trades',0)} trades · {s_wr:.0f}% win · "
               f"{ss.get('pnl_sum',0):+.1f}%")
        await self._send(msg)
        self._broadcast(msg)

    def _broadcast(self, msg):
        """Fan an alert out to every linked paid subscriber (non-blocking thread).
        Reads subscribers.json written by the web backend; uses the customer-facing
        alerts bot token so your own feed is independent."""
        if not (BROADCAST_ALERTS and ALERTS_BOT_TOKEN):
            return
        try:
            subs = json.load(open(SUBSCRIBERS_FILE)) if os.path.exists(SUBSCRIBERS_FILE) else []
        except Exception:
            subs = []
        chats = [s['chat_id'] for s in subs if s.get('tier') in BROADCAST_TIERS]
        if not chats:
            return

        def _fan():
            import urllib.parse
            for cid in chats:
                try:
                    data = urllib.parse.urlencode({'chat_id': cid, 'text': msg,
                                                   'parse_mode': 'Markdown'}).encode()
                    urllib.request.urlopen(
                        f'https://api.telegram.org/bot{ALERTS_BOT_TOKEN}/sendMessage',
                        data=data, timeout=10).read()
                    time.sleep(0.05)   # stay under Telegram's ~30 msg/s broadcast limit
                except Exception as e:
                    logger.debug(f"broadcast to {cid} failed: {e}")

        import threading
        threading.Thread(target=_fan, daemon=True).start()

    async def _send(self, text):
        # Telegram flood-limits a single chat to ~1 msg/sec. On restart a backlog
        # of exits can fire at once, so we space sends out and retry on flood limits
        # instead of silently dropping messages.
        for attempt in range(4):
            try:
                await self.bot.send_message(chat_id=self.chat_id, text=text,
                                            parse_mode='Markdown',
                                            disable_web_page_preview=True)
                await asyncio.sleep(1.1)   # stay under the per-chat rate limit
                return
            except RetryAfter as e:
                wait = int(getattr(e, 'retry_after', 5)) + 1
                logger.warning(f"Telegram flood limit, waiting {wait}s")
                await asyncio.sleep(wait)
            except (TimedOut, NetworkError) as e:
                logger.warning(f"Telegram network issue, retrying: {e}")
                await asyncio.sleep(3)
            except Exception as e:
                # Most often a 400 from malformed Markdown (a stray _ * [ ] ( in a
                # symbol or value). Don't drop the message — resend as PLAIN TEXT so
                # it still gets delivered, just without formatting.
                msg = str(e)
                if 'parse' in msg.lower() or '400' in msg or 'Bad Request' in msg:
                    try:
                        plain = text.replace('*', '').replace('_', '').replace('`', '')
                        await self.bot.send_message(chat_id=self.chat_id, text=plain,
                                                    disable_web_page_preview=True)
                        await asyncio.sleep(1.1)
                        logger.warning(f"Telegram Markdown rejected; sent as plain text. ({msg})")
                        return
                    except Exception as e2:
                        logger.error(f"Telegram plain-text fallback also failed (dropped): {e2}")
                        return
                logger.error(f"Telegram send failed (dropped): {e}")
                return

    # ---------------------------------------------------------------- accumulation
    def _load_json_into(self, path, attr):
        try:
            if os.path.exists(path):
                setattr(self, attr, json.load(open(path)) or {})
        except Exception as e:
            logger.debug(f"load {path} failed: {e}")

    def _dump_json(self, path, obj):
        try:
            with open(path, 'w') as f:
                json.dump(obj, f)
        except Exception as e:
            logger.debug(f"dump {path} failed: {e}")

    def _acc_lookup(self, symbol):
        """Fast cache read used by the pump path — no API calls."""
        return self.acc_cache.get(symbol, {})

    async def accumulation_loop(self):
        """Slow background loop. Rotates through the universe in chunks, scores each
        coin for accumulation, refreshes the cache, and maintains the watchlist."""
        if not self.acc:
            return
        pairs = self.get_futures_pairs()
        while True:
            try:
                if not pairs:
                    pairs = self.get_futures_pairs()
                chunk = pairs[self.acc_index:self.acc_index + ACC_SCAN_CHUNK]
                self.acc_index += ACC_SCAN_CHUNK
                if self.acc_index >= len(pairs):
                    self.acc_index = 0
                    pairs = self.get_futures_pairs()   # refresh universe each full sweep

                now = time.time()
                for symbol in chunk:
                    cached = self.acc_cache.get(symbol)
                    if cached and now - cached.get('ts', 0) < ACC_REFRESH_HOURS * 3600:
                        continue
                    res = self.acc.score_symbol(symbol)
                    if res:
                        res['ts'] = now
                        self.acc_cache[symbol] = res
                        await self._update_watchlist(symbol, res)
                    await asyncio.sleep(0.1)

                # prune stale cache entries to keep the file small
                self.acc_cache = {k: v for k, v in self.acc_cache.items()
                                  if now - v.get('ts', 0) < 24 * 3600}
                self._dump_json(ACC_FILE, self.acc_cache)
                await self._watchlist_maintenance()
                logger.info(f"Accumulation: scanned {len(chunk)} | cache {len(self.acc_cache)} | watchlist {len(self.watchlist)}")
                await asyncio.sleep(ACC_SCAN_INTERVAL)
            except Exception as e:
                logger.error(f"Accumulation loop error: {e}")
                await asyncio.sleep(ACC_SCAN_INTERVAL)

    async def _update_watchlist(self, symbol, res):
        score = res['score']
        if score >= WATCHLIST_ADD and symbol not in self.watchlist:
            self.watchlist[symbol] = {
                'added_ts': time.time(), 'score': score, 'peak_score': score,
                'label': res['label'], 'signals': res.get('signals', {}),
                'oi_change_pct': res.get('oi_change_pct'),
            }
            self._dump_json(WATCHLIST_FILE, self.watchlist)
            await self._send(
                f"👁 *STALKING — accumulation* 👁\n\n"
                f"*Pair:* `{symbol.replace('/', '').replace(':USDT', '')}`\n"
                f"*Accumulation score:* {score}/100\n"
                f"*Read:* {res['label']}\n\n"
                f"_Setting up — not a trade. If it pumps, the breakout gets boosted conviction._")
        elif symbol in self.watchlist:
            w = self.watchlist[symbol]
            w['score'] = score
            w['peak_score'] = max(w.get('peak_score', score), score)
            w['label'] = res['label']

    async def _watchlist_maintenance(self):
        now = time.time()
        changed = False
        for symbol in list(self.watchlist.keys()):
            w = self.watchlist[symbol]
            cur = self.acc_cache.get(symbol, {}).get('score', w.get('score', 0))
            age_h = (now - w.get('added_ts', now)) / 3600
            if cur < WATCHLIST_DROP or age_h > WATCHLIST_MAX_AGE_H:
                outcome = 'FADED' if cur < WATCHLIST_DROP else 'EXPIRED'
                self._csv_append_to(WATCHLIST_OUTCOMES_CSV, {
                    'symbol': symbol, 'outcome': outcome,
                    'added_ts': round(w.get('added_ts', now)),
                    'resolved_ts': round(now),
                    'days_stalked': round(age_h / 24, 1),
                    'peak_score': w.get('peak_score', w.get('score', 0)),
                    'final_score': cur, 'label': w.get('label', ''),
                })
                del self.watchlist[symbol]; changed = True
        if changed:
            self._dump_json(WATCHLIST_FILE, self.watchlist)
        # periodic digest of the strongest coils
        if WATCHLIST_DIGEST_HOURS and now - self._last_digest > WATCHLIST_DIGEST_HOURS * 3600:
            self._last_digest = now
            if self.watchlist:
                top = sorted(self.watchlist.items(), key=lambda kv: kv[1].get('score', 0), reverse=True)[:8]
                lines = [f"• `{s.replace('/', '').replace(':USDT', '')}` — {w['score']} · {w['label']}"
                         for s, w in top]
                await self._send("👁 *Accumulation watchlist* (top coils)\n\n" + "\n".join(lines))

    async def _watchlist_breakout(self, symbol, pump_score, acc_score):
        """Called when a watched coil finally pumps — resolve and announce."""
        if symbol in self.watchlist:
            w = self.watchlist.pop(symbol)
            self._dump_json(WATCHLIST_FILE, self.watchlist)
            now = time.time()
            held_d = (now - w.get('added_ts', now)) / 86400
            self._csv_append_to(WATCHLIST_OUTCOMES_CSV, {
                'symbol': symbol, 'outcome': 'BREAKOUT',
                'added_ts': round(w.get('added_ts', now)),
                'resolved_ts': round(now),
                'days_stalked': round(held_d, 1),
                'peak_score': w.get('peak_score', w.get('score', 0)),
                'final_score': w.get('score', 0), 'label': w.get('label', ''),
            })
            await self._send(
                f"🚀 *WATCHLIST BREAKOUT* 🚀\n\n"
                f"*Pair:* `{symbol.replace('/', '').replace(':USDT', '')}`\n"
                f"Stalked {held_d:.1f}d (acc peaked {w.get('peak_score')}). The pump just fired — "
                f"trading it with boosted conviction (pump {pump_score}, base {acc_score}).")

    # ---------------------------------------------------------------- state
    def _save_state(self):
        try:
            with open(STATE_FILE, 'w') as f:
                json.dump({
                    'open_positions': self.open_positions,
                    'pump_tracker': self.pump_tracker,
                    'trade_counter': self.trade_counter,
                    'stats': self.stats,
                    'shadow_stats': self.shadow_stats,
                    'strat_stats': self.strat_stats,
                    'cooldowns': self.cooldowns,
                    'daily': self.daily,
                    'last_summary_date': self.last_summary_date,
                }, f)
        except Exception as e:
            logger.warning(f"State save failed: {e}")

    def _load_state(self):
        if not os.path.exists(STATE_FILE):
            return
        try:
            with open(STATE_FILE) as f:
                s = json.load(f)
            self.open_positions = s.get('open_positions', {})
            self.pump_tracker = s.get('pump_tracker', {})
            self.trade_counter = s.get('trade_counter', 0)
            self.stats = s.get('stats', self.stats)
            self.shadow_stats = s.get('shadow_stats', self.shadow_stats)
            self.strat_stats = s.get('strat_stats', self.strat_stats)
            self.cooldowns = s.get('cooldowns', {})
            self.daily = s.get('daily', self.daily)
            self.last_summary_date = s.get('last_summary_date', '')
            logger.info(f"Restored {len(self.open_positions)} open positions, "
                        f"{len(self.pump_tracker)} tracked pumps")
        except Exception as e:
            logger.warning(f"State load failed: {e}")

    # ---------------------------------------------------------------- monitor
    def _roll_day(self):
        import datetime as _dt
        today = _dt.datetime.now(_dt.timezone.utc).strftime('%Y-%m-%d')
        if self.daily.get('date') != today:
            self.daily = {'date': today, 'pnl': 0.0}

    async def monitor_open_positions(self):
        for symbol in list(self.open_positions.keys()):
            pos = self.open_positions[symbol]
            df = self.get_candles(symbol, '1m', limit=3)
            if df is not None and not df.empty:
                hi = float(df['high'].max()); lo = float(df['low'].min())
                cur = float(df['close'].iloc[-1])
            else:
                price = self.get_price(symbol)
                if price is None:
                    await asyncio.sleep(0.05); continue
                hi = lo = cur = price

            self.update_excursions(pos, hi)
            self.update_excursions(pos, lo)
            entry = pos['entry_price']
            is_short = pos.get('side') == 'short'

            if is_short:
                # ---- SHORT management (everything inverted vs a long) ----
                if USE_EXIT_MANAGEMENT:
                    # partial at +1R (price fell to r1) -> bank, stop to breakeven
                    if not pos.get('partial_done') and lo <= pos.get('r1_price', float('-inf')):
                        partial_raw = ((entry - pos['r1_price']) / entry) * 100
                        pos['realized_pnl_pct'] += PARTIAL_TP_FRACTION * partial_raw
                        pos['remaining'] = round(pos['remaining'] - PARTIAL_TP_FRACTION, 4)
                        pos['partial_done'] = True
                        if MOVE_TO_BREAKEVEN:
                            pos['stop_loss'] = min(pos['stop_loss'], entry)
                        logger.info(f"PARTIAL {symbol} (short) +1R booked, stop->breakeven")
                        if not pos.get('is_shadow'):
                            self.log_partial(pos, pos['r1_price'], partial_raw)
                            await self.tg_partial(pos, pos['r1_price'], partial_raw)
                    # trail the runner DOWN with the trough once partial is done
                    if USE_TRAILING_STOP and pos.get('partial_done') and pos.get('atr_abs'):
                        pos['stop_loss'] = min(pos['stop_loss'],
                                               pos['trough_price'] + TRAIL_ATR_MULT * pos['atr_abs'])

                # resolve exits: stop is ABOVE (price rose to it), target is BELOW (EMA)
                if hi >= pos['stop_loss']:
                    reason = 'TRAIL_STOP' if pos.get('partial_done') and pos['stop_loss'] <= entry else 'STOP_LOSS'
                    r = self.close_position(symbol, pos['stop_loss'], reason)
                    self.log_exit(r)
                    if not r.get('is_shadow'): await self.tg_exit(r)
                    logger.info(f"{'SHADOW-' if r.get('is_shadow') else ''}EXIT {symbol} (short) {reason} {r['pnl_pct']:+.2f}% ({r.get('r_multiple')}R)")
                elif lo <= pos['target_price']:
                    r = self.close_position(symbol, pos['target_price'], 'TARGET_HIT')
                    self.log_exit(r)
                    if not r.get('is_shadow'): await self.tg_exit(r)
                    logger.info(f"{'SHADOW-' if r.get('is_shadow') else ''}EXIT {symbol} (short) TARGET {r['pnl_pct']:+.2f}% ({r.get('r_multiple')}R)")
                elif (time.time() - pos['entry_time']) / 60.0 >= SHORT_TIME_STOP_MIN:
                    # reversion should be fast; if it stalls (price consolidating, EMA
                    # catching up) exit — the snap-back isn't coming. (Your own rule.)
                    r = self.close_position(symbol, cur, 'TIME_STOP')
                    self.log_exit(r)
                    if not r.get('is_shadow'): await self.tg_exit(r)
                    logger.info(f"{'SHADOW-' if r.get('is_shadow') else ''}EXIT {symbol} (short) TIME_STOP {r['pnl_pct']:+.2f}%")
                else:
                    self._save_state()
                await asyncio.sleep(0.05)
                continue

            if USE_EXIT_MANAGEMENT:
                # 0) EARLY breakeven safety: if the trade ran up to +EARLY_BE_TRIGGER_R
                #    but hasn't hit TP1 yet, lift the stop toward breakeven so a stall
                #    can't round-trip a good gain into a loss (the KERNEL problem).
                if not pos.get('partial_done') and pos.get('risk_abs'):
                    fav_r = (hi - entry) / pos['risk_abs'] if pos['risk_abs'] else 0
                    if fav_r >= EARLY_BE_TRIGGER_R:
                        pos['stop_loss'] = max(pos['stop_loss'], entry)  # never lower
                # 1) partial take-profit at TP1 -> bank a third, move stop to breakeven
                if not pos.get('partial_done') and hi >= pos.get('r1_price', float('inf')):
                    partial_raw = ((pos['r1_price'] - entry) / entry) * 100
                    pos['realized_pnl_pct'] += PARTIAL_TP_FRACTION * partial_raw
                    pos['remaining'] = round(pos['remaining'] - PARTIAL_TP_FRACTION, 4)
                    pos['partial_done'] = True
                    if MOVE_TO_BREAKEVEN:
                        pos['stop_loss'] = max(pos['stop_loss'], entry)
                    logger.info(f"PARTIAL {symbol} +1R booked, stop->breakeven")
                    # surface the P&L milestone: alert + log (real trades only)
                    if not pos.get('is_shadow'):
                        self.log_partial(pos, pos['r1_price'], partial_raw)
                        await self.tg_partial(pos, pos['r1_price'], partial_raw)
                # 2) trail the runner via chandelier once partial is done.
                #    The leash TIGHTENS as the runner gains (progressive), so a big move
                #    can't give back most of its profit — but stays uncapped, so a true
                #    parabolic keeps running on a shorter trail.
                if USE_TRAILING_STOP and pos.get('partial_done') and pos.get('atr_abs'):
                    mult = TRAIL_ATR_MULT
                    if TRAIL_PROGRESSIVE and pos.get('risk_abs'):
                        run_r = (pos['peak_price'] - entry) / pos['risk_abs'] if pos['risk_abs'] else 0
                        if run_r >= TRAIL_TIER_2_R:
                            mult = TRAIL_TIER_2_MULT      # deep profit -> tight leash
                        elif run_r >= TRAIL_TIER_1_R:
                            mult = TRAIL_TIER_1_MULT      # medium profit -> medium leash
                    pos['stop_loss'] = max(pos['stop_loss'], pos['peak_price'] - mult * pos['atr_abs'])

            # 3) resolve exits (conservative: stop checked first)
            if lo <= pos['stop_loss']:
                reason = 'TRAIL_STOP' if pos.get('partial_done') and pos['stop_loss'] >= entry else 'STOP_LOSS'
                r = self.close_position(symbol, pos['stop_loss'], reason)
                self.log_exit(r)
                if not r.get('is_shadow'): await self.tg_exit(r)
                logger.info(f"{'SHADOW-' if r.get('is_shadow') else ''}EXIT {symbol} {reason} {r['pnl_pct']:+.2f}% ({r.get('r_multiple')}R)")
            elif hi >= pos['target_price']:
                r = self.close_position(symbol, pos['target_price'], 'TARGET_HIT')
                self.log_exit(r)
                if not r.get('is_shadow'): await self.tg_exit(r)
                logger.info(f"{'SHADOW-' if r.get('is_shadow') else ''}EXIT {symbol} TARGET {r['pnl_pct']:+.2f}% ({r.get('r_multiple')}R)")
            else:
                # NO time-stop on momentum trades (breakout / golden pocket): the
                # structure stop under support defines the risk, and the trade is
                # given room + time to develop. (Time-stops are for mean-reversion
                # shorts only, where a stalled snap-back means the thesis failed.)
                self._save_state()
            await asyncio.sleep(0.05)

    async def check_short_reversion(self):
        """Strategy C: short pairs overextended above their short EMA, targeting a
        snap-back to the EMA. Three independent timeframe triggers. The quant score
        is INVERTED as a gatekeeper — only short hollow (squeeze/weak-CVD) pumps."""
        if not SHORT_REVERSION_ENABLED or self.scorer is None:
            return
        n_short = sum(1 for p in self.open_positions.values() if p.get('side') == 'short')
        if n_short >= SHORT_MAX_CONCURRENT:
            return
        # don't short into a market-wide rip
        btc = self.scorer._btc_regime()
        if btc is not None and btc >= SHORT_VETO_BTC_PUMP_PCT:
            return

        for symbol in list(self.short_candidates):
            self.short_candidates.discard(symbol)
            if self.has_open_position(symbol) or self._in_short_cooldown(symbol):
                continue
            trig = self._short_trigger(symbol)
            if not trig:
                continue
            tf, dist_pct, ema_val, price, smooth, bb_up = trig

            # ---- inverted gatekeeper: only short a HOLLOW pump ----
            df1 = self.get_candles(symbol, '1m', limit=50)
            if df1 is None or df1.empty:
                continue
            q = self.scorer.evaluate(symbol, df1, {'current_price': price}, {})
            fac = q.get('factors', {})
            slr = fac.get('short_liq_ratio')
            cvd_s = fac.get('cvd_slope'); px_s = fac.get('price_slope')
            basis = fac.get('basis_pct'); funding = fac.get('funding')
            acc = self._acc_lookup(symbol); acc_score = acc.get('score', 0) if acc else 0
            top_ls = fac.get('top_trader_ls')

            hollow = False
            if slr is not None and slr >= 0.5:                 # mostly squeeze
                hollow = True
            if cvd_s is not None and px_s is not None and px_s > 0 and cvd_s <= 0:
                hollow = True                                   # price up, CVD not = weak
            if basis is not None and basis > 0.1:               # perp-led froth
                hollow = True
            if funding is not None and funding > 0.05:          # crowded longs
                hollow = True

            organic = False
            if cvd_s is not None and px_s is not None and cvd_s > 0 and px_s > 0:
                organic = True                                  # real buying
            if top_ls is not None and top_ls > 1.3:             # smart money long
                organic = True
            if acc_score >= ACC_BOOST_MIN:                      # strong accumulation base
                organic = True

            if SHORT_MIN_SQUEEZE_OR_WEAKCVD and not hollow:
                continue
            if SHORT_VETO_IF_ORGANIC and organic:
                continue

            # ---- size the stop: wide, but risk stays small via size_factor ----
            stop_price = price * (1 + SHORT_STOP_PCT / 100.0)
            if SHORT_STOP_ATR_BUFFER:
                atr_pct = fac.get('atr_pct') or 4.0
                atr_stop = price * (1 + 1.5 * atr_pct / 100.0)
                stop_price = max(stop_price, atr_stop)          # never tighter than ATR buffer
            target = ema_val                                    # revert to the EMA
            # R:R for the short: reward = distance to EMA, risk = distance to stop
            reward = price - target
            risk = stop_price - price
            short_rr = round(reward / risk, 2) if risk > 0 else 0

            ctx = {'notes': f'short_reversion {tf} +{dist_pct:.1f}% over EMA',
                   'resistance': {}, 'short_tf': tf, 'short_dist_pct': round(dist_pct, 2),
                   'ema_value': round(ema_val, 8), 'ema_smooth': round(smooth, 8) if smooth else '',
                   'bb_upper': round(bb_up, 8) if bb_up else '',
                   'volume_ratios': []}
            pos = self.open_position(
                symbol, 'SHORT_REVERSION', entry_price=price, target_price=target,
                context=ctx, stop_loss=stop_price, side='short',
                quant={'score': q['score'], 'stars': q.get('stars', 0),
                       'rr': short_rr, 'mode': f'SHORT_{tf}',
                       'data_confidence': q.get('data_confidence', ''),
                       'risk_pct': round((stop_price - price) / price * 100, 2),
                       'vetoes': '', 'contributions': q.get('contributions', {}),
                       'acc_score': acc_score, 'acc_label': (acc or {}).get('label', ''),
                       'factors': fac})
            if pos:
                self.log_entry(pos)
                await self.tg_entry(pos)
                self.short_cooldowns[symbol] = time.time() + SHORT_COOLDOWN_MIN * 60
                logger.info(f"SHORT {symbol} {tf} +{dist_pct:.1f}% over EMA -> target {target:.6g} "
                            f"stop {stop_price:.6g} score(inv-gate) {q['score']}")

    def _short_trigger(self, symbol):
        """Return (tf, dist_pct, ema, price, smooth, bb_upper) for the first timeframe
        whose price is over its threshold above the EMA, else None."""
        for tf, thresh in SHORT_TRIGGERS:
            df = self.get_candles(symbol, tf, limit=max(SHORT_EMA_LENGTH + SHORT_EMA_SMOOTHING + 5, 40))
            if df is None or len(df) < SHORT_EMA_LENGTH + 2:
                continue
            closes = df['close']
            ema = closes.ewm(span=SHORT_EMA_LENGTH, adjust=False).mean()
            ema_val = float(ema.iloc[-1])
            price = float(closes.iloc[-1])
            if ema_val <= 0:
                continue
            dist_pct = (price - ema_val) / ema_val * 100
            if dist_pct >= thresh:
                # smoothing line (SMA of the EMA) + bollinger upper — logged for tuning
                smooth = float(ema.rolling(SHORT_EMA_SMOOTHING).mean().iloc[-1]) if len(ema) >= SHORT_EMA_SMOOTHING else None
                std = float(ema.rolling(SHORT_EMA_SMOOTHING).std().iloc[-1]) if len(ema) >= SHORT_EMA_SMOOTHING else None
                bb_up = (smooth + SHORT_BB_STD * std) if (smooth is not None and std is not None) else None
                return tf, dist_pct, ema_val, price, smooth, bb_up
        return None

    def _in_short_cooldown(self, symbol):
        return time.time() < self.short_cooldowns.get(symbol, 0)

    async def check_golden_pocket_entries(self):
        now = time.time()
        for symbol in list(self.pump_tracker.keys()):
            data = self.pump_tracker[symbol]
            if now - data['timestamp'] > RETRACE_TRACK_HOURS * 3600:
                del self.pump_tracker[symbol]; continue
            if self.has_open_position(symbol):
                continue
            price = self.get_price(symbol)
            if price is None:
                continue
            baseline = self.get_hourly_baseline_volume(symbol)
            if not baseline:
                continue
            df = self.get_candles(symbol, '1m', limit=5)
            if df is None or df.empty:
                continue
            cur_vol = df.iloc[-1]['volume']
            vol_ratio = cur_vol / baseline if baseline else 0

            low = data['local_low']; high = data['pump_high']
            rng = high - low
            if rng <= 0:
                continue
            # current retrace depth (0 = at the high, 1 = full retrace to the low)
            retrace = (high - price) / rng if rng else 0
            # remember the DEEPEST retrace this pump reached (logged when/if it fills,
            # and useful to see how many pumps even reach 0.786)
            data['max_retrace'] = max(data.get('max_retrace', 0), retrace)

            # entry band: the 0.786 line (with a little width up to 0.75)
            in_entry_band = FIB_ENTRY_LOW <= retrace <= FIB_ENTRY_HIGH
            if in_entry_band and vol_ratio >= FIB_VOLUME_REQUIRED:
                ctx = {
                    'fib_level': round(retrace, 3),          # exact retrace where it filled
                    'local_low': low,
                    'pump_high': high,
                    'volume_ratios': [round(vol_ratio, 2)],
                    'notes': f'fib {retrace:.3f} bounce (target 0.786 band)',
                    'resistance': {},
                }
                pos = self.open_position(symbol, 'GOLDEN_POCKET',
                                         entry_price=price,
                                         target_price=high,
                                         context=ctx)
                if pos:
                    self.log_entry(pos); await self.tg_entry(pos)
                    logger.info(f"ENTRY {symbol} GOLDEN_POCKET @ {price:.6g} (retrace {retrace:.3f})")
                del self.pump_tracker[symbol]
                break

    # ---------------------------------------------------------------- scan
    async def scan_for_pumps(self, pairs):
        for symbol in pairs:
            try:
                df = self.get_candles(symbol, '1m', limit=50)
                pump = self.check_pump(symbol, df)
                if not pump:
                    await asyncio.sleep(0.05); continue

                # The screener feed scores + alerts on the LOOSER bar (meets_alert);
                # actual TRADES still require the strict meets_entry gate below.
                became_entry = False
                if pump.get('meets_alert') and not self.has_open_position(symbol):
                    resistance = self.analyze_resistance(symbol)
                    # nearest swing support below price (for a structure-based stop)
                    support = None
                    if pump['meets_entry']:
                        sups = [self.find_local_support(symbol, tf)[0] for tf in RESISTANCE_TIMEFRAMES]
                        sups = [s for s in sups if s and s < pump['current_price']]
                        support = max(sups) if sups else None
                    if pump['meets_entry']:
                        self.register_pump_for_retrace(symbol, pump['current_price'], pump['timestamp'])

                    # Gate + portfolio checks. A block doesn't discard the signal —
                    # it downgrades a would-be trade to SHADOW so we still track it.
                    block = self._portfolio_block()
                    if not block and self._in_cooldown(symbol):
                        block = 'cooldown'
                    if not block and not pump['meets_entry']:
                        block = 'alert_only'   # passed alert bar but not the strict trade gate
                    if not block:
                        day_ext = self._day_extension_pct(symbol, pump['current_price'])
                        if day_ext is not None and day_ext > MAX_DAY_EXTENSION_PCT:
                            block = 'over_extended'
                    if not block:
                        spread = self._spread_bps(symbol)
                        if spread is not None and spread > MAX_SPREAD_BPS:
                            block = 'wide_spread'

                    if self.scorer is not None:
                        q = self.scorer.evaluate(symbol, df, pump, resistance, support=support)
                        decision = q['decision']

                        # --- accumulation conviction multiplier (cache lookup, no API) ---
                        acc = self._acc_lookup(symbol)
                        acc_score = acc.get('score', 0) if acc else 0
                        if acc_score >= ACC_BOOST_MIN and not block:
                            frac = (acc_score - ACC_BOOST_MIN) / (100 - ACC_BOOST_MIN)
                            q['size_factor'] = round(q['size_factor'] * (1 + ACC_SIZE_BONUS * frac), 2)
                            boosted_score = min(100, q['score'] + ACC_SCORE_BONUS * frac)
                            # a strong base can upgrade a borderline shadow to a real trade
                            if (ACC_CAN_UPGRADE and decision == 'SHADOW'
                                    and q['score'] >= MIN_SCORE_TO_TRADE - ACC_UPGRADE_WINDOW
                                    and boosted_score >= MIN_SCORE_TO_TRADE
                                    and q['rr'] >= MIN_RR and q['vetoes'] == ''):
                                decision = 'TRADE'
                                q['mode'] = 'ACCUM_BREAKOUT'
                            q['score'] = round(boosted_score)
                            q['acc_score'] = acc_score
                            q['acc_label'] = acc.get('label', '')

                        if block and decision == 'TRADE':
                            decision = 'SHADOW'             # tracked, not traded
                            q['mode'] = f'BLOCK_{block}'

                        # alert on EVERY scored pump (traded or not) — the screener feed
                        await self.tg_pump_signal(symbol, pump, q, decision, resistance, support)

                        # 'alert_only' pumps passed the looser screener bar but not the
                        # strict trade gate — surface them, but don't open a tracked
                        # position (they're for looking at, like the early versions).
                        if block == 'alert_only':
                            decision = 'SKIP'

                        if decision != 'SKIP':
                            ctx = {
                                'price_change_pct': pump['price_change_pct'],
                                'volume_ratios': pump['volume_ratios'],
                                'volume_vs_macd': pump['volume_vs_macd'],
                                'body_ratio': pump['body_ratio'],
                                'resistance': resistance,
                                'notes': q['mode'],
                            }
                            is_shadow = (decision == 'SHADOW')
                            pos = self.open_position(
                                symbol, 'PUMP_BREAKOUT',
                                entry_price=pump['current_price'],
                                target_price=q['target'], context=ctx,
                                stop_loss=q['stop'], is_shadow=is_shadow,
                                size_factor=q['size_factor'],
                                quant={'score': q['score'], 'stars': q['stars'],
                                       'rr': q['rr'], 'mode': q['mode'],
                                       'data_confidence': q['data_confidence'],
                                       'risk_pct': q['risk_pct'], 'vetoes': q['vetoes'],
                                       'contributions': q['contributions'],
                                       'acc_score': q.get('acc_score', 0),
                                       'acc_label': q.get('acc_label', ''),
                                       'factors': q['factors']})
                            if pos:
                                self.log_entry(pos)
                                if not is_shadow:
                                    became_entry = True
                                    if q.get('acc_score', 0) >= WATCHLIST_ADD or symbol in self.watchlist:
                                        await self._watchlist_breakout(symbol, q['score'], q.get('acc_score', 0))
                                    await self.tg_entry(pos)
                                logger.info(f"{'SHADOW' if is_shadow else 'ENTRY'} {symbol} "
                                            f"score={q['score']} rr={q['rr']} {q['mode']} "
                                            f"stop={q['risk_pct']}% conf={q['data_confidence']}")
                    else:
                        # fallback: original gap>5% + flat stop behaviour
                        gap_4h = resistance.get('4h', {}).get('gap')
                        res_4h = resistance.get('4h', {}).get('resistance')
                        if gap_4h is not None and gap_4h > ENTRY_MIN_4H_GAP_PCT and res_4h is not None:
                            ctx = {'price_change_pct': pump['price_change_pct'],
                                   'volume_ratios': pump['volume_ratios'],
                                   'volume_vs_macd': pump['volume_vs_macd'],
                                   'body_ratio': pump['body_ratio'],
                                   'resistance': resistance, 'notes': 'sustained pump'}
                            pos = self.open_position(symbol, 'PUMP_BREAKOUT',
                                                     entry_price=pump['current_price'],
                                                     target_price=res_4h, context=ctx)
                            if pos:
                                became_entry = True
                                self.log_entry(pos); await self.tg_entry(pos)
                                logger.info(f"ENTRY {symbol} PUMP_BREAKOUT (fallback)")

                # Every detection (loud or not) goes to the live radar feed
                self.log_detection(pump, became_entry)
                # a pumped coin is a candidate to FADE (Strategy C checks the EMA trigger)
                if SHORT_REVERSION_ENABLED:
                    self.short_candidates.add(symbol)
                await asyncio.sleep(0.05)
            except Exception as e:
                logger.warning(f"Scan error {symbol}: {e}")
                continue

    def _build_daily_summary(self, day):
        """Read the trade log for `day` (UTC date string) and build a per-strategy
        scorecard from real EXIT rows. Reading the CSV keeps it accurate across
        restarts and matches the website / sheet."""
        import csv as _csv
        rows = []
        if os.path.exists(LOCAL_TRADES_CSV):
            try:
                with open(LOCAL_TRADES_CSV, newline='') as f:
                    for r in _csv.DictReader(f):
                        if (r.get('event') or '').upper() != 'EXIT':
                            continue
                        if str(r.get('is_shadow')).lower() in ('true', '1'):
                            continue
                        if not str(r.get('timestamp', '')).startswith(day):
                            continue
                        rows.append(r)
            except Exception as e:
                logger.debug(f"daily summary read: {e}")

        def fnum(x):
            try:
                return float(x)
            except (TypeError, ValueError):
                return 0.0

        if not rows:
            return f"📅 *Daily summary — {day}*\n\nNo closed trades today. The screener stayed selective."

        lines = [f"📅 *Daily summary — {day}*\n"]
        overall_n = overall_w = 0
        overall_pnl = overall_net = 0.0
        for strat, nice in (('PUMP_BREAKOUT', 'Pump Breakout'), ('GOLDEN_POCKET', 'Golden Pocket'),
                            ('SHORT_REVERSION', 'Short Reversion')):
            srows = [r for r in rows if r.get('strategy') == strat]
            if not srows:
                continue
            n = len(srows)
            wins = sum(1 for r in srows if fnum(r.get('pnl_pct')) > 0)
            pnl = sum(fnum(r.get('pnl_pct')) for r in srows)
            net = sum(fnum(r.get('net_pnl_pct') or r.get('pnl_pct')) for r in srows)
            wr = wins / n * 100 if n else 0
            best = max(srows, key=lambda r: fnum(r.get('pnl_pct')))
            worst = min(srows, key=lambda r: fnum(r.get('pnl_pct')))
            lines.append(
                f"*{nice}*\n"
                f"  {n} trades · {wins}W/{n - wins}L · {wr:.0f}% win\n"
                f"  Gross {pnl:+.1f}% · Net {net:+.1f}%\n"
                f"  Best {self._short(best['symbol'])} {fnum(best.get('pnl_pct')):+.1f}% · "
                f"Worst {self._short(worst['symbol'])} {fnum(worst.get('pnl_pct')):+.1f}%")
            overall_n += n; overall_w += wins; overall_pnl += pnl; overall_net += net

        owr = overall_w / overall_n * 100 if overall_n else 0
        lines.append(f"\n*Combined:* {overall_n} trades · {owr:.0f}% win · "
                     f"gross {overall_pnl:+.1f}% · net {overall_net:+.1f}%")
        lines.append(f"\nFull record: every signal, win and loss.")
        return '\n'.join(lines)

    def _short(self, sym):
        return str(sym).replace('/USDT:USDT', '').replace('/USDT', '').replace(':USDT', '')

    async def daily_summary_loop(self):
        """Once per day at DAILY_SUMMARY_HOUR_UTC, post yesterday's scorecard."""
        while True:
            try:
                now = datetime.now(timezone.utc)
                today = now.strftime('%Y-%m-%d')
                if (DAILY_SUMMARY_ENABLED and now.hour >= DAILY_SUMMARY_HOUR_UTC
                        and self.last_summary_date != today):
                    # summarize the day that just ended (yesterday)
                    yday = (now - timedelta(days=1)).strftime('%Y-%m-%d')
                    msg = self._build_daily_summary(yday)
                    await self._send(msg)
                    self._broadcast(msg)
                    self.last_summary_date = today
                    self._save_state()
            except Exception as e:
                logger.debug(f"daily summary loop: {e}")
            await asyncio.sleep(300)   # check every 5 min

    async def monitor_loop(self):
        """Fast, independent loop: check open positions for exits + golden-pocket
        entries every MONITOR_INTERVAL seconds, regardless of how long the
        full-universe scan takes. This is what guarantees exits actually fire."""
        while True:
            try:
                await self.monitor_open_positions()
                await self.check_golden_pocket_entries()
                await self.check_short_reversion()
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
            await asyncio.sleep(MONITOR_INTERVAL)

    async def scan_loop(self):
        """Heavy loop: scan all perp pairs for new pumps. Slow, but it no longer
        blocks exits because monitoring runs in its own loop."""
        pairs = self.get_futures_pairs()
        cycle = 0
        while True:
            try:
                if cycle % 50 == 0 and cycle > 0:
                    pairs = self.get_futures_pairs()
                await self.scan_for_pumps(pairs)
                cycle += 1
                logger.info(f"Scan cycle {cycle} done. Open: {len(self.open_positions)} | "
                            f"Tracking: {len(self.pump_tracker)} | "
                            f"Trades: {self.stats['trades']}")
            except Exception as e:
                logger.error(f"Scan loop error: {e}")
            await asyncio.sleep(CHECK_INTERVAL)

    async def run(self):
        logger.info(f"KryptoPumpTrader starting on {EXCHANGE}")
        logger.info(f"Volume: {VOLUME_MULTIPLIER}x baseline x{VOLUME_MOMENTUM_CANDLES} candles | "
                    f"MACD required: {REQUIRE_MACD} | SL: -{STOP_LOSS_PCT}% | "
                    f"4h gap > {ENTRY_MIN_4H_GAP_PCT}%")
        pairs = self.get_futures_pairs()
        logger.info(f"Watching {len(pairs)} perp pairs")
        mode_txt = (f"Quant scoring ON · trade≥{MIN_SCORE_TO_TRADE} · shadow≥{SHADOW_MIN_SCORE} · "
                    f"min R:R {MIN_RR} · ATR stops") if self.scorer else \
                   f"Quant scoring OFF · flat -{STOP_LOSS_PCT:.0f}% stop"
        await self._send(f"🟣 *KryptoPumpTrader (paper)* online · watching {len(pairs)} perps\n"
                         f"Vol ≥{VOLUME_MULTIPLIER:.0f}x · {mode_txt}")

        # Run monitoring and scanning concurrently. The monitor loop gets a turn
        # every time the scan yields (between pairs), so exits fire within ~30s
        # instead of waiting for a full 610-pair scan to finish.
        loops = [self.monitor_loop(), self.scan_loop()]
        if self.acc:
            loops.append(self.accumulation_loop())   # slow background base-detection
        if DAILY_SUMMARY_ENABLED:
            loops.append(self.daily_summary_loop())  # once-a-day scorecard
        await asyncio.gather(*loops)


if __name__ == '__main__':
    asyncio.run(KryptoPumpTrader().run())
