# KryptoSniper — Free Bot, Channels, Payments & X Setup

This guide gets the **Free KryptoSniper** funnel live alongside your untouched
Premium bot. Do the steps in order.

---

## PART A — Create the Telegram pieces

### 1. Create the FREE bot (BotFather)
1. Open **@BotFather** → `/newbot`
2. Name: `KryptoSniper` · Username: e.g. `KryptoSniperFreeBot`
3. Copy the **token** it gives you → this is your `FREE_BOT_TOKEN`.

### 2. Create the FREE public channel (top of funnel)
1. Telegram → New Channel → **Public** → name it (e.g. "KryptoSniper Alerts")
2. Set a public link, e.g. `t.me/KryptoSniperAlerts`
3. Add your **free bot as an admin** (so it can post). Give it "Post Messages".
4. This handle is your `FREE_CHANNEL_ID` (e.g. `@KryptoSniperAlerts`).

### 3. Create the PREMIUM private channel
1. New Channel → **Private**
2. Add **both** your premium bot and free bot as admins.
3. Channel → Invite Links → create a link → this is `PREMIUM_INVITE`.
   (Tip: make it a "request to join" link so only paid users you approve get in,
   or rely on the bot DMing the invite only after payment.)

### 4. Turn on Telegram Stars payments
1. Stars are **native** — no external processor, no provider token needed.
2. In BotFather: `/mybots` → your free bot → **Payments** → confirm Stars is enabled
   (Stars work out of the box for digital goods; no Stripe/processor required).
3. You'll receive Stars; convert to fiat/crypto in Telegram's wallet later.
4. Set your price in `free_bot.py`: `PREMIUM_STARS = 500` (≈ a few USD — check the
   current Star rate in-app and price to your target USD).

---

## PART B — Deploy the free bot on the VM

```bash
# from the deploy bundle (same repo), the free bot files are already included:
#   free_bot.py, free_bot_runner.py
# install the telegram lib if not present:
pip3 install --break-system-packages python-telegram-bot

# set env vars (put these in the systemd unit, see below)
export FREE_BOT_TOKEN="<token from BotFather>"
export FREE_CHANNEL_ID="@KryptoSniperAlerts"
export PREMIUM_INVITE="https://t.me/+yourPrivateInviteHash"
export ADMIN_ID="5547784306"

# test run (Ctrl-C to stop)
cd ~/krypto_pump_trader && python3 free_bot_runner.py
```

DM your free bot `/start` — you should get the welcome + buttons. Tap Upgrade →
you should get a Stars invoice. Pay it (test with a small price) → you should get
the premium invite. Send `/stats` (as admin) → funnel snapshot.

### Run it as a service (always on)
```bash
sudo tee /etc/systemd/system/krypto-free.service >/dev/null <<'UNIT'
[Unit]
Description=KryptoSniper Free Bot
After=network.target

[Service]
WorkingDirectory=/home/ubuntu/krypto_pump_trader
Environment=FREE_BOT_TOKEN=PUT_TOKEN
Environment=FREE_CHANNEL_ID=@KryptoSniperAlerts
Environment=PREMIUM_INVITE=https://t.me/+yourHash
Environment=ADMIN_ID=5547784306
ExecStart=/usr/bin/python3 /home/ubuntu/krypto_pump_trader/free_bot_runner.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now krypto-free
sudo systemctl status krypto-free
```

---

## PART C — Wire free signals into the channel

The premium bot already detects pumps. To also broadcast the FREE (gated) version
to your public channel, the premium bot calls `free_bot.format_free_signal(...)`
and posts to `FREE_CHANNEL_ID`. (One small hook in the premium bot's signal path —
ask to have it added when you're ready; it's a few lines and does NOT change any
premium behaviour.)

Free channel posts the gated alert; premium channel posts the full signal. Same
engine, two audiences.

---

## PART D — X (Twitter) — the honest setup

**Do NOT use browser-automation / unofficial posting.** It violates X ToS and gets
accounts permanently banned — you do not want your whole audience on a bannable
account. Use the legitimate **free API tier** (~500 posts/month, plenty) for the
*automated proof-posts*, and post personality/insight content yourself.

### Account setup
1. Handle: `@KryptoSniperAI` or similar — clear, searchable.
2. Bio: "Quant pump signals for crypto perps. Every trade logged — wins AND losses.
   Free alerts 👇"
3. Link: your free Telegram channel.
4. Pin a thread explaining the thesis (transparency + how the engine works).

### Get free API access
1. developer.x.com → sign up → create a Project + App (Free tier).
2. Generate API Key/Secret + Access Token/Secret (with **Write** permission).
3. Put them in `social_poster.py` (X_API_KEY, X_API_SECRET, X_ACCESS_TOKEN,
   X_ACCESS_SECRET). It already speaks OAuth 1.0a with the stdlib.
4. Run `python3 social_poster.py --dry-run` to preview, then live.

### What to auto-post (stay well under 500/month)
- Each closed REAL trade (win and loss) — the transparency hook.
- A daily recap.
That's ~5–15 posts/day max; under the free cap.

### What to post yourself (the growth engine)
- Market takes, education, threads, personality. See `X_CONTENT_WEEK1.md`.
- Mix: ~70% human insight, ~30% auto proof-posts. People follow people.
