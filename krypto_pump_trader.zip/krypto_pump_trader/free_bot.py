#!/usr/bin/env python3
"""
free_bot.py — the FREE KryptoSniper bot + public channel broadcaster.

This runs ALONGSIDE the premium bot and shares the same pump-detection engine.
The premium bot is untouched. This module:

  1. Formats a FREE-TIER version of each pump signal (price + pump shown;
     score, R:R, volume detail, levels, factors all LOCKED / blurred).
  2. Broadcasts free signals to a public Telegram CHANNEL (top-of-funnel).
  3. Runs a bot that handles /start, registers users, tracks their activity,
     and serves the upgrade / payment flow.

Funnel: public channel (free, locked) -> user taps Unlock -> DMs this bot ->
we register + track them -> they pay -> we add them to the premium channel.

Config via environment or the constants below.
"""
import json
import os
import time
import logging
from datetime import datetime, timezone

logger = logging.getLogger('free_bot')

# ----------------------------------------------------------------- CONFIG
FREE_BOT_TOKEN   = os.environ.get('FREE_BOT_TOKEN', 'PUT_FREE_BOT_TOKEN_HERE')
FREE_CHANNEL_ID  = os.environ.get('FREE_CHANNEL_ID', '@YourFreeChannel')  # public channel
PREMIUM_LINK     = os.environ.get('PREMIUM_LINK', 'https://t.me/YourBot?start=upgrade')
USERS_DB         = os.environ.get('FREE_USERS_DB', 'free_users.json')

# --- Free-tier gating: which fields free users SEE vs LOCKED ---
# Tune this line to move the paywall. True = shown to free users.
FREE_SHOWS = {
    'price':        True,    # current price — shown (proof + dopamine)
    'pump_pct':     True,    # the % pump in 3 min — shown (the hook)
    'symbol':       True,    # which coin — shown
    'rough_target': True,    # a VAGUE "resistance zone" — shown (teaser, not precise)
    'score':        False,   # quant score — LOCKED
    'rr':           False,   # risk:reward — LOCKED
    'volume':       False,   # the volume ladder — LOCKED
    'levels':       False,   # exact support/resistance — LOCKED
    'factors':      False,   # the "driven by" read — LOCKED
    'decision':     False,   # trade/shadow/skip — LOCKED
}
PRICE_TZ = 'Asia/Bangkok'

# ----------------------------------------------------------------- USER TRACKING
class UserStore:
    """Lightweight JSON-file user database. Tracks every free user and their
    behaviour so you own your funnel analytics (no third-party needed)."""
    def __init__(self, path=USERS_DB):
        self.path = path
        self.users = {}
        self._load()

    def _load(self):
        try:
            with open(self.path) as f:
                self.users = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.users = {}

    def _save(self):
        tmp = self.path + '.tmp'
        with open(tmp, 'w') as f:
            json.dump(self.users, f, indent=2)
        os.replace(tmp, self.path)

    def register(self, user_id, username='', first_name='', source=''):
        """Called on /start. Records new users; updates returning ones."""
        uid = str(user_id)
        now = datetime.now(timezone.utc).isoformat()
        if uid not in self.users:
            self.users[uid] = {
                'user_id': uid, 'username': username, 'first_name': first_name,
                'joined': now, 'source': source, 'tier': 'free',
                'events': [], 'unlock_clicks': 0, 'last_seen': now,
            }
            logger.info(f"NEW free user: {uid} @{username} (source={source})")
        else:
            self.users[uid]['last_seen'] = now
            if username:
                self.users[uid]['username'] = username
        self._save()
        return self.users[uid]

    def track(self, user_id, event, meta=None):
        """Log any behaviour: 'start', 'unlock_click', 'pricing_view', 'paid', etc."""
        uid = str(user_id)
        if uid not in self.users:
            self.register(uid)
        ev = {'event': event, 'ts': datetime.now(timezone.utc).isoformat()}
        if meta:
            ev['meta'] = meta
        self.users[uid]['events'].append(ev)
        self.users[uid]['last_seen'] = ev['ts']
        if event == 'unlock_click':
            self.users[uid]['unlock_clicks'] = self.users[uid].get('unlock_clicks', 0) + 1
        if event == 'paid':
            self.users[uid]['tier'] = 'premium'
        self._save()

    def stats(self):
        """Funnel snapshot for you."""
        total = len(self.users)
        premium = sum(1 for u in self.users.values() if u.get('tier') == 'premium')
        clickers = sum(1 for u in self.users.values() if u.get('unlock_clicks', 0) > 0)
        return {
            'total_users': total,
            'premium_users': premium,
            'free_users': total - premium,
            'unlock_clickers': clickers,
            'click_to_total_pct': round(clickers / total * 100, 1) if total else 0,
            'conversion_pct': round(premium / total * 100, 1) if total else 0,
        }


# ----------------------------------------------------------------- FREE SIGNAL FORMAT
LOCK = '🔒'

def _rough_target(resistance):
    """A deliberately VAGUE target for free users: the next-timeframe resistance
    as a 'zone', not a precise number. Teases the value without giving it away."""
    r = resistance or {}
    for tf in ('1d', '4h'):
        rv = r.get(tf, {}).get('resistance')
        gap = r.get(tf, {}).get('gap')
        if rv and gap:
            # round to a zone, not a precise level
            return f"~+{gap:.0f}% zone (next {tf} resistance)"
    return 'upside zone overhead'


def format_free_signal(symbol, pump, q, resistance=None):
    """Build the FREE-TIER message: the hook (pump + price) is shown, everything
    that constitutes the edge is locked behind a paywall teaser."""
    price = pump.get('current_price', 0) or 0
    pct = pump.get('price_change_pct', 0) or 0

    lines = ["⚡ *PUMP DETECTED* ⚡", ""]
    lines.append(f"*Pair:* `{symbol}`")
    if FREE_SHOWS['price']:
        lines.append(f"*Price:* ${price:.6g}")
    if FREE_SHOWS['pump_pct']:
        lines.append(f"*Pump:* {pct:+.1f}% in 3 min")
    if FREE_SHOWS['rough_target']:
        lines.append(f"*Target:* {_rough_target(resistance)}")
    lines.append("")
    # the locked teaser block — show them exactly what they're missing
    lines.append("*Premium unlocks:*")
    lines.append(f"{LOCK} Quant score /100")
    lines.append(f"{LOCK} Risk:Reward + exact entry")
    lines.append(f"{LOCK} Volume profile + MACD")
    lines.append(f"{LOCK} Exact support & resistance")
    lines.append(f"{LOCK} Order-flow read (who's buying)")
    lines.append(f"{LOCK} TRADE / SKIP verdict")
    lines.append("")
    lines.append(f"🔓 [Unlock everything]({PREMIUM_LINK})")
    return "\n".join(lines)


def format_free_recap(stats_line):
    """A daily free-channel recap — builds trust + FOMO without giving the edge."""
    return ("📊 *Yesterday on KryptoSniper*\n\n"
            f"{stats_line}\n\n"
            "Free members saw the pumps. Premium members saw the *scores, entries, "
            "and exits* — every win and loss logged.\n\n"
            f"🔓 [Go Premium]({PREMIUM_LINK})")


# ----------------------------------------------------------------- BOT HANDLERS
WELCOME = (
    "👋 *Welcome to KryptoSniper*\n\n"
    "You'll get *live pump alerts* the moment our engine detects a volume surge "
    "across 500+ perps — free.\n\n"
    "Each alert shows the coin, price, and pump size. *Premium* unlocks the quant "
    "score, exact entry/stop/target, order-flow read, and our full TRADE/SKIP verdict — "
    "plus every trade we take, win or loss, logged transparently.\n\n"
    "📡 Free alerts: join the channel below\n"
    "🔓 Premium: tap Upgrade\n"
)

PRICING = (
    "🔓 *KryptoSniper Premium*\n\n"
    "Everything the free alert hides:\n"
    "✅ Quant score (0–100) on every pump\n"
    "✅ Exact entry, stop (under support), and target\n"
    "✅ Risk:Reward + data confidence\n"
    "✅ Full volume profile + order-flow read\n"
    "✅ Live TRADE / SKIP / SHADOW verdict\n"
    "✅ Every trade we take — wins AND losses, logged\n"
    "✅ Three strategies: breakout, Fib retrace, short reversion\n\n"
    "Tap below to pay with Telegram Stars and get instant access."
)

# --- Telegram Stars pricing ---
# Stars are Telegram's native currency. Price is set in Stars (XTR). You receive
# them and can convert to fiat/crypto via Telegram. Adjust PREMIUM_STARS to taste;
# ~500 Stars ≈ a few USD depending on Telegram's current rate (check in-app).
PREMIUM_STARS       = 500          # price in Telegram Stars for one month
PREMIUM_DAYS        = 30
PREMIUM_TITLE       = 'KryptoSniper Premium — 30 days'
PREMIUM_DESC        = 'Unlock quant scores, exact entries/stops/targets, order-flow reads, and every logged trade for 30 days.'
PREMIUM_CHANNEL_INVITE = os.environ.get('PREMIUM_INVITE', 'https://t.me/+YourPremiumInviteHash')


async def send_premium_invoice(bot, message):
    """Send a Telegram Stars invoice. Stars invoices use currency 'XTR' and an
    empty provider_token (Telegram handles it natively — no external processor)."""
    from telegram import LabeledPrice
    await bot.send_invoice(
        chat_id=message.chat.id,
        title=PREMIUM_TITLE,
        description=PREMIUM_DESC,
        payload=f"premium_{PREMIUM_DAYS}d",
        provider_token='',                       # empty = Telegram Stars
        currency='XTR',                          # XTR = Telegram Stars
        prices=[LabeledPrice('Premium 30 days', PREMIUM_STARS)],
        start_parameter='premium',
    )


async def on_pre_checkout(bot, query):
    """Telegram asks us to confirm the order before charging. Always approve
    (we have nothing to validate server-side for a simple subscription)."""
    await bot.answer_pre_checkout_query(query.id, ok=True)


async def on_successful_payment(bot, store, message):
    """Fired after Stars are charged. Mark the user premium, grant channel access."""
    u = message.from_user
    sp = message.successful_payment
    store.track(u.id, 'paid', {
        'stars': getattr(sp, 'total_amount', PREMIUM_STARS),
        'payload': getattr(sp, 'invoice_payload', ''),
        'charge_id': getattr(sp, 'telegram_payment_charge_id', ''),
    })
    # set an expiry so you can manage renewals
    uid = str(u.id)
    if uid in store.users:
        store.users[uid]['premium_until'] = time.time() + PREMIUM_DAYS * 86400
        store._save()
    grant = (
        "🎉 *You're in — welcome to Premium!*\n\n"
        "Your access is active for the next 30 days. Every pump now comes fully "
        "unlocked: score, entry, stop, target, order-flow, and verdict.\n\n"
        f"👉 [Join the Premium channel]({PREMIUM_CHANNEL_INVITE})\n\n"
        "Every trade we take is posted here — wins and losses. Welcome aboard."
    )
    await bot.send_message(chat_id=message.chat.id, text=grant,
                           parse_mode='Markdown', disable_web_page_preview=True)
    logger.info(f"PAID: {uid} @{getattr(u,'username','')} — {PREMIUM_STARS} Stars")


async def cmd_start(bot, store, message):
    """Handle /start — register + welcome. 'source' captures deep-link attribution."""
    u = message.from_user
    parts = (message.text or '').split(maxsplit=1)
    source = parts[1] if len(parts) > 1 else 'direct'
    store.register(u.id, getattr(u, 'username', ''), getattr(u, 'first_name', ''), source)
    store.track(u.id, 'start', {'source': source})
    # buttons handled by the runner (kept dependency-light here)
    await bot.send_message(chat_id=message.chat.id, text=WELCOME,
                           parse_mode='Markdown', disable_web_page_preview=True)


async def cmd_upgrade(bot, store, message):
    u = message.from_user
    store.track(u.id, 'unlock_click')
    await bot.send_message(chat_id=message.chat.id, text=PRICING,
                           parse_mode='Markdown', disable_web_page_preview=True)


async def cmd_stats(bot, store, message, admin_id):
    """Admin-only funnel stats."""
    if str(message.from_user.id) != str(admin_id):
        return
    s = store.stats()
    txt = ("📈 *Funnel*\n\n"
           f"Total users: {s['total_users']}\n"
           f"Free: {s['free_users']} · Premium: {s['premium_users']}\n"
           f"Unlock-clickers: {s['unlock_clickers']} ({s['click_to_total_pct']}%)\n"
           f"Conversion: {s['conversion_pct']}%")
    await bot.send_message(chat_id=message.chat.id, text=txt, parse_mode='Markdown')


if __name__ == '__main__':
    # quick self-test of the formatter
    pump = {'current_price': 0.05512, 'price_change_pct': 7.2}
    res = {'1d': {'resistance': 0.06476, 'gap': 17.3}}
    print(format_free_signal('KERNEL/USDT:USDT', pump, {}, res))
    print('\n---\n')
    print(format_free_recap('3 trades · 2W/1L · +12.4% net'))
