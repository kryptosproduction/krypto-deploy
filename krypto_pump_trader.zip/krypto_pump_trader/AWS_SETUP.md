# KryptoPumpTrader — AWS Setup

A **paper trader** (simulated, no real orders, no exchange keys). It runs
separately from your KryptoSniper forward test — different bot, different sheet,
different process. They won't conflict.

---

## What it does

**Detects** sustained GREEN pumps only (never red dumps):
- Price up ≥ 2% in 3 minutes
- Last 3 candles ALL ≥ 15x the 24-hour volume baseline
- Shows volume-vs-MACD in alerts but does **not** require it

**Two paper strategies run in parallel:**

| | Entry | Exit (target) | Stop |
|---|---|---|---|
| PUMP_BREAKOUT | Sustained pump **and** 4h resistance gap > 5% | Next 4h resistance | −20% |
| GOLDEN_POCKET | Price retraces into 0.618–0.70 fib with volume | Near the pump high | −20% |

**Guards:** one open position per ticker; new entries blocked while a position is open.

**Logs everything** to a Google Sheet (entry row + exit row per trade) so you can
later compute win rate, total P&L, and whether your entries/exits were optimal
(it records the peak and trough the price reached while you held).

**Telegram** sends an entry alert and an exit alert (with % gain/loss, hold time,
best/worst excursion, and running win-rate stats).

---

## Step 1 — Set up the Google Sheet

1. Create a **new** Google Sheet (separate from KryptoSniper).
2. `Extensions > Apps Script`, delete the default code, paste in `KryptoPumpTrader.gs`.
3. `Deploy > New deployment > Web app`. Execute as **Me**, access **Anyone**.
4. Authorize when prompted. Copy the **Web App URL**.
5. Open `krypto_pump_trader.py` and paste it into `SHEET_WEBHOOK_URL`.

(The bot token and chat ID are already filled in.)

---

## Step 2 — Get the files onto your AWS VM

From your laptop (or upload via the AWS console / SCP):

```bash
scp -i your-key.pem krypto_pump_trader.py ubuntu@YOUR_VM_IP:~/
```

Or just create the folder on the VM and paste the file with `nano`.

```bash
ssh -i your-key.pem ubuntu@YOUR_VM_IP
mkdir -p ~/krypto_pump_trader && cd ~/krypto_pump_trader
nano krypto_pump_trader.py      # paste, then add your SHEET_WEBHOOK_URL
```

---

## Step 3 — Install dependencies

```bash
pip install ccxt pandas numpy python-telegram-bot --break-system-packages
```

---

## Step 4 — Test it runs (foreground first)

```bash
cd ~/krypto_pump_trader
python3 krypto_pump_trader.py
```

You should get a Telegram message: **"🟣 KryptoPumpTrader (paper) online · watching N perps"**
and console logs showing scan cycles. Press `Ctrl+C` to stop once confirmed.

---

## Step 5 — Run it 24/7 in the background

```bash
cd ~/krypto_pump_trader
nohup python3 krypto_pump_trader.py > trader.log 2>&1 &
```

That's it. It now runs independently of your browser/terminal.

---

## Managing it

```bash
# Is it running?
ps aux | grep krypto_pump_trader

# Watch live logs
tail -f ~/krypto_pump_trader/trader.log

# Stop it
pkill -f krypto_pump_trader

# Restart
cd ~/krypto_pump_trader && nohup python3 krypto_pump_trader.py > trader.log 2>&1 &
```

State (open positions, tracked pumps, running stats) is saved to
`pump_trader_state.json`, so a restart resumes where it left off — open trades
keep being monitored.

---

## Running alongside KryptoSniper

Both can run at once. Check both:

```bash
ps aux | grep -E "paper_runner|krypto_pump_trader"
```

Two separate Python processes, two Telegram bots, two sheets. No interference.

---

## Notes & tunables (top of the .py file)

- `VOLUME_MULTIPLIER = 15.0` — very strict; expect few, strong signals. Lower to 8–10 if too quiet.
- `ENTRY_MIN_4H_GAP_PCT = 5.0` — only buys breakouts with >5% room to 4h resistance.
- `STOP_LOSS_PCT = 20.0` — your "for now" stop. Easy to change later from the data.
- `RETRACE_TRACK_HOURS = 2` — how long after a pump it waits for a golden-pocket entry.
- This is a **paper** simulation: exits fill at the target/stop level when a 20-second
  scan sees the price cross it, so there's mild slippage vs a live fill — realistic enough
  to judge the strategy before going live.
