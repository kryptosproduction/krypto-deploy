#!/usr/bin/env python3
"""
social_cards.py — generate branded image cards for X / social posts.

Why this exists (marketer's reasoning): text-only posts barely travel on X; media
posts get far more reach, and a consistent visual identity turns "random anon" into
"a system worth following." These cards give every post a recognisable look.

Three card types:
  • pump_card()    — a pump alert (for the free/teaser feed; edge fields blurred)
  • result_card()  — a CLOSED trade result (win OR loss — the transparency hook)
  • quote_card()   — an insight/education quote (the save-able, shareable content)

All cards are 1600x900 (16:9, X's preferred inline ratio) and use a dark, premium
"terminal" aesthetic. No external assets needed — pure Pillow + system fonts.

Usage:
  from social_cards import pump_card, result_card, quote_card
  pump_card('KERNEL/USDT:USDT', 7.2, 0.05512, locked=True, out='card.png')
"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ---- brand palette (dark premium terminal) ----
BG0      = (14, 12, 22)        # near-black base
BG1      = (22, 18, 36)        # panel
PURPLE   = (139, 92, 246)
PURPLE_D = (109, 40, 217)
GREEN    = (31, 200, 120)
RED      = (230, 70, 95)
GOLD     = (212, 168, 60)
INK      = (240, 238, 248)
MUTE     = (140, 134, 165)
LINE     = (52, 46, 78)

F = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FB = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FM = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
FMB = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'

def _f(path, size):
    return ImageFont.truetype(path, size)

def _grad_bg(w, h):
    """Subtle vertical gradient + faint purple glow top-left for depth."""
    img = Image.new('RGB', (w, h), BG0)
    top = Image.new('RGB', (w, h), BG1)
    mask = Image.new('L', (w, h))
    md = mask.load()
    for y in range(h):
        v = int(90 * (1 - y / h))
        for x in range(0, w, 2):
            md[x, y] = v
            if x+1 < w: md[x+1, y] = v
    img = Image.composite(top, img, mask)
    # glow
    glow = Image.new('RGB', (w, h), BG0)
    gd = ImageDraw.Draw(glow)
    gd.ellipse([-200, -300, 700, 400], fill=(40, 26, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(160))
    img = Image.blend(img, glow, 0.5)
    return img

def _center(draw, text, font, cx, y, fill):
    w = draw.textlength(text, font=font)
    draw.text((cx - w/2, y), text, font=font, fill=fill)
    return w

def _logo(draw, x, y):
    """Simple wordmark — crosshair + KRYPTOSNIPER."""
    r = 13
    draw.ellipse([x, y, x+2*r, y+2*r], outline=PURPLE, width=3)
    draw.line([x+r, y-5, x+r, y+2*r+5], fill=PURPLE, width=2)
    draw.line([x-5, y+r, x+2*r+5, y+r], fill=PURPLE, width=2)
    draw.text((x+2*r+16, y-3), 'KRYPTO', font=_f(FB, 26), fill=INK)
    kw = draw.textlength('KRYPTO', font=_f(FB, 26))
    draw.text((x+2*r+16+kw, y-3), 'SNIPER', font=_f(FB, 26), fill=PURPLE)

def _footer(draw, w, h, tag='@KryptoSniperAI · every trade logged'):
    draw.text((64, h-58), tag, font=_f(F, 22), fill=MUTE)


def _lock_glyph(draw, x, y, color):
    """Draw a small padlock instead of relying on emoji fonts."""
    draw.rounded_rectangle([x, y+8, x+20, y+26], radius=3, outline=color, width=2)
    draw.arc([x+3, y-2, x+17, y+16], start=180, end=360, fill=color, width=2)


def _bolt(draw, x, y, color, s=1.0):
    """Draw a lightning bolt."""
    pts = [(x+18*s, y), (x+4*s, y+22*s), (x+14*s, y+22*s), (x+6*s, y+40*s),
           (x+26*s, y+16*s), (x+15*s, y+16*s), (x+22*s, y)]
    draw.polygon(pts, fill=color)


# ============================================================ PUMP CARD
def pump_card(symbol, pump_pct, price, target_zone=None, locked=True, out='pump_card.png'):
    w, h = 1600, 900
    img = _grad_bg(w, h)
    d = ImageDraw.Draw(img)
    _logo(d, 64, 56)
    # top-right badge
    badge = 'LIVE SIGNAL'
    bw = d.textlength(badge, font=_f(FB, 22))
    d.rounded_rectangle([w-64-bw-32, 54, w-64, 96], radius=21, fill=(40, 26, 70))
    d.text((w-64-bw-16, 60), badge, font=_f(FB, 22), fill=PURPLE)

    sym = symbol.replace('/USDT:USDT', '').replace('USDT', '')
    _bolt(d, 64, 188, GOLD, s=1.1)
    d.text((104, 190), 'PUMP DETECTED', font=_f(FB, 40), fill=GOLD)
    d.text((64, 268), sym, font=_f(FB, 130), fill=INK)

    # big pump %
    pcol = GREEN if pump_pct >= 0 else RED
    d.text((64, 430), f'{pump_pct:+.1f}%', font=_f(FMB, 92), fill=pcol)
    d.text((64, 540), 'in 3 minutes', font=_f(F, 30), fill=MUTE)

    # price + target on the right
    rx = 980
    d.text((rx, 300), 'PRICE', font=_f(FB, 24), fill=MUTE)
    d.text((rx, 332), f'${price:.6g}', font=_f(FMB, 54), fill=INK)
    if target_zone:
        d.text((rx, 430), 'TARGET', font=_f(FB, 24), fill=MUTE)
        d.text((rx, 462), target_zone, font=_f(FB, 36), fill=PURPLE)

    if locked:
        # draw small lock glyphs (rounded rect + shackle) instead of emoji
        for i, txt in enumerate(['score · R:R · entry', 'volume · order-flow', 'TRADE / SKIP verdict']):
            ly = 562 + i*40
            _lock_glyph(d, rx, ly, MUTE)
            d.text((rx+34, ly-4), txt, font=_f(F, 26), fill=MUTE)
    _footer(d, w, h)
    img.save(out)
    return out


# ============================================================ RESULT CARD
def result_card(symbol, pnl_pct, r_multiple, is_win, strategy='', reason='', out='result_card.png'):
    w, h = 1600, 900
    img = _grad_bg(w, h)
    d = ImageDraw.Draw(img)
    _logo(d, 64, 56)
    col = GREEN if is_win else RED
    label = 'WIN' if is_win else 'LOSS'
    # result badge top-right
    bw = d.textlength(label, font=_f(FB, 26))
    d.rounded_rectangle([w-64-bw-44, 52, w-64, 100], radius=24,
                        fill=(20, 60, 40) if is_win else (60, 24, 32))
    d.text((w-64-bw-22, 60), label, font=_f(FB, 26), fill=col)

    sym = symbol.replace('/USDT:USDT', '').replace('USDT', '')
    d.text((64, 200), 'TRADE CLOSED', font=_f(FB, 36), fill=MUTE)
    d.text((64, 254), sym, font=_f(FB, 110), fill=INK)

    # the number, huge
    d.text((64, 410), f'{pnl_pct:+.2f}%', font=_f(FMB, 128), fill=col)
    d.text((68, 568), f'{r_multiple:+.2f}R', font=_f(FMB, 56), fill=col)
    if strategy:
        nice = {'PUMP_BREAKOUT': 'Pump Breakout', 'GOLDEN_POCKET': 'Fib Retrace',
                'SHORT_REVERSION': 'Short Reversion'}.get(strategy, strategy)
        d.text((rx0 := 64, 648), nice, font=_f(F, 30), fill=MUTE)

    # honesty line on the right
    msg = ("This one ran." if is_win else "Stop did its job.")
    sub = ("Banked + trailed." if is_win else "Small loss, no drama.")
    d.text((1000, 360), msg, font=_f(FB, 44), fill=INK)
    d.text((1000, 426), sub, font=_f(F, 32), fill=MUTE)
    d.text((1000, 520), 'We post every trade.', font=_f(F, 28), fill=MUTE)
    d.text((1000, 558), 'Wins AND losses.', font=_f(FB, 28), fill=PURPLE)
    _footer(d, w, h)
    img.save(out)
    return out


# ============================================================ QUOTE / INSIGHT CARD
def quote_card(text, kicker='TRADING TRUTH', out='quote_card.png'):
    w, h = 1600, 900
    img = _grad_bg(w, h)
    d = ImageDraw.Draw(img)
    _logo(d, 64, 56)
    d.text((64, 200), kicker, font=_f(FB, 30), fill=PURPLE)
    d.line([64, 250, 220, 250], fill=PURPLE, width=4)

    # word-wrap the quote, big
    font = _f(FB, 64)
    words = text.split()
    lines, cur = [], ''
    for word in words:
        t = (cur + ' ' + word).strip()
        if d.textlength(t, font=font) > w - 160:
            lines.append(cur); cur = word
        else:
            cur = t
    if cur: lines.append(cur)
    y = 320
    for ln in lines:
        d.text((64, y), ln, font=font, fill=INK)
        y += 84
    _footer(d, w, h)
    img.save(out)
    return out


if __name__ == '__main__':
    import os
    os.makedirs('card_samples', exist_ok=True)
    pump_card('KERNEL/USDT:USDT', 7.2, 0.05512, '~+17% zone', locked=True, out='card_samples/pump.png')
    result_card('ARB/USDT:USDT', 21.92, 4.13, True, 'GOLDEN_POCKET', out='card_samples/win.png')
    result_card('SYN/USDT:USDT', -3.00, -1.0, False, 'PUMP_BREAKOUT', out='card_samples/loss.png')
    quote_card('Win rate lies. Expectancy tells the truth.', out='card_samples/quote.png')
    quote_card('A volume spike means nothing if you do not know who is buying.',
               kicker='THE EDGE', out='card_samples/quote2.png')
    print('cards generated in card_samples/')
