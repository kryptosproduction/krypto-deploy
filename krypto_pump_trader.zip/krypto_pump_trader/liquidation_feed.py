"""
liquidation_feed.py — live Binance forced-liquidation stream for Bot 2.

Maintains a rolling window of liquidations per symbol and exposes
short_liq_ratio(symbol): the fraction of recent liquidation notional that was
SHORTs being force-bought.

Why a pump screener cares: a pump powered mostly by short liquidations is a
SQUEEZE (forced buy-ins) that tends to snap back once the shorts are flushed. A
pump with little liquidation behind it is real spot/leverage demand. The scorer
penalizes the squeeze case via the 'liq_organic' factor.

Runs as a background thread. Needs:  pip install websocket-client
Degrades to neutral (returns None) if the package is missing or the socket drops.
"""
import json
import time
import threading
import logging
from collections import defaultdict, deque

log = logging.getLogger('liquidation_feed')

WS_URL = "wss://fstream.binance.com/ws/!forceOrder@arr"
WINDOW_SECONDS = 300   # rolling 5-minute window


class LiquidationFeed:
    def __init__(self, window=WINDOW_SECONDS):
        self.window = window
        self.events = defaultdict(deque)   # symbol -> deque[(ts, side, notional)]
        self.lock = threading.Lock()
        self._thread = None
        self._running = False

    def _handle(self, msg):
        """forceOrder payload: o = {s: symbol, S: side, q: qty, p: price, T: time}.
        side SELL = a long got liquidated; side BUY = a SHORT got force-bought."""
        try:
            o = msg.get('o', {})
            sym = o['s']
            side = o['S']
            notional = float(o['q']) * float(o['p'])
            ts = o.get('T', time.time() * 1000) / 1000
            with self.lock:
                dq = self.events[sym]
                dq.append((ts, side, notional))
                cutoff = time.time() - self.window
                while dq and dq[0][0] < cutoff:
                    dq.popleft()
        except Exception as e:
            log.debug(f"liq handle: {e}")

    def short_liq_ratio(self, symbol):
        """Fraction of recent liquidation notional that was SHORTs (BUY-side forced).
        Returns None if there's no recent liquidation data (neutral)."""
        key = symbol.replace('/', '').replace(':USDT', '')
        with self.lock:
            dq = self.events.get(key)
            if not dq:
                return None
            cutoff = time.time() - self.window
            short_n = sum(n for ts, s, n in dq if ts >= cutoff and s == 'BUY')
            total_n = sum(n for ts, s, n in dq if ts >= cutoff)
        if total_n <= 0:
            return None
        return short_n / total_n

    def total_liq_notional(self, symbol):
        """Recent total liquidation $ for the symbol (used to tell 'no data' from 'no liqs')."""
        key = symbol.replace('/', '').replace(':USDT', '')
        with self.lock:
            dq = self.events.get(key)
            if not dq:
                return 0.0
            cutoff = time.time() - self.window
            return sum(n for ts, s, n in dq if ts >= cutoff)

    def cascade_intensity(self, symbol):
        """Is a SHORT-liquidation cascade firing RIGHT NOW? Compares short-liq $ in
        the last 60s to the average 60s over the prior window. A burst (>2x) means
        shorts are being force-bought in a chain — fuel that magnetizes price UP,
        useful for a long pump. Distinct from short_liq_ratio (which is composition,
        not timing). Returns a ratio (1.0 = normal, >2 = active cascade), or None."""
        key = symbol.replace('/', '').replace(':USDT', '')
        now = time.time()
        with self.lock:
            dq = self.events.get(key)
            if not dq:
                return None
            recent = sum(n for ts, s, n in dq if ts >= now - 60 and s == 'BUY')
            prior = [(ts, n) for ts, s, n in dq if now - self.window <= ts < now - 60 and s == 'BUY']
        if not prior:
            return None
        prior_minutes = max(1.0, (self.window - 60) / 60.0)
        baseline_per_min = sum(n for _, n in prior) / prior_minutes
        if baseline_per_min <= 0:
            return None
        return round(recent / baseline_per_min, 2)

    def _run(self):
        try:
            import websocket  # websocket-client
        except ImportError:
            log.error("pip install websocket-client to enable the liquidation feed")
            return
        while self._running:
            try:
                ws = websocket.WebSocketApp(
                    WS_URL,
                    on_message=lambda w, m: self._handle(json.loads(m)),
                    on_error=lambda w, e: log.debug(f"ws err: {e}"),
                )
                ws.run_forever(ping_interval=180, ping_timeout=10)
            except Exception as e:
                log.debug(f"ws loop: {e}")
            if self._running:
                time.sleep(5)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        log.info("Liquidation feed started")

    def stop(self):
        self._running = False
