#!/usr/bin/env python3
"""
free_bot_runner.py — runs the Free KryptoSniper bot.

This is the process you run on the VM (as a systemd service) for the free bot.
It wires together:
  • /start        -> register user + welcome (with buttons)
  • Upgrade button -> send Telegram Stars invoice
  • pre-checkout   -> approve
  • payment done   -> grant premium + channel invite
  • /stats         -> admin-only funnel snapshot

Run:  FREE_BOT_TOKEN=xxxxx ADMIN_ID=5547784306 python3 free_bot_runner.py
"""
import os
import asyncio
import logging

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (Application, CommandHandler, CallbackQueryHandler,
                          PreCheckoutQueryHandler, MessageHandler, filters)

import free_bot as fb

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('free_runner')

ADMIN_ID = os.environ.get('ADMIN_ID', '5547784306')
store = fb.UserStore()


def _kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('📡 Join free alerts', url=f"https://t.me/{fb.FREE_CHANNEL_ID.lstrip('@')}")],
        [InlineKeyboardButton('🔓 Upgrade to Premium', callback_data='upgrade')],
    ])


async def start(update: Update, ctx):
    u = update.effective_user
    parts = (update.message.text or '').split(maxsplit=1)
    source = parts[1] if len(parts) > 1 else 'direct'
    store.register(u.id, u.username or '', u.first_name or '', source)
    store.track(u.id, 'start', {'source': source})
    await update.message.reply_text(fb.WELCOME, parse_mode='Markdown',
                                    disable_web_page_preview=True, reply_markup=_kb())


async def on_button(update: Update, ctx):
    q = update.callback_query
    await q.answer()
    if q.data == 'upgrade':
        store.track(q.from_user.id, 'unlock_click')
        await ctx.bot.send_message(chat_id=q.message.chat.id, text=fb.PRICING,
                                   parse_mode='Markdown')
        # send the Stars invoice right after the pitch

        class _M:  # tiny shim so we can reuse send_premium_invoice
            chat = q.message.chat
            from_user = q.from_user
        await fb.send_premium_invoice(ctx.bot, _M())


async def precheckout(update: Update, ctx):
    await fb.on_pre_checkout(ctx.bot, update.pre_checkout_query)


async def paid(update: Update, ctx):
    await fb.on_successful_payment(ctx.bot, store, update.message)


async def stats(update: Update, ctx):
    if str(update.effective_user.id) != str(ADMIN_ID):
        return
    s = store.stats()
    await update.message.reply_text(
        f"📈 Funnel\n\nTotal: {s['total_users']}\nFree: {s['free_users']} · "
        f"Premium: {s['premium_users']}\nUnlock-clickers: {s['unlock_clickers']} "
        f"({s['click_to_total_pct']}%)\nConversion: {s['conversion_pct']}%")


def main():
    token = fb.FREE_BOT_TOKEN
    if token == 'PUT_FREE_BOT_TOKEN_HERE':
        raise SystemExit('Set FREE_BOT_TOKEN env var first (from BotFather).')
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('stats', stats))
    app.add_handler(CallbackQueryHandler(on_button))
    app.add_handler(PreCheckoutQueryHandler(precheckout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, paid))
    logger.info('Free KryptoSniper bot starting...')
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
